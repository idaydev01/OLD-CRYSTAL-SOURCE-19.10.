﻿using System.Collections.Concurrent;
using System.Text;
using System.Text.Json;
using Fleck;
using Helios.Database.Tables.XMPP;
using Helios.Socket.Classes;
using Helios.Socket.Events;
using Helios.Socket.Interfaces;
using Helios.Socket.Services;
using Jose;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ErrorEventArgs = System.IO.ErrorEventArgs;
using IWebSocketServer = Helios.Socket.Interfaces.IWebSocketServer;
using LogLevel = Fleck.LogLevel;

namespace Helios.Socket;

public class ConnectionInfo
{
    public IWebSocketConnection Socket { get; set; }
    public string SessionType { get; set; } // "launcher" or "xmpp"
    public DateTime ConnectedAt { get; set; }
    public string AccountId { get; set; }
    public CancellationTokenSource TimeoutCancellation { get; set; } = new();
    public volatile bool IsHealthy = true;
    public DateTime LastHeartbeat { get; set; } = DateTime.UtcNow;
    public string ClientIdentifier { get; set; }
}

public class WebSocketServer : IWebSocketServer, IDisposable
{
    private Fleck.IWebSocketServer _server;
    private readonly IClientManager _clientManager;
    private readonly WebSocketConfiguration _configuration;
    private readonly MessageHandler _messageHandler;
    private volatile bool _disposed;
    private volatile bool _isShuttingDown;
    public bool IsRunning { get; private set; }

    public event EventHandler<LauncherConnectedEventArgs> LauncherConnected;
    public event EventHandler<LauncherDisconnectedEventArgs> LauncherDisconnected;
    public event EventHandler<LauncherErrorEventArgs> LauncherErrorOccurred;
    public event EventHandler<LauncherMessageReceivedEventArgs> LauncherMessageReceived;
    public event EventHandler<ClientConnectedEventArgs> ClientConnected;
    public event EventHandler<ClientDisconnectedEventArgs> ClientDisconnected;
    public event EventHandler<MessageReceivedEventArgs> MessageReceived;
    public event EventHandler<Events.ErrorEventArgs> ErrorOccurred;

    private readonly SemaphoreSlim _connectionSemaphore = new SemaphoreSlim(1, 1);
    private readonly SemaphoreSlim _shutdownSemaphore = new SemaphoreSlim(1, 1);

    private readonly ConcurrentDictionary<Guid, ConnectionInfo> _activeConnections = new();
    private readonly ConcurrentDictionary<Guid, bool> _disconnectingClients = new();

    private readonly ConcurrentDictionary<string, Guid> _clientIdentifierMap = new();

    private const int ConnectionTimeoutMs = 30000;
    private const int MaxRetryAttempts = 3;
    private const int RetryDelayMs = 1000;
    private const int HeartbeatIntervalMs = 30000;
    private const int ClientTimeoutMs = 60000;

    private Timer _heartbeatTimer;

    public WebSocketServer(WebSocketConfiguration configuration = null)
    {
        _configuration = configuration ?? new WebSocketConfiguration();
        _clientManager = new ClientManager();

        _messageHandler = new MessageHandler(_clientManager, _activeConnections);

        IsRunning = false;
        _isShuttingDown = false;
        _heartbeatTimer = new Timer(CheckClientHeartbeats, null, HeartbeatIntervalMs, HeartbeatIntervalMs);
    }

    private async void CheckClientHeartbeats(object state)
    {
        if (_isShuttingDown || _disposed)
            return;

        var now = DateTime.UtcNow;
        var timedOutConnections = new List<Guid>();

        foreach (var kvp in _activeConnections)
        {
            var connection = kvp.Value;
            if (now - connection.LastHeartbeat > TimeSpan.FromMilliseconds(ClientTimeoutMs))
            {
                timedOutConnections.Add(kvp.Key);
                Logger.Warn($"Client {kvp.Key} timed out - last heartbeat: {connection.LastHeartbeat}");
            }
        }

        foreach (var socketId in timedOutConnections)
        {
            try
            {
                await ForceDisconnectXmppClient(socketId, "Heartbeat timeout");
            }
            catch (Exception ex)
            {
                Logger.Error($"Error disconnecting timed out client {socketId}: {ex.Message}");
            }
        }
    }

    public void Start()
    {
        ThrowIfDisposed();

        if (IsRunning)
        {
            Logger.Warn("WebSocket server is already running");
            return;
        }

        var retryCount = 0;
        Exception lastException = null;

        while (retryCount < MaxRetryAttempts)
        {
            try
            {
                Logger.Info($"Starting WebSocket server on {_configuration.ServerUrl} (attempt {retryCount + 1}/{MaxRetryAttempts})");

                _ = Task.Run(async () => await CleanupOrphanedSessions());

                ConfigureFleckLogging();

                var server = new Fleck.WebSocketServer(_configuration.ServerUrl);
                server.RestartAfterListenError = _configuration.RestartAfterListenError;

                server.Start(async socket =>
                {
                    if (_isShuttingDown || _disposed)
                    {
                        SafeCloseSocket(socket);
                        return;
                    }

                    socket.OnOpen = async () => await SafeExecuteAsync(() => HandleClientConnected(socket), "HandleClientConnected");
                    socket.OnClose = async () => await SafeExecuteAsync(() => HandleClientDisconnected(socket), "HandleClientDisconnected");
                    socket.OnMessage = async message => await SafeExecuteAsync(() => HandleMessageReceived(socket, message), "HandleMessageReceived");
                    socket.OnError = async ex => await SafeExecuteAsync(() => HandleError(socket, ex), "HandleError");
                });

                _server = server;
                IsRunning = true;
                _isShuttingDown = false;

                Logger.Info("WebSocket server started successfully");
                return;
            }
            catch (Exception ex)
            {
                lastException = ex;
                retryCount++;

                Logger.Error($"Failed to start WebSocket server (attempt {retryCount}/{MaxRetryAttempts}): {ex.Message}");

                if (retryCount < MaxRetryAttempts)
                {
                    Logger.Info($"Retrying in {RetryDelayMs}ms...");
                    Thread.Sleep(RetryDelayMs);
                }
            }
        }

        Logger.Error($"Failed to start WebSocket server after {MaxRetryAttempts} attempts");
        OnErrorOccurred(new Events.ErrorEventArgs
        {
            Error = lastException ?? new Exception("Failed to start server after multiple attempts"),
            ErrorSource = "Server initialization"
        });
        throw lastException ?? new Exception("Failed to start server after multiple attempts");
    }

    private async Task CleanupOrphanedSessions()
    {
        try
        {
            Logger.Info("Cleaning up orphaned sessions...");

            var allClients = await _clientManager.ListAllClients();
            var allLaunchers = await _clientManager.ListAllLauncherSessions();

            int cleanedClients = 0;
            int cleanedLaunchers = 0;

            foreach (var client in allClients)
            {
                if (!_activeConnections.ContainsKey(client.SocketId))
                {
                    await _clientManager.RemoveClient(client.SocketId);
                    cleanedClients++;
                }
            }

            foreach (var launcher in allLaunchers)
            {
                if (!_activeConnections.ContainsKey(launcher.SocketId))
                {
                    await _clientManager.RemoveLauncherSession(launcher.SocketId);
                    cleanedLaunchers++;
                }
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Error during orphaned session cleanup: {ex.Message}");
        }
    }

    private void ConfigureFleckLogging()
    {
        if (_configuration.EnableLogging)
        {
            FleckLog.Level = LogLevel.Debug;
            FleckLog.LogAction = (level, message, ex) =>
            {
                try
                {
                    var fullMessage = $"[Fleck] {message ?? "null"} {ex?.Message ?? string.Empty}";

                    switch (level)
                    {
                        case LogLevel.Debug:
                            Logger.Debug(fullMessage);
                            break;
                        case LogLevel.Info:
                            Logger.Info(fullMessage);
                            break;
                        case LogLevel.Warn:
                            Logger.Warn(fullMessage);
                            break;
                        case LogLevel.Error:
                            Logger.Error(fullMessage, ex);
                            break;
                        default:
                            Logger.Info(fullMessage);
                            break;
                    }
                }
                catch (Exception logEx)
                {
                    Console.WriteLine($"[Fleck Logging Error] {logEx.Message}");
                }
            };
        }
        else
        {
            FleckLog.Level = LogLevel.Error;
        }
    }

    public async Task Stop()
    {
        if (!IsRunning && !_isShuttingDown)
        {
            return;
        }

        await _shutdownSemaphore.WaitAsync();
        try
        {
            _isShuttingDown = true;
            Logger.Info("Stopping WebSocket server");

            _heartbeatTimer?.Dispose();

            var shutdownTasks = new List<Task>();
            var activeConnections = _activeConnections.Values.ToList();

            foreach (var connectionInfo in activeConnections)
            {
                connectionInfo.TimeoutCancellation?.Cancel();
            }

            foreach (var connectionInfo in activeConnections)
            {
                shutdownTasks.Add(Task.Run(async () =>
                {
                    try
                    {
                        var socketId = connectionInfo.Socket?.ConnectionInfo?.Id ?? Guid.Empty;
                        if (socketId == Guid.Empty) return;

                        if (connectionInfo.SessionType == "launcher")
                        {
                            await ForceDisconnectLauncherSession(socketId, "Server shutdown");
                        }
                        else
                        {
                            await ForceDisconnectXmppClient(socketId, "Server shutdown");
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Warn($"Error closing connection during shutdown: {ex.Message}");
                    }
                }));
            }

            try
            {
                await Task.WhenAll(shutdownTasks).WaitAsync(TimeSpan.FromSeconds(10));
            }
            catch (TimeoutException)
            {
                Logger.Warn("Shutdown timeout reached, forcing closure");
            }

            _activeConnections.Clear();
            _disconnectingClients.Clear();
            _clientIdentifierMap.Clear();
            _clientManager?.Clear();
            Globals._socketConnections?.Clear();

            try
            {
                (_server as IDisposable)?.Dispose();
            }
            catch (Exception ex)
            {
                Logger.Warn($"Error disposing server: {ex.Message}");
            }

            IsRunning = false;
            Logger.Info("WebSocket server stopped successfully");
        }
        catch (Exception ex)
        {
            Logger.Error($"Error stopping WebSocket server: {ex.Message}");
            OnErrorOccurred(new Events.ErrorEventArgs
            {
                Error = ex,
                ErrorSource = "Server shutdown"
            });
            throw;
        }
        finally
        {
            _shutdownSemaphore.Release();
        }
    }

    private async Task HandleClientConnected(IWebSocketConnection socket)
    {
        if (_isShuttingDown || _disposed)
        {
            SafeCloseSocket(socket);
            return;
        }

        if (socket?.ConnectionInfo?.Id == null)
        {
            Logger.Error("Invalid socket connection - null socket or connection info");
            SafeCloseSocket(socket);
            return;
        }

        var connectionTimeout = new CancellationTokenSource(ConnectionTimeoutMs);

        try
        {
            await _connectionSemaphore.WaitAsync(connectionTimeout.Token);
        }
        catch (OperationCanceledException)
        {
            Logger.Error("Connection timeout while waiting for semaphore");
            SafeCloseSocket(socket);
            return;
        }

        try
        {
            var socketId = socket.ConnectionInfo.Id;

            if (_activeConnections.ContainsKey(socketId))
            {
                Logger.Warn($"Duplicate connection attempt detected: {socketId}");
                SafeCloseSocket(socket);
                return;
            }

            var (sessionType, token, accountId) = ParseConnectionInfo(socket);

            if (string.IsNullOrEmpty(sessionType))
            {
                Logger.Error($"Unable to determine session type for connection: {socketId}");
                SafeCloseSocket(socket);
                return;
            }

            if (sessionType == "launcher")
            {
                await HandleLauncherConnection(socket, socketId, token, accountId, connectionTimeout);
            }
            else
            {
                await HandleXmppConnection(socket, socketId, sessionType, token, connectionTimeout);
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Error handling client connection: {ex.Message}");
            SafeCloseSocket(socket);
            OnErrorOccurred(new Events.ErrorEventArgs
            {
                Error = ex,
                ErrorSource = "Client connection handler"
            });
        }
        finally
        {
            _connectionSemaphore.Release();
        }
    }

    private (string sessionType, string token, string accountId) ParseConnectionInfo(IWebSocketConnection socket)
    {
        try
        {
            var protocol = socket?.ConnectionInfo?.SubProtocol ?? "None";
            var token = "";
            var accountId = "";

            var path = socket?.ConnectionInfo?.Path ?? "";
            var query = "";

            if (path.Contains('?'))
            {
                var parts = path.Split('?', 2);
                if (parts.Length > 1)
                    query = parts[1];
            }

            if (!string.IsNullOrWhiteSpace(query))
            {
                try
                {
                    string fixedQuery = query.StartsWith("?") ? query : "?" + query;
                    var queryParams = System.Web.HttpUtility.ParseQueryString(fixedQuery);

                    if (protocol == "None" && queryParams["from"]?.ToLower() == "launcher")
                    {
                        protocol = "launcher";
                    }

                    if (string.IsNullOrEmpty(token) && !string.IsNullOrEmpty(queryParams["token"]))
                    {
                        token = queryParams["token"]?.Trim() ?? "";
                    }
                }
                catch (Exception ex)
                {
                    Logger.Warn($"Error parsing query parameters: {ex.Message}");
                }
            }

            if (protocol == "launcher" && !string.IsNullOrEmpty(token))
            {
                try
                {
                    var decodedToken = DecodeTokenIDK(token);
                    accountId = decodedToken?.AccountID ?? "";
                }
                catch (Exception ex)
                {
                    Logger.Warn($"Failed to decode launcher token: {ex.Message}");
                    protocol = "xmpp";
                }
            }

            if (protocol == "None")
                protocol = "xmpp";

            return (protocol, token, accountId);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error parsing connection info: {ex.Message}");
            return ("xmpp", "", "");
        }
    }

    private async Task HandleLauncherConnection(IWebSocketConnection socket, Guid socketId, string token, string accountId, CancellationTokenSource timeoutCancellation)
    {
        try
        {
            if (string.IsNullOrEmpty(accountId))
            {
                Logger.Error($"Invalid launcher connection - no account ID: {socketId}");
                SafeCloseSocket(socket);
                return;
            }

            var existingLaunchers = await _clientManager.ListAllLauncherSessions();
            var existingLauncher = existingLaunchers.FirstOrDefault(l => l.AccountId == accountId);

            if (existingLauncher != null && existingLauncher.SocketId != socketId)
            {
                Logger.Info($"Replacing existing launcher session for account {accountId}: {existingLauncher.SocketId} -> {socketId}");
                await ForceDisconnectLauncherSession(existingLauncher.SocketId, "New session connected");
            }

            var newLauncherSession = new LauncherSessions
            {
                SocketId = socketId,
                Protocol = "launcher",
                Token = token,
                AccountId = accountId,
                ConnectedAt = DateTime.UtcNow
            };

            await _clientManager.AddLauncherSession(newLauncherSession, socket);

            var connectionInfo = new ConnectionInfo
            {
                Socket = socket,
                SessionType = "launcher",
                ConnectedAt = DateTime.UtcNow,
                AccountId = accountId,
                TimeoutCancellation = timeoutCancellation,
                LastHeartbeat = DateTime.UtcNow,
                ClientIdentifier = accountId
            };

            _activeConnections[socketId] = connectionInfo;
            _clientIdentifierMap[accountId] = socketId;
            Globals._socketConnections[socketId] = socket;

            Logger.Info($"Launcher session connected for account {accountId}: {socketId}");

            OnLauncherConnected(new LauncherConnectedEventArgs
            {
                Client = new LauncherSessions
                {
                    SocketId = socketId,
                    Protocol = "launcher",
                    Token = token,
                    AccountId = accountId
                }
            });
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to handle launcher connection: {ex.Message}");
            SafeCloseSocket(socket);
            throw;
        }
    }

    private async Task HandleXmppConnection(IWebSocketConnection socket, Guid socketId, string protocol, string token, CancellationTokenSource timeoutCancellation)
    {
        try
        {
            var clientIdentifier = $"{socket.ConnectionInfo.ClientIpAddress}_{protocol}_{token?.GetHashCode() ?? 0}";

            if (_clientIdentifierMap.TryGetValue(clientIdentifier, out var existingSocketId) &&
                _activeConnections.ContainsKey(existingSocketId))
            {
                Logger.Info($"Replacing existing XMPP client {clientIdentifier}: {existingSocketId} -> {socketId}");
                await ForceDisconnectXmppClient(existingSocketId, "New session connected");
            }

            var existingClients = await _clientManager.ListAllClients();
            var orphanedClients = existingClients.Where(c => !_activeConnections.ContainsKey(c.SocketId)).ToList();

            foreach (var orphaned in orphanedClients)
            {
                Logger.Info($"Cleaning up orphaned XMPP client during new connection: {orphaned.SocketId}");
                await _clientManager.RemoveClient(orphaned.SocketId);
            }

            var newSession = new ClientSessions
            {
                SocketId = socketId,
                Protocol = protocol == "None" ? "xmpp" : protocol,
                Token = token
            };

            await _clientManager.AddClient(newSession, socket);

            var connectionInfo = new ConnectionInfo
            {
                Socket = socket,
                SessionType = "xmpp",
                ConnectedAt = DateTime.UtcNow,
                TimeoutCancellation = timeoutCancellation,
                LastHeartbeat = DateTime.UtcNow,
                ClientIdentifier = clientIdentifier
            };

            _activeConnections[socketId] = connectionInfo;
            _clientIdentifierMap[clientIdentifier] = socketId;
            Globals._socketConnections[socketId] = socket;

            Logger.Info($"XMPP client connected ({clientIdentifier}): {socketId}");

            OnClientConnected(new ClientConnectedEventArgs { Client = newSession });
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to handle XMPP connection: {ex.Message}");
            SafeCloseSocket(socket);
            throw;
        }
    }

    public static RequestedUserData DecodeTokenIDK(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
            throw new ArgumentException("Token cannot be null or empty.", nameof(token));

        var config = WebSocketConfiguration.config;
        if (config == null)
            throw new InvalidOperationException("WebSocket configuration is not initialized");

        string secret = config.JWTClientSecret;
        if (string.IsNullOrWhiteSpace(secret))
            throw new ArgumentException("Client secret cannot be null or empty.", nameof(secret));

        try
        {
            var payload = JWT.Decode<Dictionary<string, object>>(token, Encoding.UTF8.GetBytes(secret), JwsAlgorithm.HS256);

            if (payload == null)
                throw new InvalidOperationException("Token payload is null");

            var userData = new RequestedUserData();

            userData.AccountID = payload.TryGetValue("AccountID", out var accountIdObj)
                ? accountIdObj?.ToString() ?? string.Empty
                : string.Empty;

            userData.UserAccount = payload.TryGetValue("UserAccount", out var userAccountRaw) && userAccountRaw != null
                ? JsonConvert.DeserializeObject<UserAccount>(userAccountRaw.ToString() ?? "{}")
                : new UserAccount();

            userData.Profile = payload.TryGetValue("Profile", out var profileRaw) && profileRaw != null
                ? JsonConvert.DeserializeObject<UserProfile>(profileRaw.ToString() ?? "{}")
                : new UserProfile();

            return userData;
        }
        catch (Exception ex)
        {
            Logger.Error($"Error decoding token: {ex.Message}");
            throw;
        }
    }

    private async Task HandleClientDisconnected(IWebSocketConnection socket)
    {
        if (socket?.ConnectionInfo?.Id == null)
        {
            return;
        }

        await _connectionSemaphore.WaitAsync();
        try
        {
            var socketId = socket.ConnectionInfo.Id;

            if (!_disconnectingClients.TryAdd(socketId, true))
            {
                return;
            }

            if (_activeConnections.TryGetValue(socketId, out var existingConnection))
            {
                existingConnection.TimeoutCancellation?.Cancel();
                existingConnection.TimeoutCancellation?.Dispose();
            }

            if (!_activeConnections.TryRemove(socketId, out var connectionInfo))
            {
                Globals._socketConnections?.Remove(socketId, out _);
                await CleanupOrphanedSession(socketId);
                return;
            }

            if (!string.IsNullOrEmpty(connectionInfo.ClientIdentifier))
            {
                _clientIdentifierMap.TryRemove(connectionInfo.ClientIdentifier, out _);
            }

            if (connectionInfo.SessionType == "launcher")
            {
                await HandleLauncherDisconnection(socketId, connectionInfo.AccountId);
            }
            else
            {
                await HandleXmppDisconnection(socketId);
            }

            Globals._socketConnections?.Remove(socketId, out _);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error handling client disconnection: {ex.Message}");
            OnErrorOccurred(new Events.ErrorEventArgs
            {
                Client = new ClientSessions { SocketId = socket.ConnectionInfo.Id },
                Error = ex,
                ErrorSource = "Client disconnection handler"
            });
        }
        finally
        {
            _disconnectingClients.TryRemove(socket.ConnectionInfo.Id, out _);
            _connectionSemaphore.Release();
        }
    }

    private async Task HandleLauncherDisconnection(Guid socketId, string accountId)
    {
        try
        {
            var (found, launcherSession) = await _clientManager.TryGetLauncherSessionAsync(socketId);

            if (found && launcherSession != null)
            {
                await _clientManager.RemoveLauncherSession(socketId);
                Logger.Info($"Launcher session disconnected for account {accountId}: {socketId}");

                OnLauncherDisconnected(new LauncherDisconnectedEventArgs
                {
                    Client = launcherSession
                });
            }
            else
            {
                Logger.Warn($"Launcher session not found in database during disconnection: {socketId}");
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Error handling launcher disconnection for {socketId}: {ex.Message}");
        }
    }

    private async Task HandleXmppDisconnection(Guid socketId)
    {
        try
        {
            var (found, client) = await _clientManager.TryGetClientAsync(socketId);

            if (found && client != null)
            {
                await _clientManager.RemoveClient(socketId);
                Logger.Info($"XMPP client disconnected: {socketId}");

                OnClientDisconnected(new ClientDisconnectedEventArgs
                {
                    Client = client
                });
            }
            else
            {
                Logger.Warn($"XMPP client not found in database during disconnection: {socketId}");
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Error handling XMPP disconnection for {socketId}: {ex.Message}");
        }
    }

    private async Task CleanupOrphanedSession(Guid socketId)
    {
        try
        {
            var clientTask = _clientManager.TryGetClientAsync(socketId);
            var launcherTask = _clientManager.TryGetLauncherSessionAsync(socketId);

            await Task.WhenAll(clientTask, launcherTask);

            var (foundClient, client) = clientTask.Result;
            var (foundLauncher, launcherSession) = launcherTask.Result;

            if (foundClient && client != null)
            {
                await _clientManager.RemoveClient(socketId);
                Logger.Info($"Cleaned up orphaned XMPP client: {socketId}");
                OnClientDisconnected(new ClientDisconnectedEventArgs { Client = client });
            }

            if (foundLauncher && launcherSession != null)
            {
                await _clientManager.RemoveLauncherSession(socketId);
                Logger.Info($"Cleaned up orphaned launcher session: {socketId}");
                OnLauncherDisconnected(new LauncherDisconnectedEventArgs { Client = launcherSession });
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Error cleaning up orphaned session {socketId}: {ex.Message}");
        }
    }

    private async Task HandleMessageReceived(IWebSocketConnection socket, string message)
    {
        if (socket?.ConnectionInfo?.Id == null)
        {
            Logger.Warn("HandleMessageReceived called with null socket or connection info");
            return;
        }

        if (string.IsNullOrEmpty(message))
        {
            return;
        }

        try
        {
            var socketId = socket.ConnectionInfo.Id;

            if (_activeConnections.TryGetValue(socketId, out var connectionInfo))
            {
                connectionInfo.IsHealthy = true;
                connectionInfo.LastHeartbeat = DateTime.UtcNow;

                if (connectionInfo.SessionType == "launcher")
                {
                    var (found, launcherSession) = await _clientManager.TryGetLauncherSessionAsync(socketId);

                    if (found && launcherSession != null)
                    {
                        OnLauncherMessageReceived(new LauncherMessageReceivedEventArgs
                        {
                            Client = launcherSession,
                            Message = message
                        });
                        return;
                    }
                }
                else
                {
                    var (found, client) = await _clientManager.TryGetClientAsync(socketId);

                    if (found && client != null)
                    {
                        OnMessageReceived(new MessageReceivedEventArgs
                        {
                            Client = client,
                            Message = message
                        });
                        return;
                    }
                }
            }

            Logger.Warn($"Message received from unknown or inactive socket: {socketId}");
        }
        catch (Exception ex)
        {
            Logger.Error($"Error handling message: {ex.Message}");
            OnErrorOccurred(new Events.ErrorEventArgs
            {
                Client = new ClientSessions(),
                Error = ex,
                ErrorSource = "Message handler"
            });
        }
    }

    private async Task HandleError(IWebSocketConnection socket, Exception ex)
    {
        if (socket?.ConnectionInfo?.Id == null)
        {
            Logger.Error($"Error from unknown socket: {ex?.Message ?? "Unknown error"}");
            OnErrorOccurred(new Events.ErrorEventArgs
            {
                Error = ex ?? new Exception("Unknown error"),
                ErrorSource = "Unknown connection"
            });
            return;
        }

        try
        {
            var socketId = socket.ConnectionInfo.Id;

            if (IsNormalConnectionClosure(ex))
            {
                await HandleClientDisconnected(socket);
                return;
            }

            if (_activeConnections.TryGetValue(socketId, out var connectionInfo))
            {
                connectionInfo.IsHealthy = false;
            }

            if (_activeConnections.TryGetValue(socketId, out var activeConnectionInfo))
            {
                if (activeConnectionInfo.SessionType == "launcher")
                {
                    Logger.Error($"Error from launcher session {socketId}: {ex?.Message ?? "Unknown error"}");

                    var (found, launcherSession) = await _clientManager.TryGetLauncherSessionAsync(socketId);

                    OnLauncherErrorOccurred(new Events.LauncherErrorEventArgs
                    {
                        Client = found && launcherSession != null ? launcherSession : new LauncherSessions { SocketId = socketId },
                        Error = ex ?? new Exception("Unknown error"),
                        ErrorSource = "Launcher connection"
                    });
                }
                else
                {
                    Logger.Error($"Error from XMPP client {socketId}: {ex?.Message ?? "Unknown error"}");

                    var (found, client) = await _clientManager.TryGetClientAsync(socketId);

                    OnErrorOccurred(new Events.ErrorEventArgs
                    {
                        Client = found && client != null ? client : new ClientSessions { SocketId = socketId },
                        Error = ex ?? new Exception("Unknown error"),
                        ErrorSource = "XMPP Client connection"
                    });
                }
            }
            else
            {
                Logger.Error($"Error from unknown socket {socketId}: {ex?.Message ?? "Unknown error"}");
                OnErrorOccurred(new Events.ErrorEventArgs
                {
                    Error = ex ?? new Exception("Unknown error"),
                    ErrorSource = "Unknown connection"
                });
            }

            await HandleClientDisconnected(socket);
        }
        catch (Exception handlerEx)
        {
            Logger.Error($"Error in error handler: {handlerEx.Message}");
            OnErrorOccurred(new Events.ErrorEventArgs
            {
                Error = handlerEx,
                ErrorSource = "Error handler"
            });
        }
    }

    private static bool IsNormalConnectionClosure(Exception ex)
    {
        if (ex == null) return false;

        var message = ex.Message ?? "";
        return message.Contains("An existing connection was forcibly closed by the remote host") ||
               message.Contains("The remote party closed the WebSocket connection") ||
               message.Contains("Connection reset by peer") ||
               message.Contains("The WebSocket connection closed unexpectedly");
    }

    private static void SafeCloseSocket(IWebSocketConnection socket)
    {
        try
        {
            socket?.Close();
        }
        catch (Exception ex)
        {
            Logger.Error($"Error closing socket: {ex.Message}");
        }
    }

    private async Task SafeExecuteAsync(Func<Task> action, string actionName)
    {
        try
        {
            if (_disposed || _isShuttingDown)
                return;

            await action();
        }
        catch (Exception ex)
        {
            Logger.Error($"Error in {actionName}: {ex.Message}");
            OnErrorOccurred(new Events.ErrorEventArgs
            {
                Error = ex,
                ErrorSource = actionName
            });
        }
    }

    public async Task SendToClient(Guid socketId, string message)
    {
        ThrowIfDisposed();

        if (_messageHandler == null)
            throw new InvalidOperationException("Message handler is not initialized");

        await _messageHandler.SendToClientAsync(socketId, message);
    }

    public async Task SendToLauncherSession(Guid socketId, string message)
    {
        ThrowIfDisposed();

        if (_messageHandler == null)
            throw new InvalidOperationException("Message handler is not initialized");

        await _messageHandler.SendToLauncherSessionAsync(socketId, message);
    }

    public async Task DisconnectClient(Guid socketId, string reason = "Disconnected by server")
    {
        ThrowIfDisposed();

        if (_activeConnections.TryGetValue(socketId, out var connectionInfo))
        {
            if (connectionInfo.SessionType == "launcher")
            {
                await DisconnectLauncherSession(socketId, reason);
            }
            else
            {
                await ForceDisconnectXmppClient(socketId, reason);
            }
        }
        else
        {
            Logger.Warn($"Cannot disconnect unknown client {socketId}");
        }
    }

    public async Task DisconnectLauncherSession(Guid socketId, string reason = "Disconnected by server")
    {
        ThrowIfDisposed();
        await ForceDisconnectLauncherSession(socketId, reason);
    }

    private async Task ForceDisconnectXmppClient(Guid socketId, string reason)
    {
        try
        {
            Logger.Info($"Force disconnecting XMPP client {socketId}: {reason}");

            if (Globals._socketConnections?.TryGetValue(socketId, out var connection) == true)
            {
                SafeCloseSocket(connection);
            }

            _activeConnections.TryRemove(socketId, out var removedConnection);

            removedConnection?.TimeoutCancellation?.Cancel();
            removedConnection?.TimeoutCancellation?.Dispose();

            var (found, client) = await _clientManager.TryGetClientAsync(socketId);
            if (found && client != null)
            {
                await _clientManager.RemoveClient(socketId);
                OnClientDisconnected(new ClientDisconnectedEventArgs { Client = client });
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Error force disconnecting XMPP client {socketId}: {ex.Message}");
            OnErrorOccurred(new Events.ErrorEventArgs
            {
                Client = new ClientSessions { SocketId = socketId },
                Error = ex,
                ErrorSource = "ForceDisconnectXmppClient"
            });
        }
    }

    private async Task ForceDisconnectLauncherSession(Guid socketId, string reason)
    {
        try
        {
            Logger.Info($"Force disconnecting launcher session {socketId}: {reason}");

            if (Globals._socketConnections?.TryGetValue(socketId, out var connection) == true)
            {
                SafeCloseSocket(connection);
            }

            _activeConnections.TryRemove(socketId, out var removedConnection);

            removedConnection?.TimeoutCancellation?.Cancel();
            removedConnection?.TimeoutCancellation?.Dispose();

            var (found, launcherSession) = await _clientManager.TryGetLauncherSessionAsync(socketId);
            if (found && launcherSession != null)
            {
                await _clientManager.RemoveLauncherSession(socketId);
                OnLauncherDisconnected(new LauncherDisconnectedEventArgs { Client = launcherSession });
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Error force disconnecting launcher session {socketId}: {ex.Message}");
            OnLauncherErrorOccurred(new Events.LauncherErrorEventArgs
            {
                Client = new LauncherSessions { SocketId = socketId },
                Error = ex,
                ErrorSource = "ForceDisconnectLauncherSession"
            });
        }
    }

    public bool TryParseXmppMessage(string message, out XmppMessage xmppMessage)
    {
        ThrowIfDisposed();

        if (_messageHandler == null)
        {
            xmppMessage = null;
            return false;
        }

        return _messageHandler.TryParseXmppMessage(message, out xmppMessage);
    }

    public async Task<IEnumerable<LauncherSessions>> GetLauncherSessions()
    {
        ThrowIfDisposed();

        if (_clientManager == null)
            return Enumerable.Empty<LauncherSessions>();

        return await _clientManager.ListAllLauncherSessions();
    }

    public async Task<IEnumerable<ClientSessions>> GetXmppClients()
    {
        ThrowIfDisposed();

        if (_clientManager == null)
            return Enumerable.Empty<ClientSessions>();

        return await _clientManager.ListAllClients();
    }

    public Dictionary<Guid, string> GetActiveConnectionTypes()
    {
        ThrowIfDisposed();

        try
        {
            return _activeConnections.ToDictionary(
                kvp => kvp.Key,
                kvp => kvp.Value?.SessionType ?? "unknown"
            );
        }
        catch (Exception ex)
        {
            Logger.Error($"Error getting active connection types: {ex.Message}");
            return new Dictionary<Guid, string>();
        }
    }

    public Dictionary<Guid, bool> GetConnectionHealthStatus()
    {
        ThrowIfDisposed();

        try
        {
            return _activeConnections.ToDictionary(
                kvp => kvp.Key,
                kvp => kvp.Value?.IsHealthy ?? false
            );
        }
        catch (Exception ex)
        {
            Logger.Error($"Error getting connection health status: {ex.Message}");
            return new Dictionary<Guid, bool>();
        }
    }

    public int GetActiveConnectionCount()
    {
        ThrowIfDisposed();
        return _activeConnections.Count;
    }

    public TimeSpan GetServerUptime()
    {
        ThrowIfDisposed();

        if (!IsRunning)
            return TimeSpan.Zero;

        var oldestConnection = _activeConnections.Values
            .OrderBy(c => c.ConnectedAt)
            .FirstOrDefault();

        return oldestConnection != null
            ? DateTime.UtcNow - oldestConnection.ConnectedAt
            : TimeSpan.Zero;
    }

    private void ThrowIfDisposed()
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(WebSocketServer));
    }

    protected virtual void OnClientConnected(Events.ClientConnectedEventArgs e)
    {
        try
        {
            ClientConnected?.Invoke(this, e);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error in ClientConnected event handler: {ex.Message}");
        }
    }

    protected virtual void OnLauncherConnected(Events.LauncherConnectedEventArgs e)
    {
        try
        {
            LauncherConnected?.Invoke(this, e);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error in LauncherConnected event handler: {ex.Message}");
        }
    }

    protected virtual void OnLauncherDisconnected(Events.LauncherDisconnectedEventArgs e)
    {
        try
        {
            LauncherDisconnected?.Invoke(this, e);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error in LauncherDisconnected event handler: {ex.Message}");
        }
    }

    protected virtual void OnLauncherErrorOccurred(Events.LauncherErrorEventArgs e)
    {
        try
        {
            LauncherErrorOccurred?.Invoke(this, e);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error in LauncherErrorOccurred event handler: {ex.Message}");
        }
    }

    protected virtual void OnLauncherMessageReceived(Events.LauncherMessageReceivedEventArgs e)
    {
        try
        {
            LauncherMessageReceived?.Invoke(this, e);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error in LauncherMessageReceived event handler: {ex.Message}");
        }
    }

    protected virtual void OnClientDisconnected(Events.ClientDisconnectedEventArgs e)
    {
        try
        {
            ClientDisconnected?.Invoke(this, e);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error in ClientDisconnected event handler: {ex.Message}");
        }
    }

    protected virtual void OnMessageReceived(Events.MessageReceivedEventArgs e)
    {
        try
        {
            MessageReceived?.Invoke(this, e);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error in MessageReceived event handler: {ex.Message}");
        }
    }

    protected virtual void OnErrorOccurred(Events.ErrorEventArgs e)
    {
        try
        {
            ErrorOccurred?.Invoke(this, e);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error in ErrorOccurred event handler: {ex.Message}");
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (_disposed)
            return;

        _disposed = true;

        if (disposing)
        {
            try
            {
                if (IsRunning)
                {
                    Stop().GetAwaiter().GetResult();
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error during disposal: {ex.Message}");
            }

            try
            {
                foreach (var connection in _activeConnections.Values)
                {
                    connection?.TimeoutCancellation?.Cancel();
                    connection?.TimeoutCancellation?.Dispose();
                }

                _connectionSemaphore?.Dispose();
                _shutdownSemaphore?.Dispose();
            }
            catch (Exception ex)
            {
                Logger.Error($"Error disposing resources: {ex.Message}");
            }
        }
    }

    ~WebSocketServer()
    {
        Dispose(false);
    }
}