﻿using System.Text.Json;
using System.Xml.Linq;
using Fleck;
using Helios.Socket.Classes;
using Helios.Socket.Events;
using Helios.Socket.Interfaces;
using System.Collections.Concurrent;

namespace Helios.Socket.Services;

public class MessageHandler : IDisposable
{

    private readonly IClientManager _clientManager;
    private readonly ConcurrentDictionary<Guid, ConnectionInfo> _connections;
    private bool _disposed;

    public event EventHandler<XmppMessageEventArgs> XmppMessageReceived;

    public MessageHandler(IClientManager clientManager, ConcurrentDictionary<Guid, ConnectionInfo> connections)
    {
        _clientManager = clientManager ?? throw new ArgumentNullException(nameof(clientManager));
        _connections = connections ?? throw new ArgumentNullException(nameof(connections));
    }

    public async Task<bool> SendToClientAsync(Guid socketId, string message)
    {
        if (string.IsNullOrEmpty(message))
            return false;

        try
        {
            if (!_connections.TryGetValue(socketId, out var connection))
            {
                Logger.Warn($"Connection not found for socket ID: {socketId}");
                return false;
            }

            if (!connection.Socket.IsAvailable)
            {
                Logger.Warn($"Connection not available for socket ID: {socketId}");
                return false;
            }

            await connection.Socket.Send(message);
            return true;
        }
        catch (Exception ex) when (IsRecoverableException(ex))
        {
            Logger.Error($"Recoverable error sending to {socketId}: {ex.Message}");
            return false;
        }
        catch (Exception ex)
        {
            Logger.Fatal($"Critical error sending to {socketId}: {ex}");
            throw;
        }
    }

    public async Task<bool> SendToLauncherSessionAsync(Guid socketId, string message)
    {
        var (success, client) = await _clientManager.TryGetLauncherSessionAsync(socketId);
        return success && client != null && await SendToClientAsync(client.SocketId, message);
    }

    public async Task BroadcastMessageAsync(string message)
    {
        if (string.IsNullOrEmpty(message))
            return;

        var clients = await _clientManager.ListAllClients();
        //await SendToClientsAsync(clients.ToList(), message, "broadcast");
    }

    public async Task BroadcastMessageExceptAsync(Guid excludedSocketId, string message)
    {
        if (string.IsNullOrEmpty(message))
            return;

        var clients = (await _clientManager.ListAllClients())
            .Where(c => c.SocketId != excludedSocketId)
            .ToList();

        //await SendToClientsAsync(clients, message, $"broadcast-except {excludedSocketId}");
    }

    public bool TryParseXmppMessage(string message, out XmppMessage xmppMessage)
    {
        xmppMessage = null;

        if (string.IsNullOrWhiteSpace(message) ||
            !message.StartsWith("<") ||
            !message.EndsWith(">"))
        {
            return false;
        }

        try
        {
            var element = XElement.Parse(message);
            xmppMessage = new XmppMessage
            {
                Type = element.Name.LocalName,
                Namespace = element.Name.NamespaceName,
                To = element.Attribute("to")?.Value,
                From = element.Attribute("from")?.Value,
                Id = element.Attribute("id")?.Value,
                Version = element.Attribute("version")?.Value,
                Element = element,
                RawContent = message
            };
            return true;
        }
        catch (Exception ex)
        {
            Logger.Error($"XML parse error. Content: {message.Truncate(200)} - Error: {ex.Message}");
            return false;
        }
    }

    private static bool IsRecoverableException(Exception ex)
    {
        return ex is KeyNotFoundException
            || ex is InvalidOperationException
            || ex is WebSocketException
            || ex is IOException;
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (_disposed) return;
        if (disposing)
        {
            XmppMessageReceived = null;
        }
        _disposed = true;
    }

    ~MessageHandler() => Dispose(false);
}

public static class StringExtensions
{
    public static string Truncate(this string value, int maxLength)
    {
        if (string.IsNullOrEmpty(value)) return value;
        return value.Length <= maxLength ? value : value.Substring(0, maxLength) + "...";
    }
}