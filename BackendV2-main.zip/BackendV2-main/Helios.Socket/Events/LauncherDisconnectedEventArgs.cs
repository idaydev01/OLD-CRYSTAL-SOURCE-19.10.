﻿using Helios.Database.Tables.XMPP;

namespace Helios.Socket.Events;

public class LauncherDisconnectedEventArgs : EventArgs
{
    public LauncherSessions Client { get; set; }
    public string Reason { get; set; }
}