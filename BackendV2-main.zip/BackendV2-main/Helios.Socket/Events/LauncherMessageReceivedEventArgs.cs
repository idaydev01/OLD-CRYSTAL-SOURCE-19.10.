﻿using Helios.Database.Tables.XMPP;

namespace Helios.Socket.Events;

public class LauncherMessageReceivedEventArgs : EventArgs
{
    public LauncherSessions Client { get; set; }
    public string Message { get; set; }
    public DateTime ReceivedAt { get; set; } = DateTime.UtcNow;
}