﻿namespace Helios.Socket.Classes;

public class UserAccount
{
    public string DiscordID { get; set; } = string.Empty;
    public string DiscordUsername { get; set; } = string.Empty;
    public string[] Roles { get; set; } = new string[0];
    public string Avatar { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
}

public class AthenaProfile
{
    public string FavoriteCharacter { get; set; } = string.Empty;
    public int SeasonLevel { get; set; } = 0;
    public int SeasonXp { get; set; } = 0;
    public bool BookPurchased { get; set; } = false;
    public int BookLevel { get; set; } = 0;
    public int BookXp { get; set; } = 0;
}

public class CommonCoreProfile
{
    public int Vbucks { get; set; } = 0;
}

public class UserProfile
{
    public AthenaProfile Athena { get; set; } = new AthenaProfile();
    public CommonCoreProfile CommonCore { get; set; } = new CommonCoreProfile();
}

public class RequestedUserData
{
    public string AccountID { get; set; } = string.Empty;
    public UserAccount UserAccount { get; set; } = new UserAccount();
    public UserProfile Profile { get; set; } = new UserProfile();
}
