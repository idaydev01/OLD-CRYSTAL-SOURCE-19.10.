﻿using Fleck;
using Helios.Database.Repository;
using Helios.Database.Tables.XMPP;

namespace Helios.Socket.Interfaces;


public interface IClientManager
{
    Task AddClient(ClientSessions client, IWebSocketConnection socket);
    Task RemoveClient(string accountId, string protocol);
    Task RemoveClient(IWebSocketConnection connection, string protocol);
    Task RemoveClient(Guid socketId);
    Task<(bool success, ClientSessions? client)> TryGetClientAsync(string accountId);
    Task<(bool success, ClientSessions? client)> TryGetClientAsync(Guid socketId);
    Task<List<ClientSessions>> ListAllClients();
    
    Task AddLauncherSession(LauncherSessions launcherSession, IWebSocketConnection socket);
    Task RemoveLauncherSession(Guid socketId);
    Task RemoveLauncherSession(string accountId);
    Task<(bool success, LauncherSessions? session)> TryGetLauncherSessionAsync(Guid socketId);
    Task<(bool success, LauncherSessions? session)> TryGetLauncherSessionAsync(string accountId);
    Task<List<LauncherSessions>> ListAllLauncherSessions();
    Task UpdateLauncherSession(LauncherSessions session, IWebSocketConnection socket);
    
    Task<bool> ClientExists(Guid socketId, string protocol);
    Task Clear();
}