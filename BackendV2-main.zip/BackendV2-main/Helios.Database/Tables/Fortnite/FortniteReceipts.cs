﻿using Helios.Database.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Tables.Fortnite
{
    [Entity("fortnite_receipts")]
    public class FortniteReceipts : BaseTable
    {
        [Column("accountId")]
        public string AccountId { get; set; }

        [Column("appStore")]
        public string AppStore { get; set; }
        [Column("appStoreId")]
        public string AppStoreId { get; set; }
        [Column("receiptId")]
        public string ReceiptId { get; set; }
        [Column("receiptInfo")]
        public string ReceiptInfo { get; set; }
    }
}
