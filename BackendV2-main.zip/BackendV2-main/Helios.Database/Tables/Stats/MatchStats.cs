﻿using Helios.Database.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Tables.Stats
{
    [Entity("match_stats")]
    public class MatchStats : BaseTable
    {
        [Column("accountId")]
        public string AccountId { get; set; }
        [Column("kills")]
        public int Kills { get; set; }
        [Column("xp")]
        public int Xp { get; set; }
        [Column("placement")]
        public int Placement { get; set; }
        [Column("playlist")]
        public string Playlist { get; set; }
        [Column("createdAt")]
        public DateTime CreatedAt { get; set; }
    }
}
