﻿using Helios.Database.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Tables.Stats
{
    [Entity("season_stats")]
    public class SeasonStats : BaseTable
    {
        [Column("accountId")]
        public string AccountId { get; set; }
        [Column("type")]
        public string Type { get; set; }
        [Column("value")]
        public string Value { get; set; }
        [Column("season")]
        public int Season { get; set; }
    }
}
