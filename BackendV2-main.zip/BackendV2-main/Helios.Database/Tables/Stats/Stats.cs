﻿using Helios.Database.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Tables.Stats
{
    [Entity("stats")]
    public class Stats : BaseTable
    {
        [Column("accountId")]
        public string AccountId { get; set; }
        [Column("username")]
        public string Username { get; set; }
        [Column("matches_played")]
        public int MatchesPlayed { get; set; }
        [Column("type")]
        public string Type { get; set; }

        [Column("value")]
        public string Value { get; set; }
    }
}
