﻿using Helios.Database.Attributes;

namespace Helios.Database.Tables.Solstice;

[Entity("solstice_sockets")]
public class SolsticeSockets : BaseTable
{
    [Column("accountId")]
    public string AccountId { get; set; }
    [Column("socketId")]
    public string SocketId { get; set; }
}