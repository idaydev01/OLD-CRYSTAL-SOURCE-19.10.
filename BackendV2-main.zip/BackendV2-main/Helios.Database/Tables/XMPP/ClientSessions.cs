﻿using Helios.Database.Attributes;
using Fleck;
using Newtonsoft.Json;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace Helios.Database.Tables.XMPP;

[Entity("client_sessions")]
public class ClientSessions : BaseTable
{
    [Column("socketId")]
    public Guid SocketId { get; set; }
    
    [Column("protocol")]
    public string Protocol  { get; set; }
    
    [Column("accountId")]
    public string AccountId { get; set; }
    
    [Column("displayName")]
    public string DisplayName { get; set; }
    
    [Column("token")]
    public string Token { get; set; }
    
    [Column("jid")]
    public string Jid { get; set; }
    
    [Column("resource")]
    public string Resource { get; set; }
    
    [Column("lastPresenceUpdate")]
    public string LastPresenceUpdate { get; set; } = JsonSerializer.Serialize(new LastPresenceUpdate());
    
    [Column("isLoggedIn")]
    public bool IsLoggedIn { get; set; }
    [Column("isAdmin")]
    public bool IsAdmin { get; set; }
    
    [Column("isAuthenticated")]
    public bool IsAuthenticated { get; set; }
}

public class LastPresenceUpdate
{
    public bool IsAway { get; set; } = false;
    public string StatusString { get; set; } = JsonSerializer.Serialize(new SessionStatus());
}

public class SessionStatus
{
    [JsonProperty("Status")]
    public string Status { get; set; } = "";

    [JsonProperty("bIsPlaying")]
    public bool bIsPlaying { get; set; } = false;

    [JsonProperty("bIsJoinable")]
    public bool bIsJoinable { get; set; } = false;

    [JsonProperty("bHasVoiceSupport")]
    public bool bHasVoiceSupport { get; set; } = false;

    [JsonProperty("SessionId")]
    public string SessionId { get; set; } = string.Empty;

    [JsonProperty("ProductName")]
    public string ProductName { get; set; } = string.Empty;

    [JsonProperty("Properties")]
    public SessionProperties Properties { get; set; } = new();

    [JsonProperty("MembersCount")]
    public int MembersCount { get; set; }

    [JsonProperty("MaxSize")]
    public int MaxSize { get; set; }
}

public class SessionProperties
{
    [JsonProperty("party.joininfodata.286331153_j")]
    public Dictionary<string, object> PartyJoinInfoData { get; set; }

    [JsonProperty("FortBasicInfo_j")]
    public FortBasicInfo FortBasicInfo { get; set; } = new();

    [JsonProperty("FortLFG_I")]
    public string FortLFG { get; set; } = "0";

    [JsonProperty("FortPartySize_i")]
    public int FortPartySize { get; set; } = 1;

    [JsonProperty("FortSubGame_i")]
    public int FortSubGame { get; set; } = 1;

    [JsonProperty("InUnjoinableMatch_b")]
    public bool InUnjoinableMatch { get; set; } = false;

    [JsonProperty("FortGameplayStats_j")]
    public FortGameplayStats FortGameplayStats { get; set; } = new();
    
    [JsonProperty("SocialStatus_j")]
    public SocialStatus SocialStatus { get; set; } = new();
}

public class FortBasicInfo
{
    [JsonProperty("homeBaseRating")]
    public int HomeBaseRating { get; set; }
}

public class FortGameplayStats
{
    [JsonProperty("state")]
    public string State { get; set; } = "";

    [JsonProperty("playlist")]
    public string Playlist { get; set; } = "";

    [JsonProperty("numKills")]
    public int NumKills { get; set; }

    [JsonProperty("bFellToDeath")]
    public bool FellToDeath { get; set; }
}

public class SocialStatus
{
    [JsonProperty("attendingSocialEventIds")]
    public List<string> AttendingSocialEventIds { get; set; } = new();
}