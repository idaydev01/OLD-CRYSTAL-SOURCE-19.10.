﻿using Helios.Database.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Helios.Database.Tables.Tournaments
{
    public class DB_EventStatIndex
    {
        [JsonPropertyName("timesAchieved")]
        public int TimesAchieved { get; set; }
        [JsonPropertyName("pointsEarned")]
        public int PointsEarned { get; set; }
    }

    [Entity("tournament_event_history")]
    public class TournamentHistory : BaseTable
    {
        [Column("accountId")]
        public string AccountId { get; set; }
        [Column("eventId")]
        public string EventId { get; set; }
        [Column("teamId")]
        public string TeamId { get; set; }
        [Column("teamElimsStatIndex")]
        public DB_EventStatIndex TeamElimsStatIndex { get; set; }
        [Column("placementStatIndex")]
        public DB_EventStatIndex PlacementStatIndex { get; set; }
        [Column("victoryRoyaleStatIndex")]
        public DB_EventStatIndex VictoryRoyaleStatIndex { get; set; }
        [Column("timeAliveStatIndex")]
        public DB_EventStatIndex TimeAliveStatIndex { get; set; } = new();
        [Column("matchesPlayedStatIndex")]
        public DB_EventStatIndex MatchesPlayedStatIndex { get; set; } = new();
        [Column("sessionEndTimes")]
        public Dictionary<string, string> SessionEndTimes { get; set; } = new Dictionary<string, string>();
        [Column("season")]
        public int Season { get; set; }
    }
}
