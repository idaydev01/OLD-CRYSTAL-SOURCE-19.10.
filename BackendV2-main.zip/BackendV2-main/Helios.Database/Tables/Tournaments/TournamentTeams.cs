﻿using Helios.Database.Attributes;

namespace Helios.Database.Tables.Tournaments;

[Entity("tournament_teams")]
public class TournamentTeams : BaseTable
{
    [Column("eventId")]
    public string TournamentId { get; set; }
    [Column("accountId")]
    public string AccountId { get; set; }
    [Column("teams")]
    public Dictionary<string,List<string>> Teams { get; set; }
}