﻿using Helios.Database.Attributes;

namespace Helios.Database.Tables.Tournaments;

[Entity("tournament_hype")]
public class TournamentHype : BaseTable
{
    [Column("accountId")]
    public string AccountId { get; set; }
    [Column("type")]
    public string Type { get; set; }
    [Column("hype")]
    public int Hype { get; set; }
    [Column("season")]
    public int Season { get; set; }
}