﻿using Helios.Database.Attributes;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace Helios.Database.Tables.Tournaments;

[Entity("tournament_templates")]
public class TournamentTemplates : BaseTable
{
    [Column("event_id")]
    public string EventId { get; set; }
    [Column("tournament_id")]
    public string TournamentId { get; set; }
    [Column("playlist_id")]
    public string PlaylistId { get; set; }
    [Column("match_cap")]
    public int MatchCap { get; set; }
    [Column("tiebreaker_formula")]
    public dynamic TiebreakerFormula { get; set; } 
    [Column("event_template_id")]
    public string EventTemplateId { get; set; }
    [Column("scoring_rules")]
    public string ScoringRules { get; set; }  
    [Column("persistentScoreId")]
    public string PersistentScoreId { get; set; }
    [Column("payout_table")]
    public string PayoutTable { get; set; }  
    [Column("live_session_attributes")]
    public string LiveSessionAttributes { get; set; } 
    [Column("clamps_to_zero")]
    public bool ClampsToZero { get; set; }
    [Column("only_score_top_n")]
    public int OnlyScoreTopN { get; set; }
    [Column("season")]
    public int Season { get; set; }
}