﻿using Helios.Database.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Tables.Account
{
    [Entity("server_accounts")]
    public class ServerAccounts : BaseTable
    {
        [Column("username")]
        public string Username { get; set; }
        [Required]
        [Column("email")]
        [EmailAddress]
        public string Email { get; set; }
        [Column("password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Column("accountId")]
        [Required]
        public string AccountId { get; set; }
        [Column("discordId")]
        [Required]
        public string DiscordId { get; set; }
    }
}
