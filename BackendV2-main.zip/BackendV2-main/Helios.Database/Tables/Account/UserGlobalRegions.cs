﻿using Helios.Database.Attributes;

namespace Helios.Database.Tables.Account;

[Entity("user_global_regions")]
public class UserGlobalRegions : BaseTable
{
    [Column("accountId")]
    public string AccountId { get; set; }
    [Column("region")]
    public string Region { get; set; }
}