﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Repository.Query
{
    internal class QuerySpec
    {
        public Type EntityType { get; }
        public List<Expression> WhereClauses { get; } = new List<Expression>();
        public int? TakeCount { get; set; }
        public DynamicParameters Parameters { get; } = new DynamicParameters();
        private int _paramCounter = 0;

        public QuerySpec(Type entityType)
        {
            EntityType = entityType;
        }

        public string BuildSql(EntityMetadata metadata)
        {
            var tableName = metadata.TableName;
            var sb = new StringBuilder($"SELECT * FROM {tableName}");

            if (WhereClauses.Any())
            {
                sb.Append(" WHERE ");
                var translator = new ExpressionToSqlTranslator(metadata);
                var whereSql = translator.Translate(WhereClauses, Parameters, ref _paramCounter);
                sb.Append(whereSql);
            }

            if (TakeCount.HasValue)
            {
                sb.Append($" LIMIT {TakeCount.Value}");
            }

            return sb.ToString();
        }

        public string GetCacheKey()
        {
            var sb = new StringBuilder();

            foreach (var clause in WhereClauses)
            {
                sb.Append(clause.ToString());
                sb.Append(";");
            }

            if (TakeCount.HasValue)
            {
                sb.Append($"take:{TakeCount};");
            }

            return sb.ToString();
        }
    }
}
