﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Repository.Query
{
    internal class QueryProvider : IQueryProvider
    {
        private readonly EntityMetadata _metadata;
        private readonly string _connectionString;

        public QueryProvider(EntityMetadata metadata, string connectionString)
        {
            _metadata = metadata;
            _connectionString = connectionString;
        }

        public IQueryable CreateQuery(Expression expression)
        {
            throw new NotImplementedException();
        }

        public IQueryable<TElement> CreateQuery<TElement>(Expression expression)
        {
            return new Queryable<TElement>(_metadata, _connectionString);
        }

        public object Execute(Expression expression)
        {
            throw new NotImplementedException();
        }

        public TResult Execute<TResult>(Expression expression)
        {
            throw new NotImplementedException();
        }
    }
}
