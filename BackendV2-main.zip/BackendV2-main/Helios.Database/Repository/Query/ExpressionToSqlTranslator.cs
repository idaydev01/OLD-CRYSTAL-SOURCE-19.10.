﻿using Dapper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Repository.Query
{
    internal class ExpressionToSqlTranslator : ExpressionVisitor
    {
        private readonly EntityMetadata _metadata;
        private StringBuilder _sqlBuilder;
        private DynamicParameters _parameters;
        private int _paramCounter;

        public ExpressionToSqlTranslator(EntityMetadata metadata)
        {
            _metadata = metadata;
        }

        public string Translate(IEnumerable<Expression> expressions, DynamicParameters parameters, ref int paramCounter)
        {
            _sqlBuilder = new StringBuilder();
            _parameters = parameters;
            _paramCounter = paramCounter;

            var isFirst = true;
            foreach (var expr in expressions)
            {
                if (!isFirst) _sqlBuilder.Append(" AND ");
                Visit(expr);
                isFirst = false;
            }

            paramCounter = _paramCounter;
            return _sqlBuilder.ToString();
        }

        protected override Expression VisitBinary(BinaryExpression node)
        {
            _sqlBuilder.Append("(");
            Visit(node.Left);

            switch (node.NodeType)
            {
                case ExpressionType.Equal:
                    _sqlBuilder.Append(" = ");
                    break;
                case ExpressionType.NotEqual:
                    _sqlBuilder.Append(" != ");
                    break;
                case ExpressionType.AndAlso:
                    _sqlBuilder.Append(" AND ");
                    break;
                case ExpressionType.OrElse:
                    _sqlBuilder.Append(" OR ");
                    break;
                case ExpressionType.LessThan:
                    _sqlBuilder.Append(" < ");
                    break;
                case ExpressionType.LessThanOrEqual:
                    _sqlBuilder.Append(" <= ");
                    break;
                case ExpressionType.GreaterThan:
                    _sqlBuilder.Append(" > ");
                    break;
                case ExpressionType.GreaterThanOrEqual:
                    _sqlBuilder.Append(" >= ");
                    break;
                default:
                    throw new NotSupportedException($"Binary operator '{node.NodeType}' not supported");
            }

            Visit(node.Right);
            _sqlBuilder.Append(")");
            return node;
        }

        protected override Expression VisitMember(MemberExpression node)
        {
            var property = _metadata.Properties.FirstOrDefault(p =>
                p.Name.Equals(node.Member.Name, StringComparison.OrdinalIgnoreCase));

            if (property == null)
                throw new InvalidOperationException($"Property '{node.Member.Name}' not found in metadata");

            _sqlBuilder.Append(property.ColumnName);
            return node;
        }

        protected override Expression VisitConstant(ConstantExpression node)
        {
            var paramName = $"p{_paramCounter++}";
            _sqlBuilder.Append($"@{paramName}");
            _parameters.Add(paramName, node.Value);
            return node;
        }

        protected override Expression VisitMethodCall(MethodCallExpression node)
        {
            if (node.Method.Name == "Contains" && node.Method.DeclaringType == typeof(Enumerable))
            {
                Visit(node.Arguments[1]); 
                _sqlBuilder.Append(" IN (");

                var collection = (IEnumerable)((ConstantExpression)node.Arguments[0]).Value;
                var first = true;

                foreach (var item in collection)
                {
                    if (!first) _sqlBuilder.Append(", ");
                    var paramName = $"p{_paramCounter++}";
                    _sqlBuilder.Append($"@{paramName}");
                    _parameters.Add(paramName, item);
                    first = false;
                }

                _sqlBuilder.Append(")");
                return node;
            }

            throw new NotSupportedException($"Method '{node.Method.Name}' not supported");
        }
    }
}
