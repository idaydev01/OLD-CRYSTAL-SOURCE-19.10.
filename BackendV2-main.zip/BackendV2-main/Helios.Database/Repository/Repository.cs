﻿using Dapper;
using Helios.Database.Attributes;
using Helios.Database.Mappings;
using Helios.Database.Repository.Json;
using Helios.Database.Repository.Query;
using Helios.Database.Repository.String;
using Helios.Database.Repository.TypeHandlers;
using Helios.Database.Tables;
using Helios.Database.Tables.ContentPages;
using Helios.Database.Tables.Tournaments;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Repository
{
    public class Repository<TEntity> : IDisposable where TEntity : BaseTable, new()
    {
        private readonly string _connectionString;
        private static readonly ConcurrentDictionary<Type, EntityMetadata> _metadataCache = new();
        private static readonly SemaphoreSlim _bulkLock = new(1, 1);
        private const int MaxBatchSize = 50000;

        private readonly EntityMetadata _metadata;
        private readonly string _insertSql;
        private readonly string _insertReturnIdSql;
        private readonly string _deleteBaseSql;
        private readonly string _updateBaseSql;
        private readonly string _findBaseSql;
        private readonly string _findAllBaseSql;

        private readonly Dictionary<string, Func<TEntity, object>> _propertyGetters;
        private readonly Dictionary<string, Action<TEntity, object>> _propertySetters;
        private readonly List<PropertyAccessor<TEntity>> _fastPropertyAccessors;
        private static readonly SemaphoreSlim _bulkInsertSemaphore = new(1, 1);

        private static readonly ConcurrentDictionary<string, NpgsqlDataSource> _dataSources = new();
        private readonly NpgsqlDataSource _dataSource;

        private IMemoryCache _cache;
        private readonly MemoryCacheEntryOptions _defaultCacheOptions;
        private volatile bool _cachingEnabled;
        private readonly string _cacheKeyPrefix;
        private volatile bool _disposed = false;

        private const int MaxCacheSize = 10000;
        private readonly ConcurrentDictionary<string, byte> _cacheKeyTracker = new();

        private static readonly JsonSerializerSettings _jsonSettings = new JsonSerializerSettings
        {
            DateFormatHandling = DateFormatHandling.IsoDateFormat,
            NullValueHandling = NullValueHandling.Include,
            Formatting = Formatting.None 
        };

        public Repository(string connectionString, bool enableCaching = true, TimeSpan? cacheDuration = null)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
            Dapper.DefaultTypeMap.MatchNamesWithUnderscores = true;

            if (!SqlMapper.HasTypeHandler(typeof(List<string>)))
            {
                SqlMapper.AddTypeHandler(new JsonListManager());
            }

            SqlMapper.AddTypeHandler(new DictionaryTypeHandler());
            SqlMapper.AddTypeHandler(new StringDictionaryTypeHandler());

            DapperConfiguration.ConfigureTypeMapping<TournamentInformation>();
            DapperConfiguration.ConfigureTypeMapping<TournamentTemplates>();
            DapperConfiguration.ConfigureTypeMapping<TournamentDedicatedServer>();
            DapperConfiguration.ConfigureTypeMapping<TournamentHistory>();


            if (!SqlMapper.HasTypeHandler(typeof(TEntity)))
            {
                SqlMapper.SetTypeMap(typeof(TEntity), new CustomPropertyTypeMap(typeof(TEntity),
                    (type, columnName) => type.GetProperties().FirstOrDefault(prop =>
                        prop.Name.Equals(columnName, StringComparison.OrdinalIgnoreCase))));
            }

            _metadata = GetMetadata();

            _propertyGetters = new Dictionary<string, Func<TEntity, object>>(_metadata.Properties.Count);
            _propertySetters = new Dictionary<string, Action<TEntity, object>>(_metadata.Properties.Count);
            _fastPropertyAccessors = new List<PropertyAccessor<TEntity>>(_metadata.Properties.Count);

            foreach (var prop in _metadata.Properties)
            {
                _propertyGetters[prop.Name] = CompileGetter(prop.PropertyInfo);
                _propertySetters[prop.Name] = CompileSetter(prop.PropertyInfo);
                _fastPropertyAccessors.Add(new PropertyAccessor<TEntity>(
                    prop,
                    _propertyGetters[prop.Name],
                    _propertySetters[prop.Name]
                ));
            }

            var columns = string.Join(", ", _metadata.InsertProperties.Select(p => p.ColumnName));
            var values = string.Join(", ", _metadata.InsertProperties.Select(p => $"@{p.Name}"));
            var updates = string.Join(", ", _metadata.InsertProperties.Select(p => $"{p.ColumnName} = EXCLUDED.{p.ColumnName}"));

            _insertSql = $"INSERT INTO {_metadata.TableName} ({columns}) VALUES ({values}) ON CONFLICT (id) DO UPDATE SET {updates}";
            _insertReturnIdSql = $"{_insertSql} RETURNING id";
            _deleteBaseSql = $"DELETE FROM {_metadata.TableName} WHERE ";
            _updateBaseSql = $"UPDATE {_metadata.TableName} SET ";
            _findBaseSql = $"SELECT {_metadata.AllColumns} FROM {_metadata.TableName} WHERE ";
            _findAllBaseSql = $"SELECT {_metadata.AllColumns} FROM {_metadata.TableName} WHERE ";

            _dataSource = _dataSources.GetOrAdd(connectionString, cs =>
            {
                var dataSourceBuilder = new NpgsqlDataSourceBuilder(cs);
                dataSourceBuilder.ConnectionStringBuilder.MaxPoolSize = 300;
                dataSourceBuilder.ConnectionStringBuilder.MinPoolSize = 5;
                dataSourceBuilder.ConnectionStringBuilder.Pooling = true;
                dataSourceBuilder.ConnectionStringBuilder.ConnectionIdleLifetime = 300;
                dataSourceBuilder.ConnectionStringBuilder.ConnectionPruningInterval = 10;
                dataSourceBuilder.ConnectionStringBuilder.CommandTimeout = 30;
                return dataSourceBuilder.Build();
            });

            _cachingEnabled = enableCaching;
            _cacheKeyPrefix = $"repo:{typeof(TEntity).Name}:";

            _cache = new MemoryCache(new MemoryCacheOptions
            {
                SizeLimit = MaxCacheSize,
                CompactionPercentage = 0.25, 
                ExpirationScanFrequency = TimeSpan.FromMinutes(1) // Regular cleanup
            });

            _defaultCacheOptions = new MemoryCacheEntryOptions()
                .SetSlidingExpiration(cacheDuration ?? TimeSpan.FromMinutes(5))
                .SetAbsoluteExpiration(TimeSpan.FromMinutes(30)) 
                .SetSize(1)
                .SetPriority(CacheItemPriority.Normal);

        }

        private void OnCacheEntryEvicted(object key, object value, EvictionReason reason, object state)
        {
            if (key is string keyStr)
            {
                _cacheKeyTracker.TryRemove(keyStr, out _);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private async Task<NpgsqlConnection> GetConnectionAsync()
        {
            ThrowIfDisposed();
            try
            {
                var connection = await _dataSource.OpenConnectionAsync().ConfigureAwait(false);
                return connection;
            }
            catch (NpgsqlException ex) when (ex.Message.Contains("connection pool"))
            {
                Logger.Error($"Connection pool exhausted.");
                throw;
            }
        }

        public async Task<TEntity> FindAsync(TEntity template, int timeout = 500, bool useCache = true)
        {
            ThrowIfDisposed();
            var (whereClause, parameters) = BuildFastWhereClause(template);
            if (string.IsNullOrEmpty(whereClause))
                return default;

            var sql = _findBaseSql + whereClause + " LIMIT 1";
            var cacheKey = _cachingEnabled && useCache ? GenerateCacheKey(whereClause, parameters) : null;

            if (_cachingEnabled && useCache && cacheKey != null && _cache.TryGetValue<TEntity>(cacheKey, out var cachedEntity))
            {
                return cachedEntity;
            }

            await using var conn = await GetConnectionAsync();
            try
            {
                var entity = await conn.QueryFirstOrDefaultAsync<TEntity>(
                    sql, parameters, commandTimeout: timeout).ConfigureAwait(false);

                if (_cachingEnabled && useCache && entity != null && cacheKey != null)
                {
                    SetCacheValue(cacheKey, entity);
                }

                return entity;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing FindAsync: {ex.Message}", ex);
                throw;
            }
        }

        public async Task<TEntity> FindByColumnsAsync(IDictionary<string, object> columnValues, int timeout = 500,
            bool useCache = true)
        {
            useCache = useCache && _cachingEnabled;

            ThrowIfDisposed();
            if (columnValues == null || !columnValues.Any())
                throw new ArgumentException("At least one column/value pair must be provided", nameof(columnValues));

            var whereClause = new List<string>();
            var parameters = new DynamicParameters();

            foreach (var kvp in columnValues)
            {
                var property = _metadata.Properties.FirstOrDefault(p =>
                    p.ColumnName.Equals(kvp.Key, StringComparison.OrdinalIgnoreCase) ||
                    p.Name.Equals(kvp.Key, StringComparison.OrdinalIgnoreCase));

                if (property == null)
                    throw new ArgumentException($"Column or property '{kvp.Key}' not found", nameof(columnValues));

                whereClause.Add($"{property.ColumnName} = @{property.ColumnName}");
                parameters.Add(property.ColumnName, ConvertValue(kvp.Value));
            }

            var sql = _findBaseSql + string.Join(" AND ", whereClause) + " LIMIT 1";

            var cacheKeyValues = columnValues.OrderBy(kvp => kvp.Key)
                .Select(kvp => $"{kvp.Key}:{kvp.Value}")
                .ToList();
            var cacheKey = _cachingEnabled && useCache
                ? $"{_cacheKeyPrefix}findby:{string.Join(":", cacheKeyValues)}"
                : null;

            if (_cachingEnabled && useCache && cacheKey != null && _cache.TryGetValue<TEntity>(cacheKey, out var cachedEntity))
            {
                return cachedEntity;
            }

            await using var conn = await GetConnectionAsync();
            try
            {
                var entity = await conn.QueryFirstOrDefaultAsync<TEntity>(
                    sql, parameters, commandTimeout: timeout).ConfigureAwait(false);

                if (_cachingEnabled && useCache && entity != null && cacheKey != null)
                {
                    SetCacheValue(cacheKey, entity);
                }

                return entity;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing FindByColumnsAsync: {ex.Message}", ex);
                throw;
            }
        }

        public async Task PreloadAllAsync(int limit = 50000)
        {
            ThrowIfDisposed();
            var entities = await FindAllByTableAsync(limit, useCache: false).ConfigureAwait(false);
            CacheEntities(entities);

            Logger.Info($"Preloaded {entities.Count} entities for table: {typeof(TEntity).Name}.");
        }

        public async Task<TEntity> FindByColumnsAsync(object columnValues, int timeout = 500, bool useCache = true)
        {
            if (columnValues == null)
                throw new ArgumentNullException(nameof(columnValues));

            var dictionary = new Dictionary<string, object>();
            foreach (var prop in columnValues.GetType().GetProperties())
            {
                dictionary.Add(prop.Name, prop.GetValue(columnValues));
            }

            return await FindByColumnsAsync(dictionary, timeout, useCache).ConfigureAwait(false);
        }


        public async Task<IEnumerable<TEntity>> FindByColumnsWithInClauseAsync(
            IDictionary<string, object> columnValues,
            string inColumnName,
            IEnumerable<object> inValues,
            int timeout = 500,
            bool useCache = true)
        {
            ThrowIfDisposed();

            if (columnValues == null || !columnValues.Any())
                throw new ArgumentException("At least one column/value pair must be provided", nameof(columnValues));

            if (string.IsNullOrWhiteSpace(inColumnName))
                throw new ArgumentException("IN column name must be provided", nameof(inColumnName));

            var inValuesArray = inValues?.ToArray();
            if (inValuesArray == null || !inValuesArray.Any())
                return Enumerable.Empty<TEntity>();

            var whereClause = new List<string>();
            var parameters = new DynamicParameters();

            foreach (var kvp in columnValues)
            {
                var property = _metadata.Properties.FirstOrDefault(p =>
                    p.ColumnName.Equals(kvp.Key, StringComparison.OrdinalIgnoreCase) ||
                    p.Name.Equals(kvp.Key, StringComparison.OrdinalIgnoreCase));

                if (property == null)
                    throw new ArgumentException($"Column or property '{kvp.Key}' not found", nameof(columnValues));

                whereClause.Add($"{property.ColumnName} = @{property.ColumnName}");
                parameters.Add(property.ColumnName, ConvertValue(kvp.Value));
            }

            var inProperty = _metadata.Properties.FirstOrDefault(p =>
                p.ColumnName.Equals(inColumnName, StringComparison.OrdinalIgnoreCase) ||
                p.Name.Equals(inColumnName, StringComparison.OrdinalIgnoreCase));

            if (inProperty == null)
                throw new ArgumentException($"IN column or property '{inColumnName}' not found", nameof(inColumnName));

            var placeholders = string.Join(",", inValuesArray.Select((_, i) => $"@in{i}"));
            whereClause.Add($"{inProperty.ColumnName} IN ({placeholders})");

            for (int i = 0; i < inValuesArray.Length; i++)
            {
                parameters.Add($"in{i}", ConvertValue(inValuesArray[i]), GetDbType(inProperty.Type));
            }

            var sql = _findBaseSql + string.Join(" AND ", whereClause);

            var cacheKeyValues = columnValues.OrderBy(kvp => kvp.Key)
                .Select(kvp => $"{kvp.Key}:{kvp.Value}")
                .ToList();
            cacheKeyValues.Add($"{inColumnName}:IN:[{string.Join(",", inValuesArray)}]");

            var cacheKey = _cachingEnabled && useCache
                ? $"{_cacheKeyPrefix}findwithIN:{string.Join(":", cacheKeyValues)}"
                : null;

            if (_cachingEnabled && useCache && cacheKey != null &&
                _cache.TryGetValue<IEnumerable<TEntity>>(cacheKey, out var cachedEntities))
            {
                return cachedEntities;
            }

            await using var conn = await GetConnectionAsync();
            try
            {
                var entities = await conn.QueryAsync<TEntity>(
                    sql, parameters, commandTimeout: timeout).ConfigureAwait(false);

                if (_cachingEnabled && useCache && entities.Any() && cacheKey != null)
                {
                    SetCacheValue(cacheKey, entities);
                }

                return entities;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing FindByColumnsWithInClauseAsync: {ex.Message}", ex);
                throw;
            }
        }
        public async Task<IEnumerable<TEntity>> FindAllByColumnsAsync(
           IDictionary<string, object> columnValues,
           int timeout = 500,
           bool useCache = false,
           int? limit = null)
        {
            ThrowIfDisposed();

            if (columnValues == null || !columnValues.Any())
                throw new ArgumentException("At least one column/value pair must be provided", nameof(columnValues));

            var validatedProperties = new List<EntityProperty>();
            var parameters = new DynamicParameters();
            var whereClauses = new List<string>();

            foreach (var kvp in columnValues)
            {
                var property = _metadata.Properties.FirstOrDefault(p =>
                    string.Equals(p.ColumnName, kvp.Key, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(p.Name, kvp.Key, StringComparison.OrdinalIgnoreCase));

                if (property == null)
                {
                    throw new ArgumentException($"Column or property '{kvp.Key}' not found", nameof(columnValues));
                }

                validatedProperties.Add(property);
                whereClauses.Add($"{property.ColumnName} = @{property.Name}");
                parameters.Add(property.Name, ConvertValue(kvp.Value));
            }

            string cacheKey = null;
            if (_cachingEnabled && useCache)
            {
                cacheKey = BuildStableCacheKey(validatedProperties, parameters, limit);

                if (_cache.TryGetValue<IEnumerable<TEntity>>(cacheKey, out var cachedResult))
                {
                    return cachedResult;
                }
            }

            var sql = new StringBuilder(_findBaseSql)
                .Append(string.Join(" AND ", whereClauses));

            if (limit.HasValue)
            {
                sql.Append(" LIMIT ").Append(limit.Value);
            }

            await using var conn = await GetConnectionAsync();
            try
            {
                var result = await conn.QueryAsync<TEntity>(
                    sql.ToString(),
                    parameters,
                    commandTimeout: timeout
                );

                var entities = result.AsList();

                if (_cachingEnabled && useCache && cacheKey != null && entities.Count > 0)
                {
                    try
                    {
                        var cacheEntryOptions = new MemoryCacheEntryOptions()
                            .SetSize(1)
                            .SetSlidingExpiration(TimeSpan.FromMinutes(5))
                            .RegisterPostEvictionCallback((key, value, reason, state) =>
                            {
                                _cacheKeyTracker.TryRemove(key.ToString(), out _);
                            });

                        _cache.Set(cacheKey, entities, cacheEntryOptions);
                        _cacheKeyTracker[cacheKey] = 0; 
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Failed to cache result for key {cacheKey}: {ex.Message}");
                    }
                }

                return entities;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing FindAllByColumnsAsync: {ex.Message}");
                throw;
            }
        }

        private string BuildStableCacheKey(
            List<EntityProperty> properties,
            DynamicParameters parameters,
            int? limit)
        {
            if (!_cachingEnabled || properties.Count == 0)
                return null;

            using var sha256 = SHA256.Create();
            var keyBuilder = new StringBuilder(_cacheKeyPrefix)
                .Append("findallby:");

            foreach (var prop in properties.OrderBy(p => p.Name))
            {
                keyBuilder.Append(prop.Name).Append(';');
            }

            var paramValues = string.Join("|",
                parameters.ParameterNames.OrderBy(n => n)
                    .Select(n => $"{n}={parameters.Get<object>(n)}"));

            var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(paramValues));
            keyBuilder.Append("hash=")
                      .Append(BitConverter.ToString(hashBytes).Replace("-", ""));

            if (limit.HasValue)
            {
                keyBuilder.Append(":limit=").Append(limit.Value);
            }

            return keyBuilder.ToString();
        }

        public async Task<IEnumerable<TEntity>> FindAllByColumnsAsync(
            object columnValues,
            int timeout = 500,
            bool useCache = true,
            int? limit = null)
        {
            if (columnValues == null)
                throw new ArgumentNullException(nameof(columnValues));

            var dictionary = new Dictionary<string, object>();
            var properties = columnValues.GetType().GetProperties();

            foreach (var prop in properties)
            {
                try
                {
                    var value = prop.GetValue(columnValues);
                    if (value != null) 
                    {
                        dictionary.Add(prop.Name, value);
                    }
                }
                catch (Exception ex)
                {
                    Logger.Warn($"Failed to get property {prop.Name} from columnValues: {ex.Message}");
                }
            }

            if (!dictionary.Any())
            {
                throw new ArgumentException("No valid properties found in columnValues object", nameof(columnValues));
            }

            return await FindAllByColumnsAsync(dictionary, timeout, useCache, limit).ConfigureAwait(false);
        }

        private string BuildCacheKeyForColumns(
            IDictionary<string, object> columnValues,
            List<EntityProperty> properties,
            int? limit)
        {
            if (!_cachingEnabled || columnValues == null || !columnValues.Any())
                return null;

            var sb = new StringBuilder(_cacheKeyPrefix)
                .Append("findallby:");

            foreach (var prop in properties.OrderBy(p => p.Name))
            {
                if (columnValues.TryGetValue(prop.Name, out var value) ||
                    columnValues.TryGetValue(prop.ColumnName, out value))
                {
                    sb.Append(prop.Name)
                      .Append('=')
                      .Append(value?.ToString() ?? "null")
                      .Append(';');
                }
            }

            if (limit.HasValue)
            {
                sb.Append("limit=").Append(limit.Value);
            }

            sb.Append(":hash=")
              .Append(columnValues.GetHashCode());

            return sb.ToString();
        }

        public async Task<IEnumerable<TEntity>> FindAllByColumnAsync(string columnName, IEnumerable<object> values, int timeout = 500, bool useCache = true)
        {
            ThrowIfDisposed();
            var property = _metadata.Properties.FirstOrDefault(p =>
                p.ColumnName.Equals(columnName, StringComparison.OrdinalIgnoreCase) ||
                p.Name.Equals(columnName, StringComparison.OrdinalIgnoreCase));

            if (property == null)
                throw new ArgumentException($"Column or property '{columnName}' not found", nameof(columnName));

            var valuesArray = values.ToArray();

            var cacheKey = _cachingEnabled && useCache ? $"{_cacheKeyPrefix}findallby:{property.ColumnName}:{string.Join(",", valuesArray)}" : null;

            if (_cachingEnabled && useCache && cacheKey != null && _cache.TryGetValue<IEnumerable<TEntity>>(cacheKey, out var cachedEntities))
            {
                return cachedEntities;
            }

            var placeholders = string.Join(",", valuesArray.Select((_, i) => $"@p{i}"));
            var sql = $"{_findBaseSql}{property.ColumnName} IN ({placeholders})";

            var parameters = new DynamicParameters();
            for (int i = 0; i < valuesArray.Length; i++)
            {
                parameters.Add($"p{i}", ConvertValue(valuesArray[i]), GetDbType(property.Type));
            }

            await using var conn = await GetConnectionAsync();
            try
            {
                var entities = await conn.QueryAsync<TEntity>(
                    sql, parameters, commandTimeout: timeout).ConfigureAwait(false);

                if (_cachingEnabled && useCache && entities.Any() && cacheKey != null)
                {
                    SetCacheValue(cacheKey, entities);
                }

                return entities;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing FindAllByColumnAsync: {ex.Message}", ex);
                throw;
            }
        }

        public async Task<IEnumerable<TEntity>> FindAllByPredicateAsync<TProperty>(
        Expression<Func<TEntity, TProperty>> propertySelector,
            string operation,
            object value,
            int limit = 100,
            int timeout = 500,
            bool useCache = true)
        {
            ThrowIfDisposed();
            if (propertySelector.Body is not MemberExpression memberExpression)
                throw new ArgumentException("Expression must be a property selector", nameof(propertySelector));

            var propertyName = memberExpression.Member.Name;
            var property = _metadata.Properties.FirstOrDefault(p =>
                p.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase));

            if (property == null)
                throw new ArgumentException($"Property '{propertyName}' not found", nameof(propertySelector));

            var cacheKey = _cachingEnabled && useCache ?
                $"{_cacheKeyPrefix}findby:{property.ColumnName}:{operation}:{value}:{limit}" : null;

            if (_cachingEnabled && useCache && cacheKey != null && _cache.TryGetValue<IEnumerable<TEntity>>(cacheKey, out var cachedEntities))
            {
                return cachedEntities;
            }

            string whereClause = operation.ToUpper() switch
            {
                "STARTSWITH" => $"LOWER({property.ColumnName}) LIKE LOWER(@value)",
                "CONTAINS" => $"LOWER({property.ColumnName}) LIKE LOWER(@value)",
                "EQUALS" => $"{property.ColumnName} = @value",
                "NOT_EQUALS" => $"{property.ColumnName} != @value",
                _ => throw new ArgumentException($"Unsupported operation: {operation}")
            };

            var paramValue = operation.ToUpper() switch
            {
                "STARTSWITH" => $"{value}%",
                "CONTAINS" => $"%{value}%",
                _ => value
            };

            var sql = $"{_findBaseSql}{whereClause} ORDER BY {property.ColumnName} LIMIT {limit}";

            var parameters = new DynamicParameters();
            parameters.Add("value", ConvertValue(paramValue), GetDbType(property.Type));

            await using var conn = await GetConnectionAsync();
            try
            {
                var entities = await conn.QueryAsync<TEntity>(
                    sql, parameters, commandTimeout: timeout).ConfigureAwait(false);

                if (_cachingEnabled && useCache && entities.Any() && cacheKey != null)
                {
                    SetCacheValue(cacheKey, entities);
                }

                return entities;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing FindAllByPredicateAsync: {ex.Message}", ex);
                throw;
            }
        }

        public async Task<TEntity> FindByColumnAsync(string columnName, object value, int timeout = 500, bool useCache = true)
        {
            ThrowIfDisposed();
            var property = _metadata.Properties.FirstOrDefault(p =>
                p.ColumnName.Equals(columnName, StringComparison.OrdinalIgnoreCase) ||
                p.Name.Equals(columnName, StringComparison.OrdinalIgnoreCase));

            if (property == null)
                throw new ArgumentException($"Column or property '{columnName}' not found", nameof(columnName));

            var sql = _findBaseSql + property.ColumnName + " = @Value LIMIT 1";
            var parameters = new { Value = ConvertValue(value) };
            var cacheKey = _cachingEnabled && useCache ? $"{_cacheKeyPrefix}findby:{property.ColumnName}:{value}" : null;

            if (_cachingEnabled && useCache && cacheKey != null && _cache.TryGetValue<TEntity>(cacheKey, out var cachedEntity))
            {
                return cachedEntity;
            }

            await using var conn = await GetConnectionAsync();
            try
            {
                var entity = await conn.QueryFirstOrDefaultAsync<TEntity>(
                    sql, parameters, commandTimeout: timeout).ConfigureAwait(false);

                if (_cachingEnabled && useCache && entity != null && cacheKey != null)
                {
                    SetCacheValue(cacheKey, entity);
                }

                return entity;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing FindByColumnAsync: {ex.Message}", ex);
                throw;
            }
        }

        public async Task<bool> DeleteByColumnAsync(
            string columnName,
            object value,
            int timeout = 500,
            bool useCache = true)
        {
            ThrowIfDisposed();
            var property = _metadata.Properties.FirstOrDefault(p =>
                p.ColumnName.Equals(columnName, StringComparison.OrdinalIgnoreCase) ||
                p.Name.Equals(columnName, StringComparison.OrdinalIgnoreCase));

            if (property == null)
                throw new ArgumentException($"Column or property '{columnName}' not found", nameof(columnName));

            var sql = _deleteBaseSql + property.ColumnName + " = @Value";
            var parameters = new { Value = ConvertValue(value) };
            bool deleted = false;

            await using var conn = await GetConnectionAsync();
            try
            {
                var rowsAffected = await conn.ExecuteAsync(
                    sql, parameters, commandTimeout: timeout).ConfigureAwait(false);
                deleted = rowsAffected > 0;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing DeleteByColumnAsync: {ex.Message}", ex);
                throw;
            }

            if (deleted && _cachingEnabled)
            {
                var cacheKey = $"{_cacheKeyPrefix}findby:{property.ColumnName}:{value}";
                _cache.Remove(cacheKey);
                _cacheKeyTracker.TryRemove(cacheKey, out _);
                InvalidateListCaches();
            }

            return deleted;
        }

        public async Task<IEnumerable<TEntity>> QueryAsync(
    Func<IQueryable<TEntity>, IQueryable<TEntity>> query,
    int timeout = 500,
    bool useCache = true)
        {
            ThrowIfDisposed();

            var queryable = new Queryable<TEntity>(_metadata, _connectionString);
            var transformedQuery = query(queryable);

            var querySpec = ((Queryable<TEntity>)transformedQuery).GetQuerySpec();

            var cacheKey = _cachingEnabled && useCache ?
                $"{_cacheKeyPrefix}query:{querySpec.GetCacheKey()}" : null;

            if (_cachingEnabled && useCache && cacheKey != null &&
                _cache.TryGetValue<IEnumerable<TEntity>>(cacheKey, out var cachedEntities))
            {
                return cachedEntities;
            }

            var sql = querySpec.BuildSql(_metadata);

            await using var conn = await GetConnectionAsync();
            try
            {
                var entities = await conn.QueryAsync<TEntity>(
                    sql,
                    querySpec.Parameters,
                    commandTimeout: timeout).ConfigureAwait(false);

                if (_cachingEnabled && useCache && entities.Any() && cacheKey != null)
                {
                    SetCacheValue(cacheKey, entities);
                }

                return entities;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing QueryAsync: {ex.Message}", ex);
                throw;
            }
        }

        private DbType? GetDbType(Type propertyType)
        {
            if (propertyType == typeof(Guid) || propertyType == typeof(Guid?))
                return DbType.Guid;
            if (propertyType == typeof(int) || propertyType == typeof(int?))
                return DbType.Int32;
            if (propertyType == typeof(long) || propertyType == typeof(long?))
                return DbType.Int64;
            if (propertyType == typeof(string))
                return DbType.String;
            if (propertyType == typeof(DateTime) || propertyType == typeof(DateTime?))
                return DbType.DateTime;
            if (propertyType == typeof(bool) || propertyType == typeof(bool?))
                return DbType.Boolean;
            if (propertyType == typeof(decimal) || propertyType == typeof(decimal?))
                return DbType.Decimal;
            if (propertyType == typeof(double) || propertyType == typeof(double?))
                return DbType.Double;

            return null;
        }

        public async Task<int> UpdateAsync(TEntity entity)
        {
            ThrowIfDisposed();

            var keyProp = _metadata.Properties.FirstOrDefault(p => p.IsKey);
            if (keyProp == null)
                throw new InvalidOperationException("Entity must have a primary key defined for updates.");

            var keyValue = _propertyGetters[keyProp.Name](entity);
            if (keyValue == null)
                throw new InvalidOperationException("Primary key value cannot be null for updates.");

            var nonKeyProps = _metadata.Properties.Where(p => !p.IsKey).ToArray();
            if (nonKeyProps.Length == 0)
                throw new InvalidOperationException("No updatable properties found for the entity.");

            var setClause = string.Join(", ", nonKeyProps.Select(p => $"{p.ColumnName} = @{p.Name}"));
            var sql = $"{_updateBaseSql}{setClause} WHERE {keyProp.ColumnName} = @{keyProp.Name}";

            var parameters = new Dictionary<string, object>(nonKeyProps.Length + 1);
            foreach (var prop in nonKeyProps)
            {
                var value = _propertyGetters[prop.Name](entity);
                parameters[prop.Name] = ConvertValue(value);
            }
            parameters[keyProp.Name] = ConvertValue(keyValue);

            await using var conn = await GetConnectionAsync();
            try
            {
                var rowsAffected = await conn.ExecuteAsync(sql, parameters).ConfigureAwait(false);

                if (rowsAffected == 0)
                {
                    var checkSql = $"SELECT COUNT(1) FROM {_metadata.TableName} WHERE {keyProp.ColumnName} = @{keyProp.Name}";
                    var dynamicParams = new Dictionary<string, object>
                    {
                        [keyProp.Name] = ConvertValue(keyValue)
                    };

                    var exists = await conn.ExecuteScalarAsync<int>(checkSql, dynamicParams);
                    if (exists == 0)
                    {
                        throw new InvalidOperationException($"Update failed: No entity found with key '{keyValue}'. The entity may have been deleted by another process.");
                    }
                    else
                    {
                        return 0;
                    }
                }

                if (rowsAffected > 1)
                    throw new InvalidOperationException($"Update failed: Multiple rows ({rowsAffected}) were affected. This indicates a data integrity issue.");

                if (_cachingEnabled)
                {
                    InvalidateEntityCache(entity);
                }

                return rowsAffected;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing UpdateAsync for entity with key '{keyValue}': {ex.Message}", ex);
                throw;
            }
        }

        public async Task<int> DeleteAsync(TEntity template)
        {
            ThrowIfDisposed();
            var (whereClause, parameters) = BuildFastWhereClause(template);

            if (string.IsNullOrEmpty(whereClause))
                throw new InvalidOperationException("No conditions provided for deletion.");

            var sql = _deleteBaseSql + whereClause;
            await using var conn = await GetConnectionAsync();
            int rowsAffected = 0;

            try
            {
                rowsAffected = await conn.ExecuteAsync(sql, parameters).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing DeleteAsync: {ex.Message}", ex);
                throw;
            }

            if (rowsAffected > 0 && _cachingEnabled)
            {
                InvalidateEntityCache(template);
                InvalidateListCaches();
            }

            return rowsAffected;
        }

        public async Task<IEnumerable<TEntity>> FindAllAsync(TEntity template, int limit = 5000, bool useCache = true)
        {
            ThrowIfDisposed();
            var (whereClause, parameters) = BuildFastWhereClause(template);

            var sql = string.IsNullOrEmpty(whereClause)
                ? $"SELECT {_metadata.AllColumns} FROM {_metadata.TableName} LIMIT {limit}"
                : _findAllBaseSql + whereClause + $" LIMIT {limit}";

            var cacheKey = _cachingEnabled && useCache ? GenerateCacheKey("FindAll:" + whereClause, parameters, limit) : null;

            if (_cachingEnabled && useCache && cacheKey != null && _cache.TryGetValue<IEnumerable<TEntity>>(cacheKey, out var cachedEntities))
            {
                return cachedEntities;
            }

            await using var conn = await GetConnectionAsync();
            try
            {
                var entities = await conn.QueryAsync<TEntity>(sql, parameters).ConfigureAwait(false);

                if (_cachingEnabled && useCache && cacheKey != null)
                {
                    SetCacheValue(cacheKey, entities);
                }

                return entities;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing FindAllAsync: {ex.Message}", ex);
                throw;
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public async ValueTask<List<TEntity>> FindAllByTableAsync(int? limit = 5000, bool useCache = true)
        {
            ThrowIfDisposed();

            var cacheKey = _cachingEnabled && useCache
                ? $"{_cacheKeyPrefix}AllByTable:{limit?.ToString() ?? "all"}"
                : null;

            if (cacheKey != null && _cache.TryGetValue<List<TEntity>>(cacheKey, out var cached))
                return cached;

            var sql = limit.HasValue
                ? $"SELECT {_metadata.AllColumns} FROM {_metadata.TableName} LIMIT {limit.Value}"
                : $"SELECT {_metadata.AllColumns} FROM {_metadata.TableName}";

            await using var conn = await GetConnectionAsync().ConfigureAwait(false);
            var result = await conn.QueryAsync<TEntity>(sql, commandTimeout: 30).ConfigureAwait(false);
            var list = result.AsList();

            if (cacheKey != null)
                SetCacheValue(cacheKey, list);

            return list;
        }

        public async Task<List<TEntity>> FindManyAsync(TEntity template, int limit = 1000, bool useCache = true)
        {
            ThrowIfDisposed();
            var (whereClause, parameters) = BuildFastWhereClause(template);

            var sql = string.IsNullOrEmpty(whereClause)
                ? $"SELECT {_metadata.AllColumns} FROM {_metadata.TableName} LIMIT {limit}"
                : $"{_findBaseSql}{whereClause} LIMIT {limit}";

            var cacheKey = _cachingEnabled && useCache ? GenerateCacheKey("FindMany:" + whereClause, parameters, limit) : null;

            if (_cachingEnabled && useCache && cacheKey != null && _cache.TryGetValue<List<TEntity>>(cacheKey, out var cachedEntities))
            {
                return cachedEntities;
            }

            await using var conn = await GetConnectionAsync();
            try
            {
                var result = await conn.QueryAsync<TEntity>(sql, parameters).ConfigureAwait(false);
                var list = result.AsList();

                if (_cachingEnabled && useCache && cacheKey != null)
                {
                    SetCacheValue(cacheKey, list);
                }

                return list;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing FindManyAsync: {ex.Message}", ex);
                throw;
            }
        }

        public async Task<int> SaveAsync(TEntity entity, bool returnId = true)
        {
            ThrowIfDisposed();
            if (_cachingEnabled)
            {
                InvalidateEntityCache(entity);
                InvalidateListCaches();
            }

            var parameters = new Dictionary<string, object>(_metadata.Properties.Count);
            foreach (var accessor in _fastPropertyAccessors)
            {
                var value = accessor.Getter(entity);
                parameters[accessor.Property.Name] = ConvertValue(value);
            }

            await using var conn = await GetConnectionAsync();
            try
            {
                if (returnId)
                {
                    var newId = await conn.ExecuteScalarAsync<int>(_insertReturnIdSql, parameters).ConfigureAwait(false);

                    var idProperty = _metadata.Properties.FirstOrDefault(p => p.IsKey);
                    if (idProperty != null)
                    {
                        _propertySetters[idProperty.Name](entity, newId);
                    }

                    return newId;
                }

                return await conn.ExecuteAsync(_insertSql, parameters).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logger.Error($"Error executing SaveAsync: {ex.Message}", ex);
                throw;
            }
        }

        public async Task BulkSaveAsync(IEnumerable<TEntity> entities)
        {
            if (_cachingEnabled)
            {
                ClearAllCaches();
            }

            var entitiesArray = entities as TEntity[] ?? entities.ToArray();
            if (entitiesArray.Length == 0) return;

            await using var conn = await GetConnectionAsync();
            await using var transaction = await conn.BeginTransactionAsync().ConfigureAwait(false);

            try
            {
                for (int i = 0; i < entitiesArray.Length; i += MaxBatchSize)
                {
                    var remainingCount = Math.Min(MaxBatchSize, entitiesArray.Length - i);

                    await using (var writer = conn.BeginBinaryImport(_metadata.CopyCommand))
                    {
                        for (int j = i; j < i + remainingCount; j++)
                        {
                            try
                            {
                                writer.StartRow();
                                foreach (var prop in _metadata.InsertProperties)
                                {
                                    var value = _propertyGetters[prop.Name](entitiesArray[j]);
                                    WriteValueFast(writer, value, prop.Type);
                                }
                            }
                            catch (Exception rowEx)
                            {
                                Logger.Error($"Failed to write row {j} in batch starting at {i}. Entity: {JsonConvert.SerializeObject(entitiesArray[j])}");
                                throw new InvalidOperationException($"Failed to write row {j}: {rowEx.Message}", rowEx);
                            }
                        }

                        try
                        {
                            await writer.CompleteAsync();
                        }
                        catch (Exception completeEx)
                        {
                            Logger.Error($"Failed to complete binary import for batch starting at {i}. Batch size: {remainingCount}");
                            throw new InvalidOperationException($"Failed to complete binary import: {completeEx.Message}", completeEx);
                        }
                    }
                }

                await transaction.CommitAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                try
                {
                    await transaction.RollbackAsync().ConfigureAwait(false);
                }
                catch (Exception rollbackEx)
                {
                    Logger.Error($"Transaction rollback failed: {rollbackEx.Message}", rollbackEx);
                }

                Logger.Error($"Bulk insert failed for {typeof(TEntity).Name}: {ex.Message}", ex);
                throw new InvalidOperationException(
                    $"Bulk insert failed for {typeof(TEntity).Name}. See inner exception for details.", ex);
            }
        }

        public async Task BulkInsertAsync(IEnumerable<TEntity> entities)
        {
            await _bulkInsertSemaphore.WaitAsync();
            try
            {
                if (_cachingEnabled)
                    ClearAllCaches();

                var entitiesArray = entities as TEntity[] ?? entities.ToArray();
                if (entitiesArray.Length == 0) return;

                await using var conn = await GetConnectionAsync();

                NpgsqlTransaction transaction = null;
                bool ownsTransaction = false;

                if (System.Transactions.Transaction.Current == null)
                {
                    try
                    {
                        transaction = await conn.BeginTransactionAsync();
                        ownsTransaction = true;
                    }
                    catch (InvalidOperationException ex) when (ex.Message.Contains("transaction is already in progress"))
                    {
                        ownsTransaction = false;
                    }
                }

                try
                {
                    for (int i = 0; i < entitiesArray.Length; i += MaxBatchSize)
                    {
                        var remainingCount = Math.Min(MaxBatchSize, entitiesArray.Length - i);

                        await using (var writer = conn.BeginBinaryImport(_metadata.CopyCommand))
                        {
                            for (int j = i; j < i + remainingCount; j++)
                            {
                                writer.StartRow();
                                foreach (var prop in _metadata.InsertProperties)
                                {
                                    var value = _propertyGetters[prop.Name](entitiesArray[j]);
                                    WriteValueFast(writer, value, prop.Type);
                                }
                            }
                            await writer.CompleteAsync();
                        }
                    }

                    if (ownsTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }
                }
                catch (Exception ex)
                {
                    if (ownsTransaction && transaction != null)
                    {
                        try
                        {
                            await transaction.RollbackAsync();
                        }
                        catch (Exception rollbackEx)
                        {
                            Logger.Error($"Transaction rollback failed: {rollbackEx.Message}", rollbackEx);
                        }
                    }

                    Logger.Error($"Bulk insert failed: {ex.Message}", ex);
                    throw new InvalidOperationException("Bulk insert failed. See inner exception.", ex);
                }
                finally
                {
                    if (ownsTransaction && transaction != null)
                    {
                        await transaction.DisposeAsync();
                    }
                }
            }
            finally
            {
                _bulkInsertSemaphore.Release();
            }
        }

        public async Task BulkUpdateAsync(IEnumerable<TEntity> entities)
        {
            if (_cachingEnabled)
            {
                ClearAllCaches();
            }

            var keyProp = _metadata.Properties.FirstOrDefault(p => p.IsKey);
            if (keyProp == null)
                throw new InvalidOperationException("Entity must have a primary key for bulk updates.");

            var entitiesList = entities.ToList();
            if (entitiesList.Count == 0)
                return;

            var nonKeyProps = _metadata.Properties.Where(p => !p.IsKey).ToList();
            if (nonKeyProps.Count == 0)
                return;

            await using var conn = await GetConnectionAsync();
            await using var transaction = await conn.BeginTransactionAsync().ConfigureAwait(false);

            try
            {
                for (int batchOffset = 0; batchOffset < entitiesList.Count; batchOffset += MaxBatchSize)
                {
                    var batchEntities = entitiesList
                        .Skip(batchOffset)
                        .Take(MaxBatchSize)
                        .ToList();

                    var parameters = new DynamicParameters();
                    var valueStrings = new List<string>();

                    for (int i = 0; i < batchEntities.Count; i++)
                    {
                        var entity = batchEntities[i];
                        var keyValue = _propertyGetters[keyProp.Name](entity);
                        if (keyValue == null)
                            throw new InvalidOperationException("Primary key cannot be null for bulk updates.");

                        parameters.Add($"id_{i}", ConvertValue(keyValue));

                        foreach (var prop in nonKeyProps)
                        {
                            var propValue = ConvertValue(_propertyGetters[prop.Name](entity));
                            parameters.Add($"{prop.Name}_{i}", propValue);
                        }

                        var valuePlaceholders = string.Join(", ", nonKeyProps.Select(p => $"@{p.Name}_{i}"));
                        valueStrings.Add($"(@id_{i}, {valuePlaceholders})");
                    }

                    var columns = string.Join(", ", nonKeyProps.Select(p => p.ColumnName));
                    var sql = $@"
                UPDATE {_metadata.TableName} 
                SET 
                    {string.Join(", ", nonKeyProps.Select(p => $"{p.ColumnName} = data.{p.ColumnName}"))}
                FROM (VALUES 
                    {string.Join(", ", valueStrings)}
                ) AS data ({keyProp.ColumnName}, {columns})
                WHERE {_metadata.TableName}.{keyProp.ColumnName} = data.{keyProp.ColumnName}";

                    await conn.ExecuteAsync(sql, parameters, transaction).ConfigureAwait(false);
                }

                await transaction.CommitAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                try
                {
                    await transaction.RollbackAsync().ConfigureAwait(false);
                }
                catch (Exception rollbackEx)
                {
                    Logger.Error($"Transaction rollback failed: {rollbackEx.Message}", rollbackEx);
                }

                throw new InvalidOperationException("Bulk update failed. See inner exception.", ex);
            }
        }

        public async Task<int> BulkDeleteAsync(IEnumerable<TEntity> entities)
        {
            if (_cachingEnabled)
            {
                ClearAllCaches();
            }

            var keyProp = _metadata.Properties.FirstOrDefault(p => p.IsKey);
            if (keyProp == null)
                throw new InvalidOperationException("Entity must have a primary key for bulk deletes.");

            var entitiesList = entities.ToList();
            if (entitiesList.Count == 0)
                return 0;

            await using var conn = await GetConnectionAsync();
            await using var transaction = await conn.BeginTransactionAsync().ConfigureAwait(false);

            try
            {
                int totalDeleted = 0;

                for (int batchOffset = 0; batchOffset < entitiesList.Count; batchOffset += MaxBatchSize)
                {
                    var batchEntities = entitiesList
                        .Skip(batchOffset)
                        .Take(MaxBatchSize)
                        .ToList();

                    var parameters = new DynamicParameters();
                    var idPlaceholders = new List<string>();

                    for (int i = 0; i < batchEntities.Count; i++)
                    {
                        var entity = batchEntities[i];
                        var keyValue = _propertyGetters[keyProp.Name](entity);
                        if (keyValue == null)
                            throw new InvalidOperationException("Primary key cannot be null for bulk deletes.");

                        parameters.Add($"id_{i}", ConvertValue(keyValue));
                        idPlaceholders.Add($"@id_{i}");
                    }

                    var sql = $@"
                DELETE FROM {_metadata.TableName} 
                WHERE {keyProp.ColumnName} IN ({string.Join(", ", idPlaceholders)})";

                    var rowsAffected = await conn.ExecuteAsync(
                        sql,
                        parameters,
                        transaction
                    ).ConfigureAwait(false);

                    totalDeleted += rowsAffected;
                }

                await transaction.CommitAsync().ConfigureAwait(false);
                return totalDeleted;
            }
            catch (Exception ex)
            {
                try
                {
                    await transaction.RollbackAsync().ConfigureAwait(false);
                }
                catch (Exception rollbackEx)
                {
                    Logger.Error($"Transaction rollback failed: {rollbackEx.Message}", rollbackEx);
                }

                Logger.Error($"Bulk delete failed: {ex.Message}", ex);
                throw new InvalidOperationException("Bulk delete failed. See inner exception.", ex);
            }
        }

        public async Task<int> BulkDeleteByColumnAsync(string columnName, IEnumerable<object> values)
        {
            if (_cachingEnabled)
            {
                ClearAllCaches();
            }

            var property = _metadata.Properties.FirstOrDefault(p =>
                p.ColumnName.Equals(columnName, StringComparison.OrdinalIgnoreCase) ||
                p.Name.Equals(columnName, StringComparison.OrdinalIgnoreCase));

            if (property == null)
                throw new ArgumentException($"Column or property '{columnName}' not found", nameof(columnName));

            var valuesArray = values.ToArray();
            if (valuesArray.Length == 0)
                return 0;

            await using var conn = await GetConnectionAsync();
            await using var transaction = await conn.BeginTransactionAsync().ConfigureAwait(false);

            try
            {
                int totalDeleted = 0;

                for (int i = 0; i < valuesArray.Length; i += MaxBatchSize)
                {
                    var batchValues = valuesArray
                        .Skip(i)
                        .Take(MaxBatchSize)
                        .ToArray();

                    var placeholders = string.Join(",", batchValues.Select((_, index) => $"@p{index}"));
                    var sql = $@"
                DELETE FROM {_metadata.TableName} 
                WHERE {property.ColumnName} IN ({placeholders})";

                    var parameters = new DynamicParameters();
                    for (int j = 0; j < batchValues.Length; j++)
                    {
                        parameters.Add($"p{j}", ConvertValue(batchValues[j]), GetDbType(property.Type));
                    }

                    var rowsAffected = await conn.ExecuteAsync(
                        sql,
                        parameters,
                        transaction
                    ).ConfigureAwait(false);

                    totalDeleted += rowsAffected;
                }

                await transaction.CommitAsync().ConfigureAwait(false);
                return totalDeleted;
            }
            catch (Exception ex)
            {
                try
                {
                    await transaction.RollbackAsync().ConfigureAwait(false);
                }
                catch (Exception rollbackEx)
                {
                    Logger.Error($"Transaction rollback failed: {rollbackEx.Message}", rollbackEx);
                }

                Logger.Error($"Bulk delete by column failed: {ex.Message}", ex);
                throw new InvalidOperationException("Bulk delete by column failed. See inner exception.", ex);
            }
        }
        public void SetCacheEnabled(bool enabled)
        {
            _cachingEnabled = enabled;
            if (!enabled)
            {
                _cache.Dispose();
                _cache = new MemoryCache(new MemoryCacheOptions
                {
                    SizeLimit = MaxCacheSize,
                    CompactionPercentage = 0.25,
                    ExpirationScanFrequency = TimeSpan.FromMinutes(1)
                });
                _cacheKeyTracker.Clear();
            }
        }

        public void ClearAllCaches()
        {
            if (_cachingEnabled)
            {
                var oldCache = _cache;
                _cache = new MemoryCache(new MemoryCacheOptions
                {
                    SizeLimit = MaxCacheSize,
                    CompactionPercentage = 0.1
                });

                Task.Run(() =>
                {
                    try
                    {
                        (oldCache as IDisposable)?.Dispose();
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Error disposing old cache: {ex.Message}", ex);
                    }
                });
            }
        }
        public void InvalidateEntityCache(TEntity entity)
        {
            if (!_cachingEnabled) return;

            var idProperty = _metadata.Properties.FirstOrDefault(p => p.IsKey);
            if (idProperty != null)
            {
                var idValue = _propertyGetters[idProperty.Name](entity);
                if (idValue != null)
                {
                    var entityCacheKey = $"{_cacheKeyPrefix}entity:{idValue}";
                    _cache.Remove(entityCacheKey);
                }
            }

            var (whereClause, parameters) = BuildFastWhereClause(entity);
            if (!string.IsNullOrEmpty(whereClause))
            {
                var cacheKeyPattern = GenerateCacheKey(whereClause, parameters, includeSalt: false);
                InvalidateCachesByPattern(cacheKeyPattern);
            }
        }

        private void InvalidateListCaches()
        {
            if (!_cachingEnabled) return;

            var patterns = new[]
            {
                $"{_cacheKeyPrefix}FindAll:",
                $"{_cacheKeyPrefix}FindMany:",
                $"{_cacheKeyPrefix}AllByTable:"
            };

            foreach (var pattern in patterns)
            {
                InvalidateCachesByPattern(pattern);
            }
        }

        private void InvalidateCachesByPattern(string pattern)
        {
            if (_cachingEnabled)
            {
                ClearAllCaches();
            }
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void SetCacheValue<T>(string cacheKey, T value)
        {
            if (!_cachingEnabled || string.IsNullOrEmpty(cacheKey))
                return;

            try
            {
                _cache.Set(cacheKey, value, _defaultCacheOptions);
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to set cache value for key {cacheKey}: {ex.Message}", ex);
            }
        }

        private string GenerateCacheKey(string whereClause, Dictionary<string, object> parameters, int? limit = null, bool includeSalt = false)
        {
            var sb = StringBuilderCache.Acquire(256);
            sb.Append(_cacheKeyPrefix);

            if (whereClause.StartsWith("FindAll:") || whereClause.StartsWith("FindMany:"))
            {
                sb.Append(whereClause);
            }
            else
            {
                sb.Append("entity:");
                sb.Append(whereClause);
            }

            if (parameters != null && parameters.Count > 0)
            {
                sb.Append(':');
                foreach (var param in parameters.OrderBy(p => p.Key))
                {
                    sb.Append(param.Key)
                      .Append('=');

                    if (param.Value != null)
                    {
                        var valueStr = param.Value.ToString();
                        if (valueStr.Length > 50)
                        {
                            sb.Append(valueStr.Substring(0, 50));
                        }
                        else
                        {
                            sb.Append(valueStr);
                        }
                    }
                    else
                    {
                        sb.Append("null");
                    }

                    sb.Append(';');
                }
            }

            if (limit.HasValue)
            {
                sb.Append(":limit=")
                  .Append(limit.Value);
            }

   
            if (includeSalt && parameters?.Count > 0)
            {
                sb.Append(":h=")
                  .Append(whereClause.GetHashCode() ^ (parameters.Count * 31));
            }

            return StringBuilderCache.GetStringAndRelease(sb);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private (string, Dictionary<string, object>) BuildFastWhereClause(TEntity template)
        {
            var parameters = new Dictionary<string, object>();
            var sb = StringBuilderCache.Acquire(128);
            var first = true;

            foreach (var accessor in _fastPropertyAccessors)
            {
                if (accessor.Property.IsKey) continue;

                var value = accessor.Getter(template);
                if (IsDefaultValue(value)) continue;

                if (first)
                    first = false;
                else
                    sb.Append(" AND ");

                sb.Append(accessor.Property.ColumnName);
                sb.Append(" = @");
                sb.Append(accessor.Property.Name);

                parameters[accessor.Property.Name] = ConvertValue(value);
            }

            return first ? ("", parameters) : (StringBuilderCache.GetStringAndRelease(sb), parameters);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void WriteValueFast(NpgsqlBinaryImporter writer, object value, Type propertyType)
        {
            if (value == null)
            {
                writer.WriteNull();
                return;
            }

            if (propertyType.IsGenericType && propertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
            {
                propertyType = Nullable.GetUnderlyingType(propertyType);
            }

            try
            {
                if (propertyType == typeof(string))
                {
                    writer.Write((string)value);
                    return;
                }
                if (propertyType == typeof(int))
                {
                    writer.Write(Convert.ToInt32(value));
                    return;
                }
                if (propertyType == typeof(long))
                {
                    writer.Write(Convert.ToInt64(value));
                    return;
                }
                if (propertyType == typeof(decimal))
                {
                    writer.Write(Convert.ToDecimal(value));
                    return;
                }
                if (propertyType == typeof(double))
                {
                    writer.Write(Convert.ToDouble(value));
                    return;
                }
                if (propertyType == typeof(float))
                {
                    writer.Write(Convert.ToSingle(value));
                    return;
                }
                if (propertyType == typeof(bool))
                {
                    writer.Write(Convert.ToBoolean(value));
                    return;
                }
                if (propertyType == typeof(DateTime))
                {
                    writer.Write(Convert.ToDateTime(value));
                    return;
                }
                if (propertyType == typeof(DateTimeOffset))
                {
                    writer.Write((DateTimeOffset)value);
                    return;
                }
                if (propertyType == typeof(Guid))
                {
                    writer.Write((Guid)value);
                    return;
                }
                if (propertyType.IsEnum)
                {
                    writer.Write(Convert.ToInt32(value));
                    return;
                }
                if (propertyType.IsGenericType && propertyType.GetGenericTypeDefinition() == typeof(List<>))
                {
                    var json = JsonConvert.SerializeObject(value);
                    writer.Write(json, NpgsqlDbType.Jsonb);
                    return;
                }
                if (propertyType.Namespace?.StartsWith("Helios.Database.Tables") == true)
                {
                    var json = JsonConvert.SerializeObject(value);
                    writer.Write(json, NpgsqlDbType.Jsonb);
                    return;
                }
                if (value is System.Collections.IEnumerable && propertyType != typeof(string))
                {
                    var json = JsonConvert.SerializeObject(value);
                    writer.Write(json, NpgsqlDbType.Jsonb);
                    return;
                }

                var stringValue = value.ToString();
                if (string.IsNullOrEmpty(stringValue))
                {
                    writer.WriteNull();
                }
                else
                {
                    writer.Write(stringValue);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to write value '{value}' of type {value.GetType()} for property type {propertyType}: {ex.Message}");
                throw new InvalidOperationException($"Cannot write value '{value}' of type {value.GetType()} to column expecting {propertyType}", ex);
            }
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private bool IsDefaultValue(object value)
        {
            if (value == null) return true;

            var type = value.GetType();
            if (!type.IsValueType) return false;

            if (type == typeof(int)) return (int)value == 0;
            if (type == typeof(long)) return (long)value == 0;
            if (type == typeof(bool)) return (bool)value == false;
            if (type == typeof(DateTime)) return (DateTime)value == default;
            if (type == typeof(float)) return (float)value == 0;
            if (type == typeof(double)) return (double)value == 0;
            if (type == typeof(decimal)) return (decimal)value == 0;
            if (type == typeof(Guid)) return (Guid)value == Guid.Empty;

            return value.Equals(Activator.CreateInstance(type));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private object ConvertValue(object value)
        {
            if (value == null) return null;

            var type = value.GetType();

            if (type.IsEnum)
                return Convert.ToInt32(value);

            if (type.IsArray)
                return value;

            if (value is System.Collections.IEnumerable enumerable && type != typeof(string))
            {
                return JsonConvert.SerializeObject(enumerable, _jsonSettings);
            }

            if (type.Namespace?.StartsWith("Helios.Database.Tables") == true)
            {
                return JsonConvert.SerializeObject(value, _jsonSettings);
            }

            return value;
        }

        private EntityMetadata GetMetadata()
        {
            return _metadataCache.GetOrAdd(typeof(TEntity), t =>
            {
                var props = t.GetProperties()
                    .Select(p => new EntityProperty(
                        p.Name,
                        p.GetCustomAttribute<ColumnAttribute>()?.ColumnName ?? p.Name.ToSnakeCase(),
                        p.PropertyType,
                        p.GetCustomAttributes(typeof(KeyAttribute), false).Any(),
                        p
                    )).ToList();

                var insertProperties = props.Where(p => !p.IsKey).ToList();

                return new EntityMetadata(
                    TableName: EntityMapper.GetTableName(new TEntity()),
                    AllColumns: string.Join(", ", props.Select(p => p.ColumnName)),
                    CopyCommand: $"COPY {EntityMapper.GetTableName(new TEntity())} ({string.Join(", ", insertProperties.Select(p => p.ColumnName))}) FROM STDIN (FORMAT BINARY)",
                    Properties: props,
                    InsertProperties: insertProperties
                );
            });
        }

        private Func<TEntity, object> CompileGetter(PropertyInfo propertyInfo)
        {
            var parameter = Expression.Parameter(typeof(TEntity), "obj");
            var property = Expression.Property(Expression.Convert(parameter, propertyInfo.DeclaringType), propertyInfo);
            var convert = Expression.Convert(property, typeof(object));

            return Expression.Lambda<Func<TEntity, object>>(convert, parameter).Compile();
        }

        private Action<TEntity, object> CompileSetter(PropertyInfo propertyInfo)
        {
            var objParam = Expression.Parameter(typeof(TEntity), "obj");
            var valueParam = Expression.Parameter(typeof(object), "value");
            var convertedValue = Expression.Convert(valueParam, propertyInfo.PropertyType);
            var propertyAccess = Expression.Property(objParam, propertyInfo);
            var assign = Expression.Assign(propertyAccess, convertedValue);
            return Expression.Lambda<Action<TEntity, object>>(assign, objParam, valueParam).Compile();
        }

        public void SetCacheDuration(TimeSpan duration)
        {
            _defaultCacheOptions.SlidingExpiration = duration;
        }

        public void CacheEntity(TEntity entity)
        {
            if (!_cachingEnabled) return;

            var idProperty = _metadata.Properties.FirstOrDefault(p => p.IsKey);
            if (idProperty == null) return;

            var idValue = _propertyGetters[idProperty.Name](entity);
            if (idValue == null) return;

            var cacheKey = $"{_cacheKeyPrefix}entity:{idValue}";
            _cache.Set(cacheKey, entity, _defaultCacheOptions);
        }

        public void CacheEntities(IEnumerable<TEntity> entities)
        {
            if (!_cachingEnabled) return;

            var idProperty = _metadata.Properties.FirstOrDefault(p => p.IsKey);
            if (idProperty == null) return;

            foreach (var entity in entities)
            {
                var idValue = _propertyGetters[idProperty.Name](entity);
                if (idValue == null) continue;

                var cacheKey = $"{_cacheKeyPrefix}entity:{idValue}";
                _cache.Set(cacheKey, entity, _defaultCacheOptions);
            }
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void ThrowIfDisposed()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(nameof(Repository<TEntity>));
            }
        }

        public void Dispose()
        {
            if (_disposed)
                return;

            _disposed = true;

            try
            {
                (_cache as IDisposable)?.Dispose();
            }
            catch (Exception ex)
            {
                Logger.Error($"Error disposing cache: {ex.Message}", ex);
            }

            try
            {
                _bulkInsertSemaphore?.Dispose();
            }
            catch (Exception ex)
            {
                Logger.Error($"Error disposing semaphore: {ex.Message}", ex);
            }

            _cacheKeyTracker.Clear();
        }
    }
}