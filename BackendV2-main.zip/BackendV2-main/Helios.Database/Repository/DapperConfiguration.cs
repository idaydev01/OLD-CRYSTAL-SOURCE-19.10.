﻿using Dapper;
using System.Reflection;
using Helios.Database.Attributes;

namespace Helios.Database.Repository
{
    public static class DapperConfiguration
    {
        public static void ConfigureTypeMapping<T>() where T : class
        {
            var map = new CustomPropertyTypeMap(typeof(T), (type, columnName) =>
            {
                return type.GetProperties().FirstOrDefault(prop =>
                {
                    var columnAttr = prop.GetCustomAttribute<ColumnAttribute>();
                    if (columnAttr != null)
                    {
                        return columnAttr.ColumnName.Equals(columnName, StringComparison.OrdinalIgnoreCase);
                    }

                    return prop.Name.Equals(columnName, StringComparison.OrdinalIgnoreCase);
                });
            });

            SqlMapper.SetTypeMap(typeof(T), map);
        }
    }
}
