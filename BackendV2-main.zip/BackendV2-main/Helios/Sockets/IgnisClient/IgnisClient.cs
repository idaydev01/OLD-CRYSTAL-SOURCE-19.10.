﻿using Fleck;
using Helios.Utilities;
using System.Collections.Concurrent;

namespace Helios.Sockets.IgnisClient;

public class IgnisClient : IDisposable
{
    private const int MaxConnections = 7000;
    private const int HeartbeatIntervalMs = 30000;
    private const int CleanupIntervalMs = 60000;

    private WebSocketServer? _server;
    private readonly ConnectionManager _connectionManager;
    private readonly MessageHandler _messageHandler;
    private readonly SemaphoreSlim _connectionSemaphore;
    private Timer? _heartbeatTimer;
    private Timer? _cleanupTimer;
    private CancellationTokenSource? _cancellationSource;
    private volatile bool _disposed = false;

    public IgnisClient()
    {
        _connectionSemaphore = new SemaphoreSlim(MaxConnections, MaxConnections);
        _connectionManager = new ConnectionManager();
        _messageHandler = new MessageHandler(_connectionManager);
    }

    public async Task StartAsync(CancellationToken cancellationToken = default)
    {
        if (_disposed) throw new ObjectDisposedException(nameof(IgnisClient));

        _cancellationSource = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

        _server = new WebSocketServer("ws://0.0.0.0:9999")
        {
            RestartAfterListenError = true,
            ListenerSocket = { NoDelay = true }
        };

        _server.Start(socket => ConfigureSocket(socket, _cancellationSource.Token));

        StartTimers();
        _ = Task.Run(() => _connectionManager.MonitorConnectionsAsync(_cancellationSource.Token));

        Logger.Info($"Ignis WebSocket Server started on ws://0.0.0.0:9999 (Max: {MaxConnections})");
    }

    private void ConfigureSocket(IWebSocketConnection socket, CancellationToken ct)
    {
        socket.ConnectionInfo.Headers["Server"] = "IgnisWebSocket/1.0";
        socket.OnOpen = () => _ = HandleConnectionAsync(socket, ct);
        socket.OnClose = () => _connectionManager.RemoveConnection(socket.ConnectionInfo.Id);
        socket.OnMessage = msg => _ = _messageHandler.HandleMessageAsync(socket, msg, ct);
        socket.OnError = ex => _connectionManager.HandleError(socket, ex);
    }

    private async Task HandleConnectionAsync(IWebSocketConnection socket, CancellationToken ct)
    {
        if (!await _connectionSemaphore.WaitAsync(0) || ct.IsCancellationRequested)
        {
            socket.Close();
            return;
        }

        try
        {
            await _connectionManager.AddConnectionAsync(socket);
        }
        finally
        {
            _connectionSemaphore.Release();
        }
    }

    private void StartTimers()
    {
        _heartbeatTimer = new Timer(_ => _connectionManager.SendHeartbeat(),
            null, HeartbeatIntervalMs, HeartbeatIntervalMs);
        _cleanupTimer = new Timer(_ => _connectionManager.Cleanup(),
            null, CleanupIntervalMs, CleanupIntervalMs);
    }

    public int GetConnectedClientCount() => _connectionManager.GetConnectionCount();
    public bool IsClientConnected(Guid id) => _connectionManager.IsConnected(id);
    public Task SendToClient(Guid id, string message) => _connectionManager.SendToClient(id, message);
    public Task SendToAllClients(string message) => _connectionManager.SendToAllClients(message);

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        _cancellationSource?.Cancel();
        _heartbeatTimer?.Dispose();
        _cleanupTimer?.Dispose();
        _connectionManager?.Dispose();
        _connectionSemaphore?.Dispose();
        _server?.Dispose();
        _cancellationSource?.Dispose();
    }
}