using Helios.Configuration;
using Helios.Database.Tables.Stats;
using Helios.Database.Tables.Tournaments;
using Helios.Sockets.IgnisClient.Classes;
using Helios.Utilities;

namespace Helios.Sockets.IgnisClient;

public class CacheManager
{
    private readonly SemaphoreSlim _leaderboardLock = new(1, 1);
    private List<LeaderboardEntry>? _cachedLeaderboard;
    private DateTime _lastUpdate = DateTime.MinValue;
    private static readonly TimeSpan CacheExpiry = TimeSpan.FromMinutes(5);

    public async Task<List<LeaderboardEntry>?> GetLeaderboardAsync()
    {
        await _leaderboardLock.WaitAsync();
        try
        {
            if (_cachedLeaderboard != null && DateTime.UtcNow - _lastUpdate < CacheExpiry)
                return _cachedLeaderboard;

            return await RefreshLeaderboardAsync();
        }
        finally
        {
            _leaderboardLock.Release();
        }
    }

    private async Task<List<LeaderboardEntry>?> RefreshLeaderboardAsync()
    {
        try
        {
            var statsRepo = Constants.repositoryPool.For<Stats>();
            var hypeRepo = Constants.repositoryPool.For<TournamentHype>();

            var stats = await statsRepo.FindAllByPredicateAsync(s => s.AccountId, "NOT_EQUALS", "", limit: int.MaxValue);
            var hype = await hypeRepo.FindAllByTableAsync(limit: null);

            var hypeDict = hype.Where(h => !string.IsNullOrWhiteSpace(h.AccountId))
                .GroupBy(h => h.AccountId.Trim())
                .ToDictionary(g => g.Key, g => g.Sum(h => h.Hype));

            var usernames = stats.Where(s => !string.IsNullOrWhiteSpace(s.AccountId) &&
                                           !string.IsNullOrWhiteSpace(s.Username) &&
                                           s.Username.Trim() != "InvalidSocketUser")
                .GroupBy(s => s.AccountId.Trim())
                .ToDictionary(g => g.Key, g => g.OrderByDescending(s => s.Id).First().Username.Trim());

            _cachedLeaderboard = hypeDict.Where(kvp => kvp.Value > 0)
                .Select(kvp => new LeaderboardEntry
                {
                    AccountId = kvp.Key,
                    Username = usernames.TryGetValue(kvp.Key, out var name) ? name : "UnknownUser",
                    Hype = kvp.Value
                })
                .OrderByDescending(e => e.Hype)
                .Take(25)
                .ToList();

            _lastUpdate = DateTime.UtcNow;
            return _cachedLeaderboard;
        }
        catch (Exception ex)
        {
            Logger.Error($"Leaderboard refresh failed: {ex}");
            return _cachedLeaderboard;
        }
    }
}