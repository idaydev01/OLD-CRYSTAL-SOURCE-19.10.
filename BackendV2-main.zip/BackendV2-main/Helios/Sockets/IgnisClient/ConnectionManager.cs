using Fleck;
using Helios.Sockets.IgnisClient.Classes;
using Helios.Utilities;
using Newtonsoft.Json;
using System.Collections.Concurrent;

namespace Helios.Sockets.IgnisClient;

public class ConnectionManager : IDisposable
{
    private readonly ConcurrentDictionary<Guid, Helios.Sockets.IgnisClient.Classes.ConnectionInfo> _connections = new();
    private volatile bool _disposed = false;

    public async Task AddConnectionAsync(IWebSocketConnection socket)
    {
        if (string.IsNullOrEmpty(socket.ConnectionInfo.ClientIpAddress) ||
            !await ClientValidation.ValidateTokenFromQuery(socket))
        {
            socket.Close();
            return;
        }

        var info = new Helios.Sockets.IgnisClient.Classes.ConnectionInfo
        {
            Socket = socket,
            LastActivity = DateTime.UtcNow,
            ConnectedAt = DateTime.UtcNow
        };

        _connections.TryAdd(socket.ConnectionInfo.Id, info);
        Logger.Debug($"Client connected: {socket.ConnectionInfo.Id}");
    }

    public void RemoveConnection(Guid id)
    {
        if (_connections.TryRemove(id, out var info))
        {
            var duration = DateTime.UtcNow - info.ConnectedAt;
            Logger.Debug($"Client disconnected: {id} after {duration:mm\\:ss}");
        }
    }

    public void HandleError(IWebSocketConnection socket, Exception ex)
    {
        Logger.Debug($"Socket error for {socket.ConnectionInfo.Id}: {ex.Message}");
        RemoveConnection(socket.ConnectionInfo.Id);
        SafeClose(socket);
    }

    public async Task SendToClient(Guid id, string message)
    {
        if (!_connections.TryGetValue(id, out var info) || !info.IsHealthy) return;

        try
        {
            await info.Socket.Send(message);
            info.LastActivity = DateTime.UtcNow;
        }
        catch (Exception ex)
        {
            Logger.Debug($"Send failed to {id}: {ex.Message}");
            RemoveConnection(id);
        }
    }

    public async Task SendToAllClients(string message)
    {
        var tasks = _connections.Keys.Select(id => SendToClient(id, message));
        await Task.WhenAll(tasks);
    }

    public void SendHeartbeat()
    {
        var ping = JsonConvert.SerializeObject(new { type = "heartbeat", timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() });
        _ = Task.Run(() => SendToAllClients(ping));
    }

    public async Task MonitorConnectionsAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested && !_disposed)
        {
            try
            {
                var stale = _connections.Where(kvp =>
                    !kvp.Value.IsHealthy ||
                    DateTime.UtcNow - kvp.Value.LastActivity > TimeSpan.FromMinutes(5))
                    .Select(kvp => kvp.Key).ToList();

                foreach (var id in stale)
                {
                    if (_connections.TryRemove(id, out var info))
                        SafeClose(info.Socket);
                }

                await Task.Delay(60000, ct);
            }
            catch (Exception ex)
            {
                Logger.Error($"Monitor error: {ex}");
                await Task.Delay(30000, ct);
            }
        }
    }

    public async Task BroadcastToLauncherClients(string message)
    {
        try
        {
            var launcherSessions = await LauncherSessionsManager.ListAllLauncherSessions();
            var broadcastTasks = new List<Task>();

            foreach (var session in launcherSessions.Where(s => s.Protocol == "launcher" && s.IsAuthenticated))
            {
                broadcastTasks.Add(SendToClient(session.SocketId, message));
            }

            if (broadcastTasks.Any())
            {
                await Task.WhenAll(broadcastTasks);
                Logger.Info($"Broadcasted message to {broadcastTasks.Count} launcher clients");
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Error broadcasting to launcher clients: {ex.Message}");
        }
    }

    public void Cleanup()
    {
        var healthy = _connections.Count(c => c.Value.IsHealthy);
        Logger.Debug($"Connections: {healthy}/{_connections.Count} healthy");
        if (_connections.Count > 1000) GC.Collect();
    }

    public int GetConnectionCount() => _connections.Count;
    public bool IsConnected(Guid id) => _connections.TryGetValue(id, out var info) && info.IsHealthy;

    private static void SafeClose(IWebSocketConnection socket)
    {
        try { socket?.Close(); } catch { }
    }

    public void Dispose()
    {
        _disposed = true;
        foreach (var info in _connections.Values)
            SafeClose(info.Socket);
        _connections.Clear();
    }
}