using Newtonsoft.Json;
using System.Text.Json;

namespace Helios.Sockets.IgnisClient.Classes.Message;

public class IncomingWebSocketMessage
{
    [JsonProperty("type")]
    public string Type { get; set; } = string.Empty;
    [JsonProperty("payload")]
    public JsonElement Payload { get; set; }
    [JsonProperty("id")]
    public string? MessageId { get; set; }
}
