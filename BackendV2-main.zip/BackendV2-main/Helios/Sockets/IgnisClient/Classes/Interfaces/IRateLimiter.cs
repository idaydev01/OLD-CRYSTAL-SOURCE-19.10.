namespace Helios.Sockets.IgnisClient.Classes.Interfaces
{
    public interface IRateLimiter
    {
        bool IsAllowed(Guid clientId);
        void Cleanup();
    }
}