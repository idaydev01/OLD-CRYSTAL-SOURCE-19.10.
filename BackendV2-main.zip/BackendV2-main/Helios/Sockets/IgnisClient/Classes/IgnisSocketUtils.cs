using Fleck;
using Helios.Utilities;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using System.Text.Json;

namespace Helios.Sockets.IgnisClient.Classes;

public static class IgnisSocketUtils
{
    public static bool SendToClient(ConcurrentDictionary<Guid, IWebSocketConnection> connections, Guid connectionId, string message)
    {
        if (connections.TryGetValue(connectionId, out var connection))
        {
            try
            {
                connection.Send(message);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to send message to {connectionId}: {ex}");
                connections.TryRemove(connectionId, out _);
                return false;
            }
        }
        return false;
    }

    public static bool SendJsonToClient(ConcurrentDictionary<Guid, IWebSocketConnection> connections, Guid connectionId, object obj)
    {
        try
        {
            var json = JsonConvert.SerializeObject(obj);
            return SendToClient(connections, connectionId, json);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to serialize object for client {connectionId}: {ex}");
            return false;
        }
    }

    public static int SendToAllClients(ConcurrentDictionary<Guid, IWebSocketConnection> connections, string message)
    {
        var disconnectedClients = new List<Guid>();
        var successCount = 0;

        foreach (var kvp in connections)
        {
            try
            {
                kvp.Value.Send(message);
                successCount++;
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to send broadcast message to {kvp.Key}: {ex}");
                disconnectedClients.Add(kvp.Key);
            }
        }

        foreach (var clientId in disconnectedClients)
        {
            connections.TryRemove(clientId, out _);
        }

        return successCount;
    }

    public static int SendJsonToAllClients(ConcurrentDictionary<Guid, IWebSocketConnection> connections, object obj)
    {
        try
        {
            var json = JsonConvert.SerializeObject(obj);
            return SendToAllClients(connections, json);
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to serialize object for broadcast: {ex}");
            return 0;
        }
    }

    public static void DisconnectClient(ConcurrentDictionary<Guid, IWebSocketConnection> connections, Guid connectionId, string? reason = null)
    {
        if (connections.TryRemove(connectionId, out var connection))
        {
            try
            {
                if (!string.IsNullOrEmpty(reason))
                {
                    Logger.Info($"Disconnecting client {connectionId}: {reason}");
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                Logger.Error($"Error disconnecting client {connectionId}: {ex}");
            }
        }
    }

    public static bool SendErrorResponse(ConcurrentDictionary<Guid, IWebSocketConnection> connections, Guid connectionId, string errorMessage, string? messageId = null)
    {
        var errorResponse = new
        {
            type = "error",
            timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
            message = errorMessage,
            id = messageId
        };

        return SendJsonToClient(connections, connectionId, errorResponse);
    }

    public static bool SendSuccessResponse(ConcurrentDictionary<Guid, IWebSocketConnection> connections, Guid connectionId, string responseType, object? payload = null, string? messageId = null)
    {
        var response = new
        {
            type = responseType,
            timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
            payload,
            id = messageId
        };

        return SendJsonToClient(connections, connectionId, response);
    }

    public static int GetConnectedClientCount(ConcurrentDictionary<Guid, IWebSocketConnection> connections)
    {
        return connections.Count;
    }

    public static List<Guid> GetConnectedClientIds(ConcurrentDictionary<Guid, IWebSocketConnection> connections)
    {
        return connections.Keys.ToList();
    }

    public static bool IsClientConnected(ConcurrentDictionary<Guid, IWebSocketConnection> connections, Guid connectionId)
    {
        return connections.ContainsKey(connectionId);
    }
}