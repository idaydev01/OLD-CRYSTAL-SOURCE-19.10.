using Newtonsoft.Json;

namespace Helios.Sockets.IgnisClient.Classes;

public static class LeaderboardHelper
{
    public static string GenerateLeaderboardHash(List<LeaderboardEntry> leaderboard)
    {
        using var sha256 = System.Security.Cryptography.SHA256.Create();
        var jsonString = JsonConvert.SerializeObject(leaderboard, Formatting.None);
        var hashBytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(jsonString));
        return Convert.ToBase64String(hashBytes);
    }
}