namespace Helios.Sockets.Hermes.Interfaces;

public interface IHttpClientFactory
{
    HttpClient CreateClient();
}