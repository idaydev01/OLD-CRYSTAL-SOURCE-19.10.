namespace Helios.Sockets.Hermes.Responses;

public class ErrorResponse
{
    public string Error { get; set; } = string.Empty;
    public int Status { get; set; }
    public string Details { get; set; } = string.Empty;
}
