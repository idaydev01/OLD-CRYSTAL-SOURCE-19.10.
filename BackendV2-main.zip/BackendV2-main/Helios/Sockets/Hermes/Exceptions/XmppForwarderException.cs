namespace Helios.Sockets.Hermes.Exceptions;

public class XmppForwarderException : Exception
{
    public int? StatusCode { get; }
    public string? ErrorCode { get; }

    public XmppForwarderException(string message) : base(message) { }
    public XmppForwarderException(string message, Exception innerException) : base(message, innerException) { }
    public XmppForwarderException(string message, int statusCode, string? errorCode = null) : base(message)
    {
        StatusCode = statusCode;
        ErrorCode = errorCode;
    }
}