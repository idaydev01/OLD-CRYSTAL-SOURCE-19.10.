﻿using Discord;
using Discord.WebSocket;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Interfaces;
using Helios.Utilities;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;

namespace Helios.Discord.Commands;

public class Ban : ISlashCommand
{
    public string Name => "ban";
    public string Description => "Bans a user from crystal.";

    public List<SlashCommandOptionBuilder> Options => new List<SlashCommandOptionBuilder>
    {
        new SlashCommandOptionBuilder()
            .WithName("user")
            .WithDescription("The Discord user you want to ban.")
            .WithType(ApplicationCommandOptionType.User)
            .WithRequired(false),
        new SlashCommandOptionBuilder()
            .WithName("username")
            .WithDescription("The username of the user you want to ban.")
            .WithType(ApplicationCommandOptionType.String)
            .WithRequired(false),
        new SlashCommandOptionBuilder()
            .WithName("reason")
            .WithDescription("The reason for the ban.")
            .WithType(ApplicationCommandOptionType.String)
            .WithRequired(false)
    };

    public async Task BuildAsync(SocketSlashCommand command)
    {
        try
        {
            if (command == null)
            {
                await RespondAsync("Command is null, please try again.", Color.Red, command);
                return;
            }

            var options = command.Data.Options.ToList();
            var user = options.FirstOrDefault(x => x.Name == "user")?.Value as SocketUser;
            var username = options.FirstOrDefault(x => x.Name == "username")?.Value as string;
            var reason = options.FirstOrDefault(x => x.Name == "reason")?.Value as string ?? "No reason provided";

            if ((user != null && !string.IsNullOrEmpty(username)) || (user == null && string.IsNullOrEmpty(username)))
            {
                await RespondAsync("Please provide either a Discord user **or** a username, not both or neither.", Color.Red, command);
                return;
            }

            var socketUser = command.User as SocketGuildUser;
            if (socketUser == null)
            {
                await RespondAsync("You do not have the necessary permissions to use this command.", Color.Red, command);
                return;
            }

            var allowedRoles = new[] { "Owner", "Co Owner", "Admin", "Manager", "Developer", "Media Manager", "Founder", "Head Admin" };
            bool hasRequiredRole = socketUser.Roles.Any(role => allowedRoles.Contains(role.Name));

            if (!hasRequiredRole)
            {
                await RespondAsync("You do not have the necessary permissions to use this command.", Color.Red, command);
                return;
            }

            var userRepository = Constants.repositoryPool.For<User>();
            var bansRepository = Constants.repositoryPool.For<Helios.Database.Tables.AntiCheat.Ban>();
            var hardwaresRepository = Constants.repositoryPool.For<Hardwares>();
            var tokensRepository = Constants.repositoryPool.For<Tokens>();

            User userToBan = null;
            string displayName = "";

            if (user != null)
            {
                userToBan = await userRepository.FindByColumnAsync("discordid", user.Id.ToString());
                displayName = user.Username;
            }
            else if (!string.IsNullOrEmpty(username))
            {
                userToBan = await userRepository.FindByColumnAsync("username", username);
                displayName = username;
            }

            if (userToBan == null)
            {
                await RespondAsync($"The user '{displayName}' could not be found in the database.", Color.Red, command);
                return;
            }

            var accessToken = await tokensRepository.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "accountid", userToBan.AccountId },
                { "type", "accesstoken" }
            });

            if (accessToken != null)
            {
                Logger.Info($"Disconnecting user with token '{accessToken.Token}' and accountId: {userToBan.AccountId}");
                try
                {
                    using var httpClient = new HttpClient();
                    var disconnectEndpoint = "http://54.242.107.17:2095/api/v1/dash/disconnect";
                    var requestData = new
                    {
                        token = Constants.ArsenicToken,
                        authToken = accessToken.Token
                    };

                    var content = new StringContent(
                        JsonConvert.SerializeObject(requestData, Formatting.None),
                        Encoding.UTF8,
                        "application/json"
                    );

                    var response = await httpClient.PostAsync(disconnectEndpoint, content);
                    if (!response.IsSuccessStatusCode)
                    {
                        Logger.Warn($"Failed to disconnect user: {response.StatusCode}");
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Error sending disconnect request: {ex.Message}");
                }
            }

            userToBan.Banned = true;
            await userRepository.UpdateAsync(userToBan);

            var userHardware = await hardwaresRepository.FindByColumnAsync("accountid", userToBan.AccountId.ToString());
            if (userHardware != null)
            {
                userHardware.Banned = true;
                await hardwaresRepository.UpdateAsync(userHardware);
            }

            var existingBan = await bansRepository.FindByColumnAsync("accountid", userToBan.AccountId.ToString());
            if (existingBan != null)
            {
                existingBan.Reason = reason;
                existingBan.IsRecentlyUnbanned = false;
                existingBan.UnbannedAt = null;
                await bansRepository.UpdateAsync(existingBan);
            }
            else
            {
                var newBan = new Helios.Database.Tables.AntiCheat.Ban
                {
                    AccountId = userToBan.AccountId,
                    Reason = reason,
                    IsRecentlyUnbanned = false,
                    UnbannedAt = null
                };
                await bansRepository.SaveAsync(newBan);
            }

            await tokensRepository.DeleteAsync(new Tokens { AccountId = userToBan.AccountId, Type = "accesstoken" });
            await tokensRepository.DeleteAsync(new Tokens { AccountId = userToBan.AccountId, Type = "refreshtoken" });

            if (user != null)
            {
                try
                {
                    var guild = (command.Channel as SocketGuildChannel)?.Guild;
                    if (guild != null)
                    {
                        await guild.AddBanAsync(user, 0, reason);
                        Logger.Info($"Successfully banned {user.Username} from the Discord server.");
                    }
                    else
                    {
                        Logger.Warn("Could not get guild to ban user.");
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Failed to ban user from server: {ex.Message}");
                }
            }

            var embedBuilder = new EmbedBuilder()
                .WithTitle("User Banned Successfully")
                .WithDescription($"**User:** {displayName}\n**Reason:** {reason}")
                .WithColor(new Color(220, 53, 69))
                .WithCurrentTimestamp()
                .WithFooter($"Banned by {command.User.Username}", command.User.GetAvatarUrl() ?? command.User.GetDefaultAvatarUrl());

            if (user != null)
            {
                embedBuilder.WithThumbnailUrl(user.GetAvatarUrl(size: 256) ?? user.GetDefaultAvatarUrl());
            }

            await command.RespondAsync(embed: embedBuilder.Build(), ephemeral: true);
        }
        catch (Exception ex)
        {
            Logger.Error($"An error occurred in Ban: {ex.Message}");
            await RespondAsync("An error occurred while banning the user.", Color.Red, command);
        }
    }

    private async Task RespondAsync(string message, Color color, SocketSlashCommand command)
    {
        var embedBuilder = new EmbedBuilder()
            .WithDescription(message)
            .WithColor(color)
            .WithCurrentTimestamp();

        await command.RespondAsync(embed: embedBuilder.Build(), ephemeral: true);
    }
}
