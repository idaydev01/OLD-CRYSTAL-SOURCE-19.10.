using Discord;
using Discord.WebSocket;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Interfaces;
using Helios.Utilities;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;

namespace Helios.Discord.Commands;

public class Disconnect : ISlashCommand
{
    public string Name => "disconnect";
    public string Description => "Disconnects a user from the anticheat.";

    public List<SlashCommandOptionBuilder> Options => new List<SlashCommandOptionBuilder>
    {
        new SlashCommandOptionBuilder()
            .WithName("user")
            .WithDescription("The user you want to disconnect")
            .WithType(ApplicationCommandOptionType.User)
            .WithRequired(true)
    };

    public async Task BuildAsync(SocketSlashCommand command)
    {
        try
        {
            if (command == null)
            {
                await RespondAsync("Command is null, please try again.", Color.Red, command);
                return;
            }

            var socketUser = command.User as SocketGuildUser;
            if (socketUser == null)
            {
                await RespondAsync("You do not have the necessary permissions to use this command.", Color.Red, command);
                return;
            }

            var allowedRoles = new[] { "Owner", "Co Owner", "Developer" };
            bool hasRequiredRole = socketUser.Roles.Any(role => allowedRoles.Contains(role.Name));

            if (!hasRequiredRole)
            {
                await RespondAsync("You do not have the necessary permissions to use this command.", Color.Red, command);
                return;
            }

            var options = command.Data.Options.ToList();
            var user = options.FirstOrDefault(x => x.Name == "user")?.Value as SocketUser;
            var reason = options.FirstOrDefault(x => x.Name == "reason")?.Value as string ?? "No reason provided";

            if (user == null)
            {
                await RespondAsync("Invalid user specified, please try again.", Color.Red, command);
                return;
            }
            var userRepository = Constants.repositoryPool.For<User>();
            var tokensRepository = Constants.repositoryPool.For<Tokens>();

            var userToDisconnect = await userRepository.FindByColumnAsync("discordid", user.Id.ToString());

            if (userToDisconnect == null)
            {
                await RespondAsync("The user could not be found in the database.", Color.Red, command);
                return;
            }

            var accessToken = await tokensRepository.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "accountid", userToDisconnect.AccountId },
                { "type", "accesstoken" }
            });

            if (accessToken == null)
            {
                await RespondAsync("The user is not currently connected to the game.", Color.Orange, command);
                return;
            }
                
            Logger.Info($"Disconnecting user with token '{accessToken.Token}' and accountId: {userToDisconnect.AccountId}");

            bool success = false;
            try
            {
                using (var httpClient = new HttpClient())
                {
                    var disconnectEndpoint = "http://54.242.107.17:2095/api/v1/dash/disconnect";
                    var requestData = new
                    {
                        token = Constants.ArsenicToken,
                        authToken = accessToken.Token
                    };

                    var jsonContent = JsonConvert.SerializeObject(requestData, Formatting.None);
                    var content = new StringContent(
                        jsonContent,
                        Encoding.UTF8,
                        "application/json"
                    );

                    var response = await httpClient.PostAsync(disconnectEndpoint, content);

                    if (response.IsSuccessStatusCode)
                    {
                        success = true;
                        Logger.Info($"Successfully disconnected user {userToDisconnect.AccountId}");
                    }
                    else
                    {
                        Logger.Warn($"Failed to disconnect user: {response.StatusCode}");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error sending disconnect request: {ex.Message}");
            }


            await tokensRepository.DeleteAsync(new Tokens { AccountId = accessToken.AccountId, Type = "accesstoken" });
            await tokensRepository.DeleteAsync(new Tokens { AccountId = accessToken.AccountId, Type = "refreshtoken" });

            if (success)
            {
                var embedBuilder = new EmbedBuilder()
                    .WithTitle("User Disconnected Successfully")
                    .WithThumbnailUrl(user.GetAvatarUrl(size: 256) ?? user.GetDefaultAvatarUrl())
                    .WithColor(new Color(40, 167, 69))
                    .WithCurrentTimestamp()
                    .WithFooter($"Disconnected by {command.User.Username}", command.User.GetAvatarUrl() ?? command.User.GetDefaultAvatarUrl());

                await command.RespondAsync(embed: embedBuilder.Build(), ephemeral: true);
            }
            else
            {
                await RespondAsync("Failed to disconnect the user. They might not be connected or there was an API error.", Color.Red, command);
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"An error occurred in Disconnect: {ex.Message}");
            await RespondAsync("An error occurred while trying to disconnect the user.", Color.Red, command);
        }
    }

    private async Task RespondAsync(string message, Color color, SocketSlashCommand command)
    {
        var embedBuilder = new EmbedBuilder()
            .WithDescription(message)
            .WithColor(color)
            .WithCurrentTimestamp();

        await command.RespondAsync(embed: embedBuilder.Build(), ephemeral: true);
    }
}