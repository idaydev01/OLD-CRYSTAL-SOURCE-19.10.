﻿using Discord;
using Discord.Rest;
using Discord.WebSocket;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Interfaces;
using Helios.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Helios.Discord.Commands;

public class Unban : ISlashCommand
{
    public string Name => "unban";
    public string Description => "Unbans a user from crystal.";

    public List<SlashCommandOptionBuilder> Options => new List<SlashCommandOptionBuilder>
    {
        new SlashCommandOptionBuilder()
            .WithName("user")
            .WithDescription("The user you want to unban.")
            .WithType(ApplicationCommandOptionType.User)
            .WithRequired(true)
    };

    public async Task BuildAsync(SocketSlashCommand command)
    {
        try
        {
            if (command == null)
            {
                Logger.Error("Command context is null in Unban command.");
                await RespondAsync("Command is null, please try again.", Color.Red, command);
                return;
            }

            if (command.User is not SocketGuildUser guildUser)
            {
                await RespondAsync("This command can only be used in a server.", Color.Red, command);
                return;
            }

            var allowedRoles = new[] { "Owner", "Co Owner", "Admin", "Manager", "Developer", "Media Manager", "Founder", "Head Admin" };
            bool hasRequiredRole = guildUser.Roles.Any(role => allowedRoles.Contains(role.Name));

            if (!hasRequiredRole)
            {
                await RespondAsync("You do not have the necessary permissions to use this command.", Color.Red, command);
                return;
            }

            var userOption = command.Data.Options.FirstOrDefault(x => x.Name == "user");
            if (userOption?.Value is not SocketUser targetUser)
            {
                await RespondAsync("Invalid user specified, please try again.", Color.Red, command);
                return;
            }

            var userRepository = Constants.repositoryPool.For<User>();
            var bansRepository = Constants.repositoryPool.For<Helios.Database.Tables.AntiCheat.Ban>();
            var hardwaresRepository = Constants.repositoryPool.For<Hardwares>();

            var userToUnban = await userRepository.FindByColumnAsync("discordid", targetUser.Id.ToString());

            if (userToUnban == null)
            {
                await RespondAsync("The user could not be found in the database.", Color.Red, command);
                return;
            }

            var userBan = await bansRepository.FindByColumnAsync("accountid", userToUnban.AccountId.ToString());
            var userHardware = await hardwaresRepository.FindByColumnAsync("accountid", userToUnban.AccountId.ToString());

            if (!userToUnban.Banned && (userHardware == null || !userHardware.Banned) && (userBan == null || userBan.UnbannedAt != null))
            {
                await RespondAsync("This user is not currently banned.", Color.Orange, command);
                return;
            }

            bool changesMade = false;

            if (userToUnban.Banned)
            {
                userToUnban.Banned = false;
                await userRepository.UpdateAsync(userToUnban);
                changesMade = true;
            }

            if (userBan != null)
            {
                userBan.UnbannedAt = DateTime.UtcNow;
                userBan.IsRecentlyUnbanned = true;
                await bansRepository.UpdateAsync(userBan);
                changesMade = true;
            }

            if (userHardware != null && userHardware.Banned)
            {
                userHardware.Banned = false;
                await hardwaresRepository.UpdateAsync(userHardware);
                changesMade = true;
            }

            var guild = (command.Channel as SocketGuildChannel)?.Guild;
            if (guild != null)
            {
                try
                {
                    var bans = new List<RestBan>();
                    await foreach (var batch in guild.GetBansAsync())
                    {
                        bans.AddRange(batch);
                    }

                    var banEntry = bans.FirstOrDefault(b => b.User.Id == targetUser.Id);
                    if (banEntry != null)
                    {
                        await guild.RemoveBanAsync(targetUser);
                        Logger.Info($"Successfully removed Discord server ban for user {targetUser.Username} ({targetUser.Id})");
                        changesMade = true;
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Failed to remove Discord server ban: {ex.Message}");
                }
            }
            else
            {
                Logger.Warn("Could not get guild context to remove ban from Discord server.");
            }

            if (!changesMade)
            {
                await RespondAsync("No changes were made - the user might already be unbanned.", Color.Orange, command);
                return;
            }

            var embedBuilder = new EmbedBuilder()
                .WithTitle("User Unbanned Successfully")
                .WithDescription($"{targetUser.Mention} ({targetUser.Username}#{targetUser.Discriminator}) has been unbanned.")
                .WithThumbnailUrl(targetUser.GetAvatarUrl(size: 256) ?? targetUser.GetDefaultAvatarUrl())
                .WithColor(new Color(40, 167, 69))
                .WithCurrentTimestamp()
                .WithFooter($"Unbanned by {command.User.Username}",
                            command.User.GetAvatarUrl() ?? command.User.GetDefaultAvatarUrl());

            await command.RespondAsync(embed: embedBuilder.Build(), ephemeral: true);
            Logger.Info($"User {targetUser.Id} was unbanned by {command.User.Id}");
        }
        catch (Exception ex)
        {
            Logger.Error($"An error occurred in Unban: {ex}");
            await RespondAsync("An unexpected error occurred while processing the unban. Please try again later.", Color.Red, command);
        }
    }

    private async Task RespondAsync(string message, Color color, SocketSlashCommand command)
    {
        try
        {
            var embedBuilder = new EmbedBuilder()
                .WithDescription(message)
                .WithColor(color)
                .WithCurrentTimestamp();

            await command.RespondAsync(embed: embedBuilder.Build(), ephemeral: true);
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to send response in Unban command: {ex}");
        }
    }
}
