﻿using Discord;
using Discord.WebSocket;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Tournaments;
using Helios.Interfaces;
using Helios.Utilities;
using Newtonsoft.Json;

namespace Helios.Discord.Commands;

public class UserLookup : ISlashCommand
{
    public string Name => "userlookup";
    public string Description => "Looks up information about a user by Discord user or in-game username.";

    public List<SlashCommandOptionBuilder> Options => new List<SlashCommandOptionBuilder>
    {
        new SlashCommandOptionBuilder()
            .WithName("user")
            .WithDescription("The Discord user you want to look up.")
            .WithType(ApplicationCommandOptionType.User)
            .WithRequired(false),
        new SlashCommandOptionBuilder()
            .WithName("username")
            .WithDescription("The in-game username you want to look up.")
            .WithType(ApplicationCommandOptionType.String)
            .WithRequired(false)
    };

    public async Task BuildAsync(SocketSlashCommand command)
    {
        try
        {
            if (command == null)
            {
                await RespondAsync("Command is null, please try again.", Color.Red, command);
                return;
            }

            var options = command.Data.Options;
            var userOption = options.FirstOrDefault(x => x.Name == "user")?.Value as SocketUser;
            var usernameOption = options.FirstOrDefault(x => x.Name == "username")?.Value as string;

            if (userOption == null && string.IsNullOrEmpty(usernameOption))
            {
                await RespondAsync("Please specify either a Discord user or an in-game username.", Color.Red, command);
                return;
            }

            if (userOption != null && !string.IsNullOrEmpty(usernameOption))
            {
                await RespondAsync("Please specify either a Discord user OR an in-game username, not both.", Color.Red, command);
                return;
            }

            var socketUser = command.User as SocketGuildUser;
            var userRepository = Constants.repositoryPool.For<User>();

            /*
            var socketUser = command.User as SocketGuildUser;
            if (socketUser == null || (!socketUser.GuildPermissions.BanMembers && !socketUser.GuildPermissions.KickMembers))
            {
                await RespondAsync("You do not have the necessary permissions to use this command.", Color.Red, command);
                return;
            }
            */

            User userToLookup = null;
            SocketUser targetDiscordUser = null;

            if (userOption != null)
            {
                userToLookup = await userRepository.FindByColumnAsync("discordid", userOption.Id.ToString());
                targetDiscordUser = userOption;
            }
            else
            {
                userToLookup = await FindUserByUsernameAsync(userRepository, usernameOption);

                if (userToLookup != null && !string.IsNullOrEmpty(userToLookup.DiscordId))
                {
                    if (ulong.TryParse(userToLookup.DiscordId, out ulong discordId))
                    {
                        var guild = (command.User as SocketGuildUser)?.Guild;
                        targetDiscordUser = guild?.GetUser(discordId);

                        if (targetDiscordUser == null)
                        {
                            var client = command.User.GetType().GetProperty("Client")?.GetValue(command.User) as DiscordSocketClient;
                            targetDiscordUser = client?.GetUser(discordId);
                        }
                    }
                }
            }

            if (userToLookup == null)
            {
                var searchType = userOption != null ? "Discord user" : "username";
                await RespondAsync($"The {searchType} could not be found in the database.", Color.Red, command);
                return;
            }

            var embedColor = userToLookup.Banned ? new Color(220, 53, 69) : new Color(40, 167, 69);

            var displayName = targetDiscordUser?.Username ?? userToLookup.Username ?? "Unknown";
            var avatarUrl = targetDiscordUser?.GetAvatarUrl(size: 256) ?? targetDiscordUser?.GetDefaultAvatarUrl();

            var embedBuilder = new EmbedBuilder()
                .WithTitle($"User Profile: {displayName}")
                .WithColor(embedColor)
                .WithCurrentTimestamp()
                .WithFooter($"Requested by {command.User.Username}", command.User.GetAvatarUrl() ?? command.User.GetDefaultAvatarUrl());

            if (!string.IsNullOrEmpty(avatarUrl))
            {
                embedBuilder.WithThumbnailUrl(avatarUrl);
            }

            var userInfoText = $"**In-Game Username:** `{userToLookup.Username ?? "Not Available"}`";

            if (targetDiscordUser != null)
            {
                userInfoText += $"\n**Discord ID:** `{targetDiscordUser.Id}`\n" +
                               $"**Display Name:** {(targetDiscordUser as SocketGuildUser)?.DisplayName ?? targetDiscordUser.Username}";
            }
            else if (!string.IsNullOrEmpty(userToLookup.DiscordId))
            {
                userInfoText += $"\n**Discord ID:** `{userToLookup.DiscordId}`\n" +
                               $"**Display Name:** Not Available (User not in server)";
            }
            else
            {
                userInfoText += $"\n**Discord:** Not linked";
            }

            embedBuilder.AddField("**User Information**", userInfoText, false);

            var statusText = userToLookup.Banned ? "**BANNED**" : "Active";
            embedBuilder.AddField("**Account Status**", statusText, true);

            var specialRoles = new List<string>();
            if (userToLookup.Roles.Contains("Crystal Booster")) specialRoles.Add("💎 Crystal Booster");
            if (userToLookup.Roles.Contains("OG Donator")) specialRoles.Add("⭐ OG Donator");
            if (userToLookup.Roles.Contains("Donator")) specialRoles.Add("💝 Donator");

            embedBuilder.AddField("**Special Roles**",
                specialRoles.Count > 0 ? string.Join("\n", specialRoles) : "None", true);

            var tournamentHypeRepository = Constants.repositoryPool.For<TournamentHype>();
            var tournamentHype = await tournamentHypeRepository.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "accountid", userToLookup.AccountId },
                { "type", "NormalHype" },
                { "season", Constants.CurrentVersion }
            });

            var hypeText = tournamentHype?.Hype.ToString() ?? "Not Available";
            embedBuilder.AddField("**Arena Hype**", $"`{hypeText}`", true);

            if (targetDiscordUser is SocketGuildUser guildUser)
            {
                embedBuilder.AddField("**Discord Information**",
                    $"**Joined Server:** {guildUser.JoinedAt?.ToString("MMM dd, yyyy") ?? "Unknown"}\n" +
                    $"**Account Created:** {targetDiscordUser.CreatedAt.ToString("MMM dd, yyyy")}", false);
            }

            embedBuilder.AddField("\u200B", "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", false);

            await command.RespondAsync(embed: embedBuilder.Build(), ephemeral: true);
        }
        catch (Exception ex)
        {
            Logger.Error($"An error occurred in UserLookup: {ex.Message}");
            await RespondAsync("An error occurred while looking up the user.", Color.Red, command);
        }
    }

    private async Task<User> FindUserByUsernameAsync(Repository<User> userRepository, string username)
    {
        var exactMatch = await userRepository.FindByColumnAsync("username", username);
        if (exactMatch != null)
        {
            return exactMatch;
        }

        try
        {
            var users = await userRepository.FindAllByPredicateAsync(
                x => x.Username,
                "STARTSWITH",
                username,
                limit: 100);

            return users.FirstOrDefault(u => string.Equals(u.Username, username, StringComparison.OrdinalIgnoreCase));
        }
        catch
        {
            return await userRepository.FindByColumnAsync("username", username);
        }
    }

    private async Task RespondAsync(string message, Color color, SocketSlashCommand command)
    {
        var embedBuilder = new EmbedBuilder()
            .WithDescription(message)
            .WithColor(color)
            .WithCurrentTimestamp();

        await command.RespondAsync(embed: embedBuilder.Build(), ephemeral: true);
    }
}