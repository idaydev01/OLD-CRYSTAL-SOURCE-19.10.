﻿using Discord;
using Discord.WebSocket;
using Helios.Configuration;
using Helios.Database.Tables.XMPP;
using Helios.Interfaces;
using Helios.Utilities;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;
using System.Threading;

namespace Helios.Discord
{
    public class Bot : IDisposable
    {
        private readonly IServiceProvider _services;
        private readonly Dictionary<string, ISlashCommand> _commands = new();
        private Timer _playerCountTimer;
        private readonly SemaphoreSlim _playerCountSemaphore = new(1, 1);
        private bool _isUpdatingPlayerCount = false;
        private readonly CancellationTokenSource _shutdownToken = new();

        public Bot()
        {
            Constants.DiscordSocketClient = new DiscordSocketClient(new DiscordSocketConfig
            {
                LogLevel = LogSeverity.Info,
                GatewayIntents = GatewayIntents.Guilds | GatewayIntents.GuildMembers
            });

            _services = new ServiceCollection()
                .AddSingleton(Constants.DiscordSocketClient)
                .BuildServiceProvider();
        }

        public async Task RunAsync(string token)
        {
            Constants.DiscordSocketClient.Log += LogAsync;
            Constants.DiscordSocketClient.Ready += ReadyAsync;
            Constants.DiscordSocketClient.SlashCommandExecuted += HandleSlashCommandAsync;

            await Constants.DiscordSocketClient.LoginAsync(TokenType.Bot, token);
            await Constants.DiscordSocketClient.StartAsync();
        }

        private Task LogAsync(LogMessage log)
        {
            Logger.Info($"{log}");
            return Task.CompletedTask;
        }

        private async Task ReadyAsync()
        {
            Logger.Info("Bot is connected.");
            LoadSlashCommands();
            await CleanupAllCommandsAsync();
            await RegisterSlashCommandsAsync();
            StartPlayerCountTimer();
        }

        private async Task CleanupAllCommandsAsync()
        {
            try
            {
                Logger.Info("Starting cleanup of all old commands...");

                await CleanupGlobalCommandsAsync();
                await CleanupGuildCommandsAsync();

                Logger.Info("Command cleanup completed!");
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed during command cleanup: {ex.Message}");
            }
        }

        private async Task CleanupGlobalCommandsAsync()
        {
            try
            {
                var globalCommands = await Constants.DiscordSocketClient.GetGlobalApplicationCommandsAsync();
                Logger.Info($"Found {globalCommands.Count} global commands to check.");

                foreach (var command in globalCommands)
                {
                    if (!_commands.ContainsKey(command.Name))
                    {
                        try
                        {
                            await command.DeleteAsync();
                            Logger.Info($"Deleted unused global command: {command.Name}");
                        }
                        catch (Exception ex)
                        {
                            Logger.Error($"Failed to delete global command '{command.Name}': {ex.Message}");
                        }
                    }
                    else
                    {
                        Logger.Info($"Kept global command: {command.Name} (used by this bot)");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to cleanup global commands: {ex.Message}");
            }
        }

        private async Task CleanupGuildCommandsAsync()
        {
            try
            {
                var guild = Constants.DiscordSocketClient.GetGuild(ulong.Parse(Constants.config.DiscordGuildId));
                if (guild == null)
                {
                    Logger.Error("Failed to get guild for command cleanup.");
                    return;
                }

                var guildCommands = await guild.GetApplicationCommandsAsync();
                Logger.Info($"Found {guildCommands.Count} guild commands to check.");

                foreach (var command in guildCommands)
                {
                    if (!_commands.ContainsKey(command.Name))
                    {
                        try
                        {
                            await command.DeleteAsync();
                            Logger.Info($"Deleted unused guild command: {command.Name}");
                        }
                        catch (Exception ex)
                        {
                            Logger.Error($"Failed to delete guild command '{command.Name}': {ex.Message}");
                        }
                    }
                    else
                    {
                        Logger.Info($"Kept guild command: {command.Name} (used by this bot)");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to cleanup guild commands: {ex.Message}");
            }
        }

        private void StartPlayerCountTimer()
        {
            _playerCountTimer = new Timer(async _ =>
            {
                if (_shutdownToken.IsCancellationRequested) return;
                await UpdatePlayerCountAsync();
            }, null, TimeSpan.Zero, TimeSpan.FromSeconds(30));

            Logger.Info("Player count update timer started.");
        }

        private async Task UpdatePlayerCountAsync()
        {
            if (!await _playerCountSemaphore.WaitAsync(100))
            {
                Logger.Info("Player count update skipped - another update is already in progress.");
                return;
            }

            try
            {
                if (_isUpdatingPlayerCount)
                {
                    Logger.Info("Player count update skipped - flag indicates update in progress.");
                    return;
                }

                _isUpdatingPlayerCount = true;

                using var timeoutCts = new CancellationTokenSource(TimeSpan.FromSeconds(20));
                var allClients = await Constants.GlobalXmppClientService.GetConnectedUsersAsync();

                var playerCount = allClients.ConnectedUsersCount;
                var activityText = playerCount < 20 ? $"Crystal" : $"{playerCount} players online";

                await Constants.DiscordSocketClient.SetGameAsync(activityText, type: ActivityType.Watching);
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to update player count: {ex.Message}");
            }
            finally
            {
                _isUpdatingPlayerCount = false;
                _playerCountSemaphore.Release();
            }
        }

        private async Task RegisterSlashCommandsAsync()
        {
            var guild = Constants.DiscordSocketClient.GetGuild(ulong.Parse(Constants.config.DiscordGuildId));
            if (guild == null)
            {
                Logger.Error("Failed to get guild.");
                return;
            }

            var existingCommands = await guild.GetApplicationCommandsAsync();

            foreach (var command in _commands.Values)
            {
                try
                {
                    var builder = new SlashCommandBuilder()
                        .WithName(command.Name)
                        .WithDescription(command.Description);

                    if (command.Options != null)
                    {
                        foreach (var option in command.Options)
                            builder.AddOption(option);
                    }

                    var existingCommand = existingCommands.FirstOrDefault(c => c.Name == command.Name);

                    if (existingCommand != null)
                    {
                        await existingCommand.DeleteAsync();
                        await guild.CreateApplicationCommandAsync(builder.Build());
                        Logger.Info($"Updated existing slash command: {command.Name}");
                    }
                    else
                    {
                        await guild.CreateApplicationCommandAsync(builder.Build());
                        Logger.Info($"Created new slash command: {command.Name}");
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Failed to register command '{command.Name}': {ex.Message}");
                }
            }

            Logger.Info("Slash command registration completed!");
        }

        private void LoadSlashCommands()
        {
            _commands.Clear();

            var commandTypes = Assembly.GetExecutingAssembly()
                .GetTypes()
                .Where(t => typeof(ISlashCommand).IsAssignableFrom(t) && !t.IsInterface && !t.IsAbstract);

            foreach (var type in commandTypes)
            {
                try
                {
                    var command = (ISlashCommand)Activator.CreateInstance(type);
                    if (!_commands.ContainsKey(command.Name))
                    {
                        _commands[command.Name] = command;
                        Logger.Info($"Loaded slash command: {command.Name}");
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Failed to load command from type {type.Name}: {ex.Message}");
                }
            }
        }

        private async Task HandleSlashCommandAsync(SocketSlashCommand command)
        {
            if (_commands.TryGetValue(command.Data.Name, out var slashCommand))
            {
                await slashCommand.BuildAsync(command);
            }
            else
            {
                await command.RespondAsync("Unknown command.");
            }
        }

        public void Dispose()
        {
            _shutdownToken.Cancel();

            _playerCountTimer?.Dispose();
            _playerCountSemaphore?.Dispose();

            Constants.DiscordSocketClient.Log -= LogAsync;
            Constants.DiscordSocketClient.Ready -= ReadyAsync;
            Constants.DiscordSocketClient.SlashCommandExecuted -= HandleSlashCommandAsync;

            if (Constants.DiscordSocketClient != null)
            {
                try
                {
                    Constants.DiscordSocketClient.LogoutAsync().GetAwaiter().GetResult();
                    Constants.DiscordSocketClient.StopAsync().GetAwaiter().GetResult();
                    Constants.DiscordSocketClient.Dispose();
                }
                catch (Exception ex)
                {
                    Logger.Error($"Failed during Discord client shutdown: {ex.Message}");
                }
            }

            Logger.Info("Bot disposed.");
        }
    }
}