namespace Helios.Utilities.Errors.HeliosErrors;

public class DashboardErrors
{
    private const string Service = "com.helios.dashboard";

    public static ApiError InvalidPayload => new(
        "errors.com.helios.dashboard.invalidPayload",
        "Invalid payload", Service, 1001, 400);

    public static ApiError UnauthorizedAccess => new(
        "errors.com.helios.dashboard.unauthorizedAccess",
        "Unauthorized access to this endpoint", Service, 1002, 403);
}