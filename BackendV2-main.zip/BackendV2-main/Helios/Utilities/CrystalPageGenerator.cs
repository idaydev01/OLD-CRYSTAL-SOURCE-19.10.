﻿using System.Web;

namespace Helios.Utilities
{
    public static class CrystalPageGenerator
    {
        public static string GenerateErrorPage(string message)
        {
            return $@"<!DOCTYPE html>
<html lang=""en"">
<head>
  <meta charset=""UTF-8"" />
  <meta name=""viewport"" content=""width=device-width, initial-scale=1.0""/>
  <title>Crystal Login - Error</title>
  <script src=""https://cdn.tailwindcss.com""></script>
  <link href=""https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap"" rel=""stylesheet"">

  <style>
    body {{
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      overflow: hidden;
      background-color: #0e0e0e;
    }}

    @keyframes floatRotate {{
      0% {{
        transform: translate(0, 0) rotate(0deg);
      }}
      50% {{
        transform: translate(30px, -40px) rotate(180deg);
      }}
      100% {{
        transform: translate(0, 0) rotate(360deg);
      }}
    }}

    .floating-square {{
      position: absolute;
      background-color: #1c1c1c;
      opacity: 0.6;
      border-radius: 0.5rem;
      animation: floatRotate 5s ease-in-out infinite;
    }}

    .square-1 {{ width: 30px; height: 30px; top: 10%; left: 20%; animation-delay: 0s; }}
    .square-2 {{ width: 50px; height: 50px; top: 25%; left: 65%; animation-delay: 0.5s; }}
    .square-3 {{ width: 20px; height: 20px; top: 55%; left: 35%; animation-delay: 1s; }}
    .square-4 {{ width: 40px; height: 40px; top: 75%; left: 15%; animation-delay: 1.5s; }}
    .square-5 {{ width: 60px; height: 60px; top: 45%; left: 80%; animation-delay: 2s; }}
    .square-6 {{ width: 25px; height: 25px; top: 85%; left: 55%; animation-delay: 2.5s; }}

    @keyframes fade-in {{
      from {{
        opacity: 0;
        transform: translateY(20px);
      }}
      to {{
        opacity: 1;
        transform: translateY(0);
      }}
    }}

    .animate-fade-in {{
      animation: fade-in 0.3s ease-out;
    }}
  </style>
</head>
<body class=""flex items-center justify-center min-h-screen p-6 relative"">

  <div class=""floating-square square-1""></div>
  <div class=""floating-square square-2""></div>
  <div class=""floating-square square-3""></div>
  <div class=""floating-square square-4""></div>
  <div class=""floating-square square-5""></div>
  <div class=""floating-square square-6""></div>

  <div class=""relative z-10 bg-gradient-to-b from-[#161616] to-[#1e1e1e] border border-neutral-800 rounded-2xl p-6 w-full max-w-md text-white animate-fade-in"">
    <div class=""flex items-center gap-2 mb-4"">
      <svg xmlns=""http://www.w3.org/2000/svg"" class=""w-6 h-6 text-red-500"" fill=""none"" viewBox=""0 0 24 24"" stroke=""currentColor"">
        <path stroke-linecap=""round"" stroke-linejoin=""round"" stroke-width=""2"" d=""M6 18L18 6M6 6l12 12""/>
      </svg>
      <h2 class=""text-xl font-semibold"">Authentication Error</h2>
    </div>

    <p class=""text-zinc-400 text-sm bg-zinc-900 border border-zinc-800 rounded-lg p-3 mb-4"">
      Unable to complete login. Please try again or contact support.
    </p>

    <div class=""w-full mb-4"">
        <div class=""flex items-center gap-3 p-3 bg-zinc-900 border border-zinc-800 rounded-lg"">
            <img src=""https://fortnite-api.com/images/cosmetics/br/CID_A_354_Athena_Commando_F_ShatterFlyEclipse/icon.png"" 
                 alt=""Crystal Avatar""
                 class=""w-12 h-12 rounded-full"">
            <div class=""flex-1 text-left"">
                <div class=""text-white font-semibold text-sm"">CRYSTAL</div>
                <div class=""text-zinc-400 text-xs font-mono break-all"">
                    {HttpUtility.HtmlEncode(message)}
                </div>
            </div>
        </div>
    </div>

    <button onclick=""window.open('https://discord.gg/R6zJpBW7pZ', '_blank')""
            class=""w-full h-10 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-semibold text-sm cursor-pointer transition-colors"">
      Join Crystal Support
    </button>
  </div>
</body>
</html>";
        }

        public static string GenerateSuccessPage(string username, string discordId, string favoriteCosmetic, string token)
        {
            var avatarUrl = !string.IsNullOrEmpty(favoriteCosmetic)
                ? $"https://fortnite-api.com/images/cosmetics/br/{HttpUtility.HtmlEncode(favoriteCosmetic)}/icon.png"
                : "https://fortnite-api.com/images/cosmetics/br/CID_960_Athena_Commando_M_Cosmos/icon.png";

            return $@"<!DOCTYPE html>
<html lang=""en"">
<head>
  <meta charset=""UTF-8"" />
  <meta name=""viewport"" content=""width=device-width, initial-scale=1.0""/>
  <title>Crystal Login - Success</title>
  <script src=""https://cdn.tailwindcss.com""></script>
  <link href=""https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap"" rel=""stylesheet"">

  <style>
    body {{
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      overflow: hidden;
      background-color: #0e0e0e;
    }}

    @keyframes floatRotate {{
      0% {{
        transform: translate(0, 0) rotate(0deg);
      }}
      50% {{
        transform: translate(30px, -40px) rotate(180deg);
      }}
      100% {{
        transform: translate(0, 0) rotate(360deg);
      }}
    }}

    .floating-square {{
      position: absolute;
      background-color: #1c1c1c;
      opacity: 0.6;
      border-radius: 0.5rem;
      animation: floatRotate 5s ease-in-out infinite;
    }}

    .square-1 {{
      width: 30px; height: 30px;
      top: 10%; left: 20%;
      animation-delay: 0s;
    }}

    .square-2 {{
      width: 50px; height: 50px;
      top: 25%; left: 65%;
      animation-delay: 0.5s;
    }}

    .square-3 {{
      width: 20px; height: 20px;
      top: 55%; left: 35%;
      animation-delay: 1s;
    }}

    .square-4 {{
      width: 40px; height: 40px;
      top: 75%; left: 15%;
      animation-delay: 1.5s;
    }}

    .square-5 {{
      width: 60px; height: 60px;
      top: 45%; left: 80%;
      animation-delay: 2s;
    }}

    .square-6 {{
      width: 25px; height: 25px;
      top: 85%; left: 55%;
      animation-delay: 2.5s;
    }}

    @keyframes fade-in {{
      from {{
        opacity: 0;
        transform: translateY(20px);
      }}
      to {{
        opacity: 1;
        transform: translateY(0);
      }}
    }}

    .animate-fade-in {{
      animation: fade-in 0.3s ease-out;
    }}
  </style>
</head>
<body class=""flex items-center justify-center min-h-screen p-6 relative"">

  <div class=""floating-square square-1""></div>
  <div class=""floating-square square-2""></div>
  <div class=""floating-square square-3""></div>
  <div class=""floating-square square-4""></div>
  <div class=""floating-square square-5""></div>
  <div class=""floating-square square-6""></div>

  <div class=""relative z-10 bg-gradient-to-b from-[#161616] to-[#1e1e1e] border border-neutral-800 rounded-2xl p-6 w-full max-w-md text-white animate-fade-in"">
    <div class=""flex items-center gap-2 mb-4"">
      <svg xmlns=""http://www.w3.org/2000/svg"" class=""w-6 h-6 text-green-500"" fill=""none"" viewBox=""0 0 24 24"" stroke=""currentColor"">
        <path stroke-linecap=""round"" stroke-linejoin=""round"" stroke-width=""2"" d=""M5 13l4 4L19 7""/>
      </svg>
      <h2 class=""text-xl font-semibold"">Login Successful</h2>
    </div>

    <p class=""text-zinc-400 text-sm bg-zinc-900 border border-zinc-800 rounded-lg p-3 mb-4"">
      Welcome back to Crystal! Click below to log into the launcher.
    </p>

    <div class=""flex items-center gap-4 p-3 bg-zinc-900 border border-zinc-800 rounded-lg mb-4"">
      <div class=""relative"">
        <img
          src=""{avatarUrl}""
          onerror=""this.src = 'https://fortnite-api.com/images/cosmetics/br/CID_960_Athena_Commando_M_Cosmos/icon.png'""
          alt=""Avatar""
          class=""w-12 h-12 rounded-full border border-stone-700""
        />
        <div class=""absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-[#1e1e1e]""></div>
      </div>
      <div class=""flex-1"">
        <div class=""text-white font-medium text-sm"">{HttpUtility.HtmlEncode(username)}</div>
        <div class=""text-zinc-400 text-xs"">{HttpUtility.HtmlEncode(discordId)}</div>
      </div>
    </div>

    <button
      id=""loginButton""
      onclick=""handleLogin()""
      class=""w-full h-10 bg-purple-600 hover:bg-purple-700 transition-all rounded-lg font-semibold text-white text-sm""
    >
      Login to Crystal
    </button>
  </div>

  <script>
    function handleLogin() {{
      const button = document.getElementById('loginButton');
      button.textContent = 'Logged In';
      button.classList.remove('bg-purple-600', 'hover:bg-purple-700');
      button.classList.add('bg-green-500', 'cursor-default');
      button.disabled = true;
      window.location.href = 'crystal://{HttpUtility.HtmlEncode(token)}';
      setTimeout(() => {{
        window.close();
      }}, 2000);
    }}
  </script>
</body>
</html>";
        }
    }
}