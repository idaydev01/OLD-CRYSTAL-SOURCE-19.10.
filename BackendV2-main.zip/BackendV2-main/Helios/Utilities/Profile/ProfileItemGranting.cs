﻿using CUE4Parse.Utils;
using Helios.Classes.MCP;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Fortnite;
using Helios.Database.Tables.Profiles;
using Helios.Utilities.Extensions;
using Microsoft.OpenApi.Validations;
using Newtonsoft.Json;
using Org.BouncyCastle.Asn1.Esf;
using System.Collections.Concurrent;
using System.Text.Json;
namespace Helios.Utilities.Profile;
public class ProfileItemGranting
{
    public class AtomicCounter
    {
        private int _value;
        public int Increment() => Interlocked.Increment(ref _value);
        public int Value => Volatile.Read(ref _value);
    }
    private static readonly Dictionary<string, string> CosmeticTypeMapping = new(StringComparer.OrdinalIgnoreCase)
    {
        ["characters"] = "AthenaCharacter",
        ["backpacks"] = "AthenaBackpack",
        ["pickaxes"] = "AthenaPickaxe",
        ["dances"] = "AthenaDance",
        ["musicpacks"] = "AthenaMusicPack",
        ["pets"] = "AthenaBackpack",
        ["sprays"] = "AthenaDance",
        ["toys"] = "AthenaDance",
        ["loadingscreens"] = "AthenaLoadingScreen",
        ["gliders"] = "AthenaGlider",
        ["contrails"] = "AthenaSkyDiveContrail",
        ["petcarriers"] = "AthenaPetCarrier",
        ["battlebuses"] = "AthenaBattleBus",
        ["victoryposes"] = "AthenaVictoryPose",
        ["consumableemotes"] = "AthenaConsumableEmote",
        ["wraps"] = "AthenaItemWrap",
        ["itemwraps"] = "AthenaItemWrap"
    };

    private static bool NeedsVariantUpdate(Items existingItem, List<Variants> expectedVariants)
    {
        if (expectedVariants.Count == 0) return false;

        try
        {
            var existingItemValue = JsonConvert.DeserializeObject<Dictionary<string, object>>(existingItem.Value);
            var existingVariants = new List<Dictionary<string, object>>();

            if (existingItemValue.TryGetValue("variants", out var existingVariantsObj) && existingVariantsObj != null)
            {
                try
                {
                    var existingVariantsJson = JsonConvert.SerializeObject(existingVariantsObj);
                    var deserializedVariants = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(existingVariantsJson);
                    if (deserializedVariants != null)
                    {
                        existingVariants = deserializedVariants;
                    }
                }
                catch
                {
                    return true;
                }
            }
            else
            {
                return true;
            }

            foreach (var expectedVariant in expectedVariants)
            {
                dynamic expVar = expectedVariant;
                var existingVariant = existingVariants.FirstOrDefault(v =>
                    v.TryGetValue("channel", out var ch) && ch?.ToString() == expVar.Channel);

                if (existingVariant == null)
                {
                    return true;
                }

                if (!existingVariant.TryGetValue("owned", out var ownedVal) || ownedVal == null)
                {
                    return true;
                }

                if (expVar.Owned != null && expVar.Owned.Count > 0)
                {
                    try
                    {
                        var ownedJson = JsonConvert.SerializeObject(ownedVal);
                        var ownedList = JsonConvert.DeserializeObject<List<string>>(ownedJson);
                        if (ownedList == null || ownedList.Count == 0)
                        {
                            return true;
                        }
                    }
                    catch
                    {
                        return true;
                    }
                }
            }

            return false;
        }
        catch
        {
            return true;
        }
    }

    private static void UpdateItemVariants(Items existingItem, List<Variants> expectedVariants)
    {
        try
        {
            var existingItemValue = JsonConvert.DeserializeObject<Dictionary<string, object>>(existingItem.Value);
            var existingVariants = new List<Dictionary<string, object>>();

            if (existingItemValue.TryGetValue("variants", out var existingVariantsObj) && existingVariantsObj != null)
            {
                try
                {
                    var existingVariantsJson = JsonConvert.SerializeObject(existingVariantsObj);
                    var deserializedVariants = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(existingVariantsJson);
                    if (deserializedVariants != null)
                    {
                        existingVariants = deserializedVariants;
                    }
                }
                catch
                {
                }
            }

            var updatedVariants = new List<Dictionary<string, object>>();

            foreach (var expectedVariant in expectedVariants)
            {
                dynamic expVar = expectedVariant;
                var existingVariant = existingVariants.FirstOrDefault(v =>
                    v.TryGetValue("channel", out var ch) && ch?.ToString() == expVar.Channel);

                if (existingVariant != null)
                {
                    var preservedVariant = new Dictionary<string, object>();
                    foreach (var kvp in existingVariant)
                    {
                        preservedVariant[kvp.Key] = kvp.Value;
                    }

                    if (!preservedVariant.TryGetValue("owned", out var ownedVal) || ownedVal == null)
                    {
                        if (expVar.Owned != null && expVar.Owned.Count > 0)
                        {
                            preservedVariant["owned"] = expVar.Owned;
                        }
                    }
                    else
                    {
                        try
                        {
                            var ownedJson = JsonConvert.SerializeObject(ownedVal);
                            var ownedList = JsonConvert.DeserializeObject<List<string>>(ownedJson);
                            if ((ownedList == null || ownedList.Count == 0) &&
                                expVar.Owned != null && expVar.Owned.Count > 0)
                            {
                                preservedVariant["owned"] = expVar.Owned;
                            }
                        }
                        catch
                        {
                            if (expVar.Owned != null && expVar.Owned.Count > 0)
                            {
                                preservedVariant["owned"] = expVar.Owned;
                            }
                        }
                    }

                    updatedVariants.Add(preservedVariant);
                }
                else
                {
                    var newVariant = new Dictionary<string, object>
                    {
                        ["channel"] = expVar.Channel,
                        ["active"] = expVar.Active
                    };

                    if (expVar.Owned != null && expVar.Owned.Count > 0)
                    {
                        newVariant["owned"] = expVar.Owned;
                    }

                    updatedVariants.Add(newVariant);
                }
            }

            existingItemValue["variants"] = updatedVariants;
            existingItem.Value = JsonConvert.SerializeObject(existingItemValue);
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to update variants for item {existingItem.TemplateId}: {ex.Message}");
            var newItem = ProfileItemCreator.CreateItem("athena", existingItem.AccountId, existingItem.TemplateId, expectedVariants);
            if (newItem != null)
            {
                existingItem.Value = newItem.Value;
            }
        }
    }

    public static async Task GrantAll(string accountId)
    {
        if (string.IsNullOrWhiteSpace(accountId))
            throw new ArgumentException("Account ID cannot be null or empty.", nameof(accountId));
        var profileItemsRepo = Constants.repositoryPool.For<Items>(false);
        var receiptsRepo = Constants.repositoryPool.For<FortniteReceipts>(false);
        var usersRepo = Constants.repositoryPool.For<User>(false);
        profileItemsRepo.ClearAllCaches();
        receiptsRepo.ClearAllCaches();
        usersRepo.ClearAllCaches();
        User? user;
        try
        {
            user = await usersRepo.FindByColumnAsync("accountid", accountId, useCache: false);
            if (user == null)
            {
                Logger.Warn($"[GrantAll] User not found: {accountId}");
                return;
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"[GrantAll] Failed to fetch user {accountId}: {ex.Message}");
            throw;
        }
        List<string> cosmeticFiles;
        try
        {
            cosmeticFiles = await Constants.FileProvider.LoadAllCosmeticsAsync(CancellationToken.None);
            if (cosmeticFiles.Count == 0)
            {
                Logger.Warn("[GrantAll] No cosmetic files found.");
                return;
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"[GrantAll] Failed to load cosmetics: {ex.Message}");
            throw;
        }
        var newItems = new List<Items>();
        var updatedItems = new List<Items>();
        int processed = 0, skipped = 0, errors = 0, variantUpdates = 0;
        var existingItemsQuery = await profileItemsRepo.FindAllByColumnsAsync(
            new Dictionary<string, object>
            {
            {"accountid", accountId},
            {"profileid", "athena"}
            },
            useCache: false
        );
        var existingItems = existingItemsQuery
            .GroupBy(x => x.TemplateId)
            .ToDictionary(g => g.Key, g => g.First());
        foreach (var cosmeticPath in cosmeticFiles)
        {
            try
            {
                processed++;
                var cosmeticName = Path.GetFileNameWithoutExtension(cosmeticPath);
                var cosmeticTypeKey = GetCosmeticTypeKey(cosmeticPath);
                if (!CosmeticTypeMapping.TryGetValue(cosmeticTypeKey, out var cosmeticType))
                {
                    skipped++;
                    continue;
                }
                var templateId = $"{cosmeticType}:{cosmeticName}";
                var expectedVariants = await Constants.FileProvider.GetVariantsAsync(templateId.Split(":")[1]);
                if (existingItems.TryGetValue(templateId, out var existingItem))
                {
                    if (expectedVariants.Count > 0)
                    {
                        bool needsVariantUpdate = false;
                        try
                        {
                            var existingItemValue = JsonConvert.DeserializeObject<Dictionary<string, object>>(existingItem.Value);
                            var existingVariants = new List<Dictionary<string, object>>();
                            if (existingItemValue.TryGetValue("variants", out var existingVariantsObj) && existingVariantsObj != null)
                            {
                                try
                                {
                                    var existingVariantsJson = JsonConvert.SerializeObject(existingVariantsObj);
                                    var deserializedVariants = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(existingVariantsJson);
                                    if (deserializedVariants != null)
                                    {
                                        existingVariants = deserializedVariants;
                                    }
                                }
                                catch
                                {
                                    needsVariantUpdate = true;
                                }
                            }
                            else
                            {
                                needsVariantUpdate = true;
                            }
                            if (!needsVariantUpdate)
                            {
                                foreach (var expectedVariant in expectedVariants)
                                {
                                    var existingVariant = existingVariants.FirstOrDefault(v =>
                                        v.TryGetValue("channel", out var ch) && ch?.ToString() == expectedVariant.Channel);
                                    if (existingVariant == null)
                                    {
                                        needsVariantUpdate = true;
                                        break;
                                    }
                                    if (!existingVariant.TryGetValue("owned", out var ownedVal) ||
                                        ownedVal == null)
                                    {
                                        needsVariantUpdate = true;
                                        break;
                                    }
                                    if (expectedVariant.Owned != null && expectedVariant.Owned.Count > 0)
                                    {
                                        try
                                        {
                                            var ownedJson = JsonConvert.SerializeObject(ownedVal);
                                            var ownedList = JsonConvert.DeserializeObject<List<string>>(ownedJson);
                                            if (ownedList == null || ownedList.Count == 0)
                                            {
                                                needsVariantUpdate = true;
                                                break;
                                            }
                                        }
                                        catch
                                        {
                                            needsVariantUpdate = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            if (needsVariantUpdate)
                            {
                                var updatedVariants = new List<Dictionary<string, object>>();
                                foreach (var expectedVariant in expectedVariants)
                                {
                                    var existingVariant = existingVariants.FirstOrDefault(v =>
                                        v.TryGetValue("channel", out var ch) && ch?.ToString() == expectedVariant.Channel);
                                    if (existingVariant != null)
                                    {
                                        var preservedVariant = new Dictionary<string, object>();
                                        foreach (var kvp in existingVariant)
                                        {
                                            preservedVariant[kvp.Key] = kvp.Value;
                                        }
                                        if (!preservedVariant.TryGetValue("owned", out var ownedVal) ||
                                            ownedVal == null)
                                        {
                                            if (expectedVariant.Owned != null && expectedVariant.Owned.Count > 0)
                                            {
                                                preservedVariant["owned"] = expectedVariant.Owned;
                                            }
                                        }
                                        else
                                        {
                                            try
                                            {
                                                var ownedJson = JsonConvert.SerializeObject(ownedVal);
                                                var ownedList = JsonConvert.DeserializeObject<List<string>>(ownedJson);
                                                if ((ownedList == null || ownedList.Count == 0) &&
                                                    expectedVariant.Owned != null && expectedVariant.Owned.Count > 0)
                                                {
                                                    preservedVariant["owned"] = expectedVariant.Owned;
                                                }
                                            }
                                            catch
                                            {
                                                if (expectedVariant.Owned != null && expectedVariant.Owned.Count > 0)
                                                {
                                                    preservedVariant["owned"] = expectedVariant.Owned;
                                                }
                                            }
                                        }
                                        updatedVariants.Add(preservedVariant);
                                    }
                                    else
                                    {
                                        var newVariant = new Dictionary<string, object>
                                        {
                                            ["channel"] = expectedVariant.Channel,
                                            ["active"] = expectedVariant.Active
                                        };
                                        if (expectedVariant.Owned != null && expectedVariant.Owned.Count > 0)
                                        {
                                            newVariant["owned"] = expectedVariant.Owned;
                                        }
                                        updatedVariants.Add(newVariant);
                                    }
                                }
                                existingItemValue["variants"] = updatedVariants;
                                existingItem.Value = JsonConvert.SerializeObject(existingItemValue);
                                updatedItems.Add(existingItem);
                                variantUpdates++;
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.Error($"[GrantAll] Error checking variants for {templateId}: {ex.Message}");
                            var newItem = ProfileItemCreator.CreateItem("athena", accountId, templateId, expectedVariants);
                            if (newItem != null)
                            {
                                existingItem.Value = newItem.Value;
                                updatedItems.Add(existingItem);
                                variantUpdates++;
                            }
                        }
                    }
                    skipped++;
                    continue;
                }
                var item = ProfileItemCreator.CreateItem("athena", accountId, templateId, expectedVariants);
                if (item != null)
                    newItems.Add(item);
            }
            catch (Exception ex)
            {
                errors++;
                Logger.Warn($"[GrantAll] Error processing '{cosmeticPath}': {ex.Message}");
            }
        }
        if (newItems.Count > 0)
        {
            const int batchSize = 6000;
            try
            {
                for (int i = 0; i < newItems.Count; i += batchSize)
                {
                    var batch = newItems.Skip(i).Take(batchSize).ToList();
                    await profileItemsRepo.BulkSaveAsync(batch);
                    profileItemsRepo.ClearAllCaches();
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[GrantAll] Failed to save new items: {ex.Message}");
                throw;
            }
        }
        if (updatedItems.Count > 0)
        {
            const int batchSize = 1000;
            try
            {
                for (int i = 0; i < updatedItems.Count; i += batchSize)
                {
                    var batch = updatedItems.Skip(i).Take(batchSize).ToList();
                    foreach (var item in batch)
                    {
                        await profileItemsRepo.UpdateAsync(item);
                    }
                    profileItemsRepo.ClearAllCaches();
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[GrantAll] Failed to update existing items: {ex.Message}");
                throw;
            }
        }
        if (newItems.Count > 0)
        {
            try
            {
                await receiptsRepo.SaveAsync(new FortniteReceipts
                {
                    AccountId = accountId,
                    AppStoreId = "FullLocker",
                    AppStore = "EpicPurchasingService",
                    ReceiptId = Guid.NewGuid().ToString("N"),
                    ReceiptInfo = "ENTITLEMENT",
                });
                user.AllItemsGranted = true;
                await usersRepo.UpdateAsync(user);
            }
            catch (Exception ex)
            {
                Logger.Error($"[GrantAll] Failed to save receipt: {ex.Message}");
                throw;
            }
        }
        Logger.Info($"[GrantAll] Completed for {accountId}. " +
                   $"New Items: {newItems.Count}, Variant Updates: {variantUpdates}, Processed: {processed}, Skipped: {skipped}, Errors: {errors}");
    }
    private static string GetCosmeticTypeKey(string cosmeticPath)
    {
        var pathSegments = cosmeticPath.ToLower().Split('/');
        return pathSegments.Length > 5 ? pathSegments[5] : string.Empty;
    }
    public static async Task GrantBoosterItems(string accountId)
    {
        if (string.IsNullOrWhiteSpace(accountId))
            throw new ArgumentException("Account ID is required", nameof(accountId));
        var itemsToGrant = new List<string>
        {
            "AthenaCharacter:CID_660_Athena_Commando_F_BandageNinjaBlue",
            "AthenaPickaxe:Pickaxe_ID_338_BandageNinjaBlue1H",
            "AthenaBackPack:BID_452_BandageNinjaBlue"
        };
        try
        {
            var repository = Constants.repositoryPool.Repo<Items>();
            var receiptsRepository = Constants.repositoryPool.Repo<FortniteReceipts>();
            var usersRepository = Constants.repositoryPool.For<User>();
            var user = await usersRepository.FindByColumnAsync("accountid", accountId);
            if (user == null)
            {
                Logger.Warn($"[GrantBoosterItems] User with account ID '{accountId}' not found.");
                return;
            }
            var createdItems = new List<Items>();
            var updatedItems = new List<Items>();
            int variantUpdates = 0;
            foreach (var templateId in itemsToGrant)
            {
                var variant = await Constants.FileProvider.GetVariantsAsync(templateId.Split(":")[1]);

                var existingItem = await repository().FindByColumnsAsync(new Dictionary<string, object>
                {
                    { "templateid", templateId },
                    { "accountid", accountId },
                    { "profileid", "athena" }
                });

                if (existingItem != null)
                {
                    if (variant.Count > 0 && NeedsVariantUpdate(existingItem, variant))
                    {
                        UpdateItemVariants(existingItem, variant);
                        updatedItems.Add(existingItem);
                        variantUpdates++;
                    }
                    continue;
                }
                try
                {
                    var item = ProfileItemCreator.CreateItem("athena", accountId, templateId, variant);
                    if (item != null) createdItems.Add(item);
                }
                catch (Exception ex)
                {
                    Logger.Error($"Failed to create item {templateId} for {accountId}: {ex.Message}");
                }
            }

            if (createdItems.Count > 0)
            {
                await repository().BulkSaveAsync(createdItems);
            }

            if (updatedItems.Count > 0)
            {
                foreach (var item in updatedItems)
                {
                    await repository().UpdateAsync(item);
                }
            }

            if (createdItems.Count > 0 || updatedItems.Count > 0)
            {
                await receiptsRepository().SaveAsync(new FortniteReceipts
                {
                    AccountId = accountId,
                    AppStoreId = "BoosterRewards",
                    AppStore = "EpicPurchasingService",
                    ReceiptId = Guid.NewGuid().ToString(),
                    ReceiptInfo = "ENTITLEMENT",
                });
                user.BoosterItemsGranted = true;
                await usersRepository.UpdateAsync(user);
            }

            Logger.Info($"[GrantBoosterItems] Completed for {accountId}. " +
                       $"New Items: {createdItems.Count}, Variant Updates: {variantUpdates}");
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to grant booster items for {accountId}: {ex}");
            throw;
        }
    }
    public static async Task GrantOgDonatorItems(string accountId)
    {
        if (string.IsNullOrWhiteSpace(accountId))
            throw new ArgumentException("Account ID is required", nameof(accountId));
        var itemsToGrant = new List<string>
        {
            "AthenaCharacter:CID_017_Athena_Commando_M",
            "AthenaCharacter:CID_028_Athena_Commando_F",
            "AthenaBackPack:BID_452_BandageNinjaBlue",
            "AthenaCharacter:CID_029_Athena_Commando_F_Halloween",
            "AthenaCharacter:CID_030_Athena_Commando_M_Halloween",
            "AthenaPickaxe:HalloweenScythe",
            "AthenaPickaxe:Pickaxe_Lockjaw"
        };
        try
        {
            var repository = Constants.repositoryPool.Repo<Items>();
            var receiptsRepository = Constants.repositoryPool.Repo<FortniteReceipts>();
            var usersRepository = Constants.repositoryPool.For<User>();
            var user = await usersRepository.FindByColumnAsync("accountid", accountId);
            if (user == null)
            {
                Logger.Warn($"[GrantOgDonatorItems] User with account ID '{accountId}' not found.");
                return;
            }
            var createdItems = new List<Items>();
            var updatedItems = new List<Items>();
            int variantUpdates = 0;
            foreach (var templateId in itemsToGrant)
            {
                var existingItem = await repository().FindByColumnsAsync(new Dictionary<string, object>
                {
                    { "templateid", templateId },
                    { "accountid", accountId },
                    { "profileid", "athena" }
                });

                var variant = await Constants.FileProvider.GetVariantsAsync(templateId.Split(":")[1]);

                if (existingItem != null)
                {
                    if (variant.Count > 0 && NeedsVariantUpdate(existingItem, variant))
                    {
                        UpdateItemVariants(existingItem, variant);
                        updatedItems.Add(existingItem);
                        variantUpdates++;
                    }
                    continue;
                }
                try
                {
                    var item = ProfileItemCreator.CreateItem("athena", accountId, templateId, variant);
                    if (item != null) createdItems.Add(item);
                }
                catch (Exception ex)
                {
                    Logger.Error($"Failed to create item {templateId} for {accountId}: {ex.Message}");
                }
            }

            if (createdItems.Count > 0)
            {
                await repository().BulkSaveAsync(createdItems);
            }

            if (updatedItems.Count > 0)
            {
                foreach (var item in updatedItems)
                {
                    await repository().UpdateAsync(item);
                }
            }

            if (createdItems.Count > 0 || updatedItems.Count > 0)
            {
                await receiptsRepository().SaveAsync(new FortniteReceipts
                {
                    AccountId = accountId,
                    AppStoreId = "OgDonatorRewards",
                    AppStore = "EpicPurchasingService",
                    ReceiptId = Guid.NewGuid().ToString(),
                    ReceiptInfo = "ENTITLEMENT",
                });
                user.OgDonatorItemsGranted = true;
                await usersRepository.UpdateAsync(user);
            }

            Logger.Info($"[GrantOgDonatorItems] Completed for {accountId}. " +
                       $"New Items: {createdItems.Count}, Variant Updates: {variantUpdates}");
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to grant og donator items for {accountId}: {ex}");
            throw;
        }
    }

    public static async Task GrantMissingVariants(string accountId)
    {
        if (string.IsNullOrWhiteSpace(accountId))
            throw new ArgumentException("Account ID cannot be null or empty.", nameof(accountId));

        var profileItemsRepo = Constants.repositoryPool.For<Items>(false);
        var usersRepo = Constants.repositoryPool.For<User>(false);

        profileItemsRepo.ClearAllCaches();
        usersRepo.ClearAllCaches();

        User? user;
        try
        {
            user = await usersRepo.FindByColumnAsync("accountid", accountId, useCache: false);
            if (user == null)
            {
                Logger.Warn($"[GrantMissingVariants] User not found: {accountId}");
                return;
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"[GrantMissingVariants] Failed to fetch user {accountId}: {ex.Message}");
            throw;
        }

        var existingItemsQuery = await profileItemsRepo.FindAllByColumnsAsync(
            new Dictionary<string, object>
            {
            {"accountid", accountId},
            {"profileid", "athena"}
            },
            useCache: false
        );

        var existingItems = existingItemsQuery.ToList();
        var updatedItems = new List<Items>();
        int variantUpdates = 0;
        int processed = 0;
        int errors = 0;

        Logger.Info($"[GrantMissingVariants] Processing {existingItems.Count} items for {accountId}");

        foreach (var existingItem in existingItems)
        {
            try
            {
                processed++;

                var templateParts = existingItem.TemplateId.Split(':');
                if (templateParts.Length != 2)
                {
                    continue;
                }

                var cosmeticName = templateParts[1];
                var expectedVariants = await Constants.FileProvider.GetVariantsAsync(cosmeticName);

                if (expectedVariants.Count == 0)
                {
                    continue; 
                }

                if (NeedsVariantUpdate(existingItem, expectedVariants))
                {
                    UpdateItemVariants(existingItem, expectedVariants);
                    updatedItems.Add(existingItem);
                    variantUpdates++;
                }
            }
            catch (Exception ex)
            {
                errors++;
                Logger.Warn($"[GrantMissingVariants] Error processing item '{existingItem.TemplateId}': {ex.Message}");
            }
        }

        if (updatedItems.Count > 0)
        {
            const int batchSize = 1000;
            try
            {
                for (int i = 0; i < updatedItems.Count; i += batchSize)
                {
                    var batch = updatedItems.Skip(i).Take(batchSize).ToList();
                    foreach (var item in batch)
                    {
                        await profileItemsRepo.UpdateAsync(item);
                    }
                    profileItemsRepo.ClearAllCaches();
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[GrantMissingVariants] Failed to update items: {ex.Message}");
                throw;
            }
        }

        Logger.Info($"[GrantMissingVariants] Completed for {accountId}. " +
                   $"Processed: {processed}, Variant Updates: {variantUpdates}, Errors: {errors}");
    }

    public static async Task GrantItemAsync(string templateId, string profileId, string accountId, string defaultItemValue)
    {
        var itemsRepository = Constants.repositoryPool.Repo<Items>();
        var existingItem = await itemsRepository().FindByColumnsAsync(new Dictionary<string, object>
        {
            { "templateid", templateId },
            { "accountid", accountId },
            { "profileid", profileId }
        });
        if (existingItem == null)
        {
            await itemsRepository().SaveAsync(CreateItem(accountId, templateId, new List<object>(), profileId, defaultItemValue));
        }
    }
    private static Items CreateItem(
        string accountId,
        string templateId,
        List<object>? variants,
        string profileId = "athena",
        string? defaultValue = null)
    {
        return new Items
        {
            AccountId = accountId,
            ProfileId = profileId,
            TemplateId = templateId,
            Value = defaultValue ?? System.Text.Json.JsonSerializer.Serialize(new
            {
                item_seen = false,
                variants = variants ?? new(),
                xp = 0,
                favorite = false
            }),
            Quantity = 1,
            IsAttribute = false
        };
    }
}