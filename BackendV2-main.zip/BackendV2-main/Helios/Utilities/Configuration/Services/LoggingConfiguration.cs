﻿using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;

namespace Helios.Configuration.Services;


public static class LoggingConfiguration
{
    public static LogLevel ConvertLogEventLevelToLogLevel(LogEventLevel level)
    {
        return level switch
        {
            LogEventLevel.Verbose => LogLevel.Trace,
            LogEventLevel.Debug => LogLevel.Debug,
            LogEventLevel.Information => LogLevel.Information,
            LogEventLevel.Warning => LogLevel.Warning,
            LogEventLevel.Error => LogLevel.Error,
            LogEventLevel.Fatal => LogLevel.Critical,
            _ => LogLevel.None
        };
    }

    public static void ConfigureLogging(ILoggingBuilder logging, IConfiguration configuration, IHostEnvironment environment)
    {
        logging.ClearProviders();
        logging.AddSerilog();

        logging.AddConfiguration(configuration.GetSection("Logging"));

        var minimumLevel = environment.IsDevelopment() ? LogEventLevel.Debug : LogEventLevel.Error;

        logging.AddConsole().SetMinimumLevel(ConvertLogEventLevelToLogLevel(minimumLevel));
    }
}