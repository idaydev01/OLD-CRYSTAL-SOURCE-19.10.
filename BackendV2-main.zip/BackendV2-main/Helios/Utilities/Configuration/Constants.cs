﻿using System.Text.RegularExpressions;
using CUE4Parse.UE4.Assets.Objects;
using CUE4Parse.UE4.Objects.GameplayTags;
using Discord.WebSocket;
using Helios.Classes.MCP;
using Helios.Classes.Typings;
using Helios.Database;
using Helios.Database.Repository;
using Helios.Managers;
using Helios.Managers.Unreal;
using Helios.Sockets.Hermes;

namespace Helios.Configuration;

public static class Constants
{
    public static ConfigTypes config { get; } = Configuration.GetConfig();
    public static DatabaseCtx dbContext { get; } = new DatabaseCtx(config.DatabaseConnectionUrl);
    public static RepositoryPool repositoryPool { get; } = new RepositoryPool(config.DatabaseConnectionUrl);
    public static UnrealAssetProvider FileProvider { get; set; } = null;

    public static int CurrentVersion = int.Parse(config.CurrentVersion.Split(".")[0]);
    public static string ValidApiKey = "a9f3e5c2-38b4-4d0f-9a7e-84ec4bdb9b35";
    public static string ArsenicToken = "MzExNTIyMjcwNTkwMjcwNTkwMjYyMzk0MjY4NTM3NDEzODcyNDU2ODY5NDU2ODY5MzA3NDM2MzE5NzE4Mjk3MTk1MzEzNTcxMjY2NDg4MzA3NDM2MzIzODEyNDU0ODIwMjc4NzcwMjgwODE5MjgyODY0";


    // https://github.com/djlorenzouasset/Athena/blob/430db920d10fb1f8b9e5f89437f9d5a4c45399c2/Athena/Managers/Dataminer.cs#L57
    public static readonly string[] ItemDefinitionClasses = [
        // BR
        "AthenaCharacterItemDefinition", "AthenaBackpackItemDefinition",
        "AthenaPickaxeItemDefinition", "AthenaGliderItemDefinition",
        "AthenaPetCarrierItemDefinition", "AthenaToyItemDefinition",
        "AthenaEmojiItemDefinition", "AthenaSprayItemDefinition",
        "AthenaLoadingScreenItemDefinition", "AthenaDanceItemDefinition",
        "AthenaSkyDiveContrailItemDefinition", "AthenaItemWrapDefinition",
        "AthenaMusicPackItemDefinition", "CosmeticShoesItemDefinition",

        // FORTNITE FESTIVAL
        "SparksGuitarItemDefinition", "SparksBassItemDefinition",
        "SparksKeyboardItemDefinition", "SparksDrumItemDefinition",
        "SparksMicItemDefinition", "SparksAuraItemDefinition",
        "SparksSongItemDefinition",

        // ROCKET RACING
        "FortVehicleCosmeticsItemDefinition_Skin",
        "FortVehicleCosmeticsItemDefinition_Body",
        "FortVehicleCosmeticsItemDefinition_Booster",
        "FortVehicleCosmeticsItemDefinition_Wheel",
        "FortVehicleCosmeticsItemDefinition_DriftTrail",

        // LEGO
        "JunoBuildingPropAccountItemDefinition",
        "JunoBuildingSetAccountItemDefinition"
    ];

    public static readonly HashSet<string> IgnoredTemplateIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
       "AthenaDanceItemDefinition_AdHocSquadsJoin"
    };

    public static readonly string[] IgnoredPrefixes = new[]
    {
        "Glider_",
        "EID_",
        "BoltonPickaxe",
        "LSID_",
        "Wrap_",
        "MusicPack_",
        "AthenaDanceItemDefinition_AdHocSquadsJoin"
    };


    public static XmppForwarderClient GlobalXmppClientService { get; set; } = null;
    public static PartyManager GlobalPartyManagerService { get; set; } = null;
    public static DiscordSocketClient DiscordSocketClient { get; set; }
    public static DateTime ActiveUntil => new DateTime(9999, 12, 31, 23, 59, 59, DateTimeKind.Utc);

    public static string BaseUrl
    {
        get
        {
#if DEBUG
            return "http://127.0.0.1";
#else
            return "http://185.206.149.110";
#endif
        }
    }
    public static int Port => 8080;
    public static int MatchmakerPort => 45011;

    // Xmpp
    public static string BaseXmppUrl { get; set; } = "http://127.0.0.1:9080";
    public static TimeSpan RequestTimeout { get; set; } = TimeSpan.FromSeconds(30);
    public static int MaxConnectionsPerServer { get; set; } = 100;
    public static TimeSpan ConnectionLifetime { get; set; } = TimeSpan.FromMinutes(10);
    public static TimeSpan KeepAliveTimeout { get; set; } = TimeSpan.FromSeconds(30);
    public static int MaxRetryAttempts { get; set; } = 3;
    public static TimeSpan RetryDelay { get; set; } = TimeSpan.FromSeconds(1);

    public static string ExtractSanitiztedRoute(PathString route)
    {
        string sanitizedRoute = null;
        sanitizedRoute = Regex.Replace(route, @"^(https?:\/\/)?([a-zA-Z0-9.-]+)(:\d+)?", "");
        sanitizedRoute = Regex.Replace(sanitizedRoute, @".*\/fortnite", "");

        return sanitizedRoute;
    }

    public static string ParseChannelName(string tagText)
    {
        const string propertyPrefix = "Cosmetics.Variant.Property.";
        const string channelPrefix = "Cosmetics.Variant.Channel.";

        int propertyIndex = tagText.IndexOf(propertyPrefix);
        if (propertyIndex >= 0)
        {
            return tagText.Substring(propertyIndex + propertyPrefix.Length);
        }

        int channelIndex = tagText.IndexOf(channelPrefix);
        if (channelIndex >= 0)
        {
            return tagText.Substring(channelIndex + channelPrefix.Length);
        }

        return string.Empty;
    }
    
    public static Variants CreateVariantFromOptions(FStructFallback[] options, string channel)
    {
        var variant = new Variants
        {
            Channel = channel,
            Active = "",
            Owned = new List<string>(options.Length)
        };

        var optionsSpan = options.AsSpan();

        for (int i = 0; i < optionsSpan.Length; i++)
        {
            ref readonly var option = ref optionsSpan[i];

            if (option.TryGetValue(out FGameplayTag gameplayTag, "CustomizationVariantTag") &&
                option.TryGetValue(out bool bIsDefault, "bIsDefault"))
            {
                var tagName = gameplayTag.TagName.PlainText;

                if (bIsDefault)
                {
                    variant.Active = tagName;
                }

                variant.Owned.Add(tagName);
            }
        }

        variant.Active ??= string.Empty;

        return variant;
    }

    public const string xmlString = "http://fortmp.dev/config";
}