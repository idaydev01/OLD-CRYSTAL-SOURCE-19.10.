﻿using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Utilities.Errors.HeliosErrors;

namespace Helios.Utilities.Tokens;

public class VerifyToken
{
    public static async Task<bool> Verify(HttpContext context, HttpRequest request)
    {
        if (!request.Headers.TryGetValue("Authorization", out var authHeader) || string.IsNullOrEmpty(authHeader))
            return false;
        
        string token = authHeader.ToString().Trim();

        if (token.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            token = token.Substring("Bearer ".Length);
        if (token.StartsWith("eg1~"))
            token = token.Substring("eg1~".Length);
        
        if (token.Count(c => c == '.') != 2)
        {
            Logger.Error($"Malformed token received: {token}");
            return false;
        }

        string accountId;
        try
        {
            var decodedToken = TokenGenerator.DecodeToken(token);
            if (decodedToken == null)
                return false;
        
            accountId = decodedToken["sub"] as string;
            if (string.IsNullOrEmpty(accountId))
                return false;
        }
        catch (Exception ex)
        {
            Logger.Error("Token decoding error", ex);
            return false;
        }
        
        try
        {
            var uRepo = Constants.repositoryPool.Repo<User>();
            var user = await uRepo().FindByColumnAsync("accountid", accountId);
            if (user is null)
                return false;

            if (user.Banned)
                return false;

            if (!user.Ac)
                return false;
            
            context.Response.Cookies.Append("AccountId", accountId, new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddDays(7)
            });

            string userJson = System.Text.Json.JsonSerializer.Serialize(user);
            context.Response.Cookies.Append("User", userJson, new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddDays(7)
            });

            return true;
        }
        catch (Exception ex)
        {
            Logger.Error($"Error verifying token: {ex.Message}", ex);
            return false;
        }
    }
}