using Helios.Classes.MatchmakingServers;
using Helios.Configuration;
using RestSharp;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

namespace Helios.Utilities.Requests.GetMatchmakingServers
{
    public class GetMatchmakingServers
    {
        public static async Task<List<Servers>> GetServersAsync()
        {
            var client = new RestClient($"{Constants.BaseUrl}:{Constants.MatchmakerPort}/solstice/api/v1/servers");
            var request = new RestRequest($"{Constants.BaseUrl}:{Constants.MatchmakerPort}/solstice/api/v1/servers", Method.Get);

            try
            {
                var response = await client.ExecuteAsync<List<Servers>>(request);

                if (response.IsSuccessful)
                {
                    return response.Data ?? new List<Servers>();
                }
                else
                {
                    Logger.Error($"Error: {response.StatusCode} - {response.ErrorMessage}");
                    return new List<Servers>();
                }
            }
            catch (Exception e)
            {
                Logger.Error($"Request error: {e.Message}");
                return new List<Servers>();
            }
        }

        public static async Task<Servers?> GetServerById(string sessionId)
        {
            var client = new RestClient($"{Constants.BaseUrl}:{Constants.MatchmakerPort}");
            var request = new RestRequest($"/solstice/api/v1/servers/{sessionId}", Method.Get);

            try
            {
                var response = await client.ExecuteAsync<Servers>(request);

                if (response.IsSuccessful)
                {
                    return response.Data;
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    return null;
                }
                else
                {
                    Logger.Error($"Error: {response.StatusCode} - {response.ErrorMessage}");
                    return null;
                }
            }
            catch (Exception e)
            {
                Logger.Error($"Request error: {e.Message}");
                return null;
            }
        }

        public static async Task<Servers?> GetDedicatedServerById(string sessionId)
        {
            var client = new RestClient($"{Constants.BaseUrl}:{Constants.MatchmakerPort}");
            var request = new RestRequest($"/solstice/api/v1/servers/dedicated/{sessionId}", Method.Get);

            try
            {
                var response = await client.ExecuteAsync<Servers>(request);

                if (response.IsSuccessful)
                {
                    return response.Data;
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    return null;
                }
                else
                {
                    Logger.Error($"Error: {response.StatusCode} - {response.ErrorMessage}");
                    return null;
                }
            }
            catch (Exception e)
            {
                Logger.Error($"Request error: {e.Message}");
                return null;
            }
        }
    }
}