﻿﻿using CUE4Parse.Compression;
using CUE4Parse.Encryption.Aes;
using CUE4Parse.FileProvider;
using CUE4Parse.MappingsProvider;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Exports.Engine;
using CUE4Parse.UE4.Assets.Objects;
using CUE4Parse.UE4.Objects.Core.Misc;
using CUE4Parse.UE4.Objects.GameplayTags;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.UE4.Versions;
using CUE4Parse.Utils;
using Helios.Classes.AthenaSeason;
using Helios.Classes.HTTP;
using Helios.Classes.MCP;
using Helios.Configuration;
using Helios.Managers.Unreal.Enums;
using Helios.Utilities;
using Helios.Utilities.Caching;
using Newtonsoft.Json;
using Org.BouncyCastle.Asn1.Cms;
using Org.BouncyCastle.Utilities.IO.Pem;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using static Org.BouncyCastle.Math.EC.ECCurve;

namespace Helios.Managers.Unreal;

public class UnrealAssetProvider : IDisposable
{
    private readonly SemaphoreSlim _initializationLock = new(1, 1);
    private bool _isInitialized;
    private bool _isDisposed;
    private static readonly HttpClient _httpClient = new();
    private const string CosmeticsPath = "FortniteGame/Content/Athena/Items/Cosmetics";
    //private static readonly Dictionary<string, string> FortniteMajorVersionMap = new()
    //{
    //    { "15", "++Fortnite+Release-15.30-CL-15341163-Windows" },
    //    { "19", "++Fortnite+Release-19.10-CL-18675304-Windows" }
    //};

    private static readonly TimeSpan CosmeticsCacheDuration = TimeSpan.FromDays(120);
    public DefaultFileProvider FileProvider { get; private set; }

    public UnrealAssetProvider()
    {
        var dataPath = Path.Combine(Directory.GetCurrentDirectory(), ".data");
        Directory.CreateDirectory(dataPath);
    }

    public async Task InitializeAsync(CancellationToken cancellationToken = default)
    {
        if (_isInitialized) return;

        await _initializationLock.WaitAsync(cancellationToken);
        try
        {
            if (_isInitialized) return;

            Logger.Info($"Initializing provider with game directory: {Constants.config.GameDirectory}");
            ValidateGameDirectory(Constants.config.GameDirectory);

            var version = FVersionConverter.Convert(Constants.config.CurrentVersion);

            EGame EngineVersion = EGame.GAME_UE4_LATEST;
            if (version >= FVersion.V19_10)
                EngineVersion = EGame.GAME_UE5_0;
            if (version >= FVersion.V28_30)
                EngineVersion = EGame.GAME_UE5_4;

            FileProvider = new DefaultFileProvider(
                Constants.config.GameDirectory,
                SearchOption.TopDirectoryOnly,
                true,
                new VersionContainer(EngineVersion));

            FileProvider.Initialize();

            var aesKey = FAesProvider.GetAesKey(version)
                ?? throw new InvalidOperationException($"Failed to get AES key for version {Constants.config.CurrentVersion}");

            await FileProvider.SubmitKeyAsync(new FGuid(), new FAesKey(aesKey.Key));

            var dataPath = Path.Combine(Directory.GetCurrentDirectory(), ".data");
            await InitializeOodleAsync(dataPath);

            if (Constants.CurrentVersion >= 15)
            {
                FileProvider.MappingsContainer = await GetMappingsAsync(dataPath, Constants.config.CurrentVersion);
            }

            PrecomputeCosmeticPaths();

            Logger.Info($"Provider initialized with version {Constants.config.CurrentVersion}");
            _isInitialized = true;
        }
        finally
        {
            _initializationLock.Release();
        }
    }

    private async Task InitializeOodleAsync(string dataPath)
    {
        var oodlePath = Path.Combine(dataPath, OodleHelper.OODLE_DLL_NAME);
        if (!File.Exists(oodlePath))
        {
            await OodleHelper.DownloadOodleDllAsync(oodlePath);
        }
        OodleHelper.Initialize(oodlePath);
    }

    private async Task<FileUsmapTypeMappingsProvider> GetMappingsAsync(string dataPath, string majorVersion)
    {
        //if (!FortniteMajorVersionMap.TryGetValue(majorVersion, out var versionQuery))
        //    throw new ArgumentException($"No mapping found for major version '{majorVersion}'");

        var mappingsResponse = await _httpClient.GetStringAsync(
            $"https://fortnitecentral.genxgames.gg/api/v1/mappings?version={majorVersion}");

        var mappingsData = JsonConvert.DeserializeObject<List<MappingsResponse>>(mappingsResponse)?[0]
                            ?? throw new Exception("Failed to deserialize mappings response.");

        var path = Path.Combine(dataPath, mappingsData.FileName);
        if (!File.Exists(path))
        {
            var bytes = await _httpClient.GetByteArrayAsync(mappingsData.Url);
            await File.WriteAllBytesAsync(path, bytes);
        }

        return new FileUsmapTypeMappingsProvider(path);
    }

    private void PrecomputeCosmeticPaths()
    {
        var sw = Stopwatch.StartNew();

        List<string> cosmetics = FileProvider.Files
            .AsParallel()
            .Where(file =>
                file.Key.StartsWith(CosmeticsPath, StringComparison.OrdinalIgnoreCase)
                && file.Key.EndsWith(".uasset", StringComparison.OrdinalIgnoreCase))
            .Select(file => file.Key)
            .ToList();


        HeliosFastCache.Set(CosmeticsPath, cosmetics, CosmeticsCacheDuration);
        Logger.Info($"Precomputed {cosmetics.Count} cosmetic paths in {sw.ElapsedMilliseconds}ms");
    }

    public async Task<List<Variants>> GetVariantsAsync(string templateId)
    {
        try
        {
            string cacheKey = $"variants_{templateId}";
            if (HeliosFastCache.TryGet(cacheKey, out List<Variants> cachedVariants))
            {
                return cachedVariants;
            }

            var filteredCosmetics = await Task.Run(() => LoadAllCosmeticsAsync());
            if (filteredCosmetics == null)
            {
                Logger.Error("LoadAllCosmeticsAsync returned null");
                return new List<Variants>();
            }

            var foundItem = filteredCosmetics
                .FirstOrDefault(x => x?.ToLower().Contains(templateId.ToLower()) == true);

            if (string.IsNullOrEmpty(foundItem))
                return new List<Variants>();

            string pathWithoutExtension = Path.ChangeExtension(foundItem, null);
            string nameWithoutExtension = Path.GetFileNameWithoutExtension(foundItem);

            string coolId = $"{pathWithoutExtension}.{nameWithoutExtension}";

            if (Constants.IgnoredTemplateIds.Contains(coolId))
                return new List<Variants>();

            if (Constants.IgnoredPrefixes.Any(prefix => coolId.Contains(prefix, StringComparison.OrdinalIgnoreCase)))
            {
                return new List<Variants>();
            }

            UObject itemObj = null;
            try
            {
                itemObj = await FileProvider.LoadPackageObjectAsync(coolId);
            }
            catch (NullReferenceException ex) when (ex.Message.Contains("does not have an export"))
            {
                return new List<Variants>();
            }
            catch (Exception ex)
            {
                Logger.Error($"Unexpected error loading package: {ex}");
                return new List<Variants>();
            }

            if (itemObj == null) return new List<Variants>();

            if (!Constants.ItemDefinitionClasses.Contains(itemObj.ExportType)) 
                return new List<Variants>();

            var itemVariants = itemObj.GetOrDefault("ItemVariants", Array.Empty<UObject>());
            var variantsList = new List<Variants>();

            var variantTypes = new[]
            {
                "PartOptions", "MaterialOptions", "DynamicOptions", "GenericTagOptions",
                "LoadoutAugmentations", "ParticleOptions", "MeshOptions",
                "ActiveSelectionTag", "InlineVariant"
            };

            foreach (var variant in itemVariants)
            {
                if (variant == null) continue;

                if (!variant.TryGetValue(out FGameplayTag variantChannel, "VariantChannelTag") ||
                    variantChannel.TagName.PlainText == null)
                {
                    continue;
                }

                string rawChannelName = variantChannel.TagName.PlainText;
                string parsedChannel = Constants.ParseChannelName(rawChannelName);

                var ownedParts = new List<string>();
                string activePart = "";

                string exportType = variant.ExportType ?? string.Empty;

                string optionsName = exportType switch
                {
                    "FortCosmeticMeshVariant" => "MeshOptions",
                    "FortCosmeticMaterialVariant" => "MaterialOptions",
                    "FortCosmeticParticleVariant" => "ParticleOptions",
                    "FortCosmeticPropertyVariant" => "GenericPropertyOptions",
                    "FortCosmeticRichColorVariant" => "InlineVariant",
                    "FortCosmeticGameplayTagVariant" => "GenericTagOptions",
                    "FortCosmeticCharacterPartVariant" => "PartOptions",
                    "FortCustomizableObjectSprayVariant" => "ActiveSelectionTag",
                    "FortCustomizableObjectParameterVariant" => "ParameterOptions",
                    _ => null
                };

                if (optionsName is null)
                    continue;

                if (optionsName == "ActiveSelectionTag")
                {
                    if (variant.TryGetValue(out FStructFallback activeSectionTag, optionsName))
                    {
                        var tag = activeSectionTag.GetOrDefault("TagName", new FName("DefaultStyle")).Text;
                        if (!string.IsNullOrEmpty(tag))
                        {
                            ownedParts.Add(tag.Split("Property.").Last() + ".X=ffff0000ffffSD=");
                            activePart = tag;
                        }
                    }
                }
                else if (optionsName == "InlineVariant")
                {
                }
                else
                {
                    if (variant.TryGetValue(out FStructFallback[] options, optionsName) && options?.Length > 0)
                    {
                        foreach (var option in options)
                        {
                            if (option.TryGetValue(out FGameplayTag gameplayTag, "CustomizationVariantTag"))
                            {
                                var tag = gameplayTag.TagName.PlainText;
                                if (!string.IsNullOrEmpty(tag))
                                {
                                    if (tag.Contains("Property.Color") || tag.Contains("Vehicle.Painted") || tag.Contains("Vehicle.Tier"))
                                    {
                                        ownedParts.Add(tag.Split("Property.").Last());
                                    }
                                    else
                                    {
                                        ownedParts.Add(tag.Split('.').Last());
                                    }
                                }
                            }
                        }
                    }
                }

                if (ownedParts.Count == 0)
                {
                    foreach (var type in variantTypes)
                    {
                        if (variant.TryGetValue(out FStructFallback[] options, type) && options != null)
                        {
                            var extraVariant = Constants.CreateVariantFromOptions(options, parsedChannel);
                            variantsList.Add(extraVariant);
                            goto AddChannel;
                        }
                    }
                }

                string channel = rawChannelName.Contains("Slot") || rawChannelName.Contains("Vehicle")
                    ? rawChannelName.Split("Channel.").Last()
                    : rawChannelName.Split('.').Last();

                variantsList.Add(new Variants
                {
                    Channel = channel,
                    Active = activePart ?? "",
                    Owned = ownedParts
                });

            AddChannel:;
            }

            HeliosFastCache.Set(cacheKey, variantsList);
            return variantsList;
        }
        catch (Exception ex)
        {
            Logger.Error($"GetVariantsAsync error: {ex}");
            return new List<Variants>();
        }
    }

    private async Task<UObject> GetAthenaSeasonUObjectAsync()
    {
        if (string.IsNullOrEmpty(Constants.config?.CurrentVersion))
        {
            throw new InvalidOperationException("Config or CurrentVersion is null or empty.");
        }

        if (!int.TryParse(Constants.config.CurrentVersion.AsSpan().Slice(0, Constants.config.CurrentVersion.IndexOf('.')),
                out var majorVersion))
        {
            throw new FormatException("CurrentVersion is not in the expected format.");
        }

        // FortniteGame/Plugins/GameFeatures/BattlepassS15/Content/SeasonData/AthenaSeason15.uasset
        string validSeasonsPath = majorVersion >= 15 ? 
            $"FortniteGame/Plugins/GameFeatures/BattlepassS{majorVersion}/Content/SeasonData/AthenaSeason{majorVersion}": 
            $"FortniteGame/Content/Athena/Items/Seasons/AthenaSeason{majorVersion}";

        var uObject = await FileProvider.SafeLoadPackageObjectAsync<UObject>(validSeasonsPath);
        return uObject;
    }

    public async Task<Dictionary<int, int>> GetAthenaSeasonsAsync()
    {
        var athenaSeasonObj = await GetAthenaSeasonUObjectAsync();

        if (athenaSeasonObj == null)
        {
            throw new InvalidOperationException("Failed to load AthenaSeason UObject.");
        }

        var properties = athenaSeasonObj.Properties.AsParallel();

        foreach (var property in properties)
        {
            var propertyName = property.Name.ToString();

            switch (propertyName)
            {
                case "BookXpScheduleFree":
                    FStructFallback freeTagObject = property.Tag.GetValue<FStructFallback>();
                    FStructFallback[] freeLevels = freeTagObject.Get<FStructFallback[]>("Levels");
                    var rewardItemsFree = new List<RewardItem>();

                    for (int i = 0; i < freeLevels.Length; i++)
                    {
                        FStructFallback[] rewards = freeLevels[i].Get<FStructFallback[]>("Rewards");
                        foreach (var reward in rewards)
                        {
                            FSoftObjectPath itemDef = reward.Get<FSoftObjectPath>("ItemDefinition");

                            string assetPathName = itemDef.AssetPathName.Text;
                            if (string.IsNullOrEmpty(assetPathName) || assetPathName == "None")
                                continue;

                            string[] assetParts = assetPathName.Split('.');
                            if (assetParts.Length < 2)
                                continue;

                            string templateId = string.Empty;
                            int quantity = reward.Get<int>("Quantity");
                            string asset = assetParts[1];

                            bool mappingFound = false;

                            foreach (var mapping in TemplateMappings.assetTemplateMappings)
                            {
                                if (asset.Contains(mapping.Key))
                                {
                                    templateId = $"{mapping.Value}:{asset}";
                                    mappingFound = true;
                                    break;
                                }
                            }

                            if (!mappingFound)
                            {
                                Logger.Warn($"No mapping found for asset: {asset}");
                            }

                            if (!string.IsNullOrEmpty(templateId))
                            {
                                rewardItemsFree.Add(new RewardItem
                                {
                                    TemplateId = templateId,
                                    Quantity = quantity,
                                    Tier = i
                                });
                            }
                        }
                    }

                    HeliosFastCache.Set("BookXpScheduleFree", rewardItemsFree);
                    Logger.Info($"Successfully Parsed and Cached {propertyName}");
                    break;

                case "BookXpSchedulePaid":
                    FStructFallback tagObject = property.Tag.GetValue<FStructFallback>();
                    FStructFallback[] levels = tagObject.Get<FStructFallback[]>("Levels");

                    var rewardItemsPaid = new List<RewardItem>();

                    for (int i = 0; i < levels.Length; i++)
                    {
                        FStructFallback[] rewards = levels[i].Get<FStructFallback[]>("Rewards");
                        foreach (var reward in rewards)
                        {
                            FSoftObjectPath itemDef = reward.Get<FSoftObjectPath>("ItemDefinition");

                            string assetPathName = itemDef.AssetPathName.Text;
                            if (string.IsNullOrEmpty(assetPathName) || assetPathName == "None")
                                continue;

                            string[] assetParts = assetPathName.Split('.');
                            if (assetParts.Length < 2)
                                continue;

                            string templateId = string.Empty;
                            int quantity = reward.Get<int>("Quantity");
                            string asset = assetParts[1];

                            bool mappingFound = false;

                            foreach (var mapping in TemplateMappings.assetTemplateMappings)
                            {
                                if (asset.Contains(mapping.Key))
                                {
                                    templateId = $"{mapping.Value}:{asset}";
                                    mappingFound = true;
                                    break;
                                }
                            }

                            if (!mappingFound)
                            {
                                Logger.Warn($"No mapping found for asset: {asset}");
                            }

                            if (!string.IsNullOrEmpty(templateId))
                            {
                                rewardItemsPaid.Add(new RewardItem
                                {
                                    TemplateId = templateId,
                                    Quantity = quantity,
                                    Tier = i
                                });
                            }
                        }
                    }

                    HeliosFastCache.Set("BookXpSchedulePaid", rewardItemsPaid);
                    Logger.Info($"Successfully Parsed and Cached {propertyName}");
                    break;

                case "SeasonXpCurve":
                    UDataTable seasonXpCurve = property.Tag.GetValue<UDataTable>();

                    if (seasonXpCurve is { RowMap: not null and { Count: > 0 } rowMap })
                    {
                        var list = new List<SeasonXpCurve>(rowMap.Count);

                        foreach (var (rowId, structDef) in rowMap)
                        {
                            list.Add(new SeasonXpCurve
                            {
                                Level = structDef.Get<int>("Level"),
                                XpTotal = structDef.Get<int>("XpTotal"),
                                XpToNextLevel = structDef.Get<int>("XpToNextLevel"),
                                RowId = rowId.PlainText
                            });
                        }

                        HeliosFastCache.Set("SeasonXpCurve", list);
                        Logger.Info($"Successfully Parsed and Cached {propertyName}");
                    }
                    break;

                case "SeasonXpScheduleFree":
                    FStructFallback starsTagObject = property.Tag.GetValue<FStructFallback>();
                    FStructFallback[] starsLevels = starsTagObject.Get<FStructFallback[]>("Levels");

                    var athenaBattleStars = new List<AthenaBattleStars>();
                    var seenLevels = new HashSet<int>();

                    for (int i = 0; i < starsLevels.Length; i++)
                    {
                        FStructFallback[] rewards = starsLevels[i].Get<FStructFallback[]>("Rewards");

                        int totalQuantity = 0;

                        foreach (var reward in rewards)
                        {
                            int quantity = reward.Get<int>("Quantity");
                            totalQuantity += quantity;
                        }

                        if (!seenLevels.Contains(i))
                        {
                            athenaBattleStars.Add(new AthenaBattleStars
                            {
                                Level = i,
                                Amount = totalQuantity
                            });

                            seenLevels.Add(i);
                        }
                    }

                    HeliosFastCache.Set("SeasonXpScheduleFree", athenaBattleStars);
                    Logger.Info($"Successfully Parsed and Cached {propertyName}");
                    break;

                default:
                    break;
            }
        }

        return new Dictionary<int, int>();
    }

    public Task<List<string>> LoadAllCosmeticsAsync(CancellationToken cancellationToken = default)
    {
        return HeliosFastCache.TryGet<List<string>>(CosmeticsPath, out var cached)
            ? Task.FromResult(cached)
            : Task.FromResult(new List<string>());
    }

    private void ValidateGameDirectory(string gameDirectory)
    {
        if (!Directory.Exists(gameDirectory))
            throw new DirectoryNotFoundException($"Game directory not found: {gameDirectory}");

        try
        {
            Directory.GetFileSystemEntries(gameDirectory);
        }
        catch (UnauthorizedAccessException ex)
        {
            throw new UnauthorizedAccessException($"Access denied to game directory: {ex.Message}", ex);
        }
    }


    public void Dispose()
    {
        if (_isDisposed) return;

        FileProvider?.Dispose();
        _initializationLock?.Dispose();
        _isDisposed = true;
        GC.SuppressFinalize(this);
    }
}