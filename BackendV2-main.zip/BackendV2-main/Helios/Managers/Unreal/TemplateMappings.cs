using Helios.Configuration;
using static Org.BouncyCastle.Math.EC.ECCurve;

namespace Helios.Managers.Unreal
{
    public class TemplateMappings
    {
        public static readonly Dictionary<string, string> assetTemplateMappings = new()
        {
            { "EID", "AthenaDance" },
            { "Emoji", "AthenaDance" },
            { "SPID", "AthenaDance" },
            { "TOY", "AthenaDance" },
            { "LSID", "AthenaLoadingScreen" },
            { "Trails", "AthenaSkyDiveContrail" },
            { "MtxGiveaway", "Currency" },
            { "Glider", "AthenaGlider" },
            { "BID", "AthenaBackpack" },
            { "PetCarrier", "AthenaBackpack" },
            { "MusicPack", "AthenaMusicPack" },
            { "Pickaxe", "AthenaPickaxe" },
            { "AthenaSeasonXpBoost", "Token" },
            { "AthenaSeasonFriendXpBoost", "Token" },
            { "CID", "AthenaCharacter" },
            { "AthenaSeasonMergedXpBoosts", "Token" },
            { "Wrap", "AthenaItemWrap" },
            { "AthenaSeasonalXP", "Token" },
            { "AthenaNextSeasonTierBoost", "Token" },
            { $"Season{int.Parse(Constants.config.CurrentVersion.Split('.')[0])}_", "ChallengeBundleSchedule" },
            { "AthenaNextSeasonXPBoost", "Token" },
            { "VTID", "CosmeticVariantToken" }
        };

        public static string GetMappedTemplateId(string asset, string originalTemplateId)
        {
            foreach (var mapping in assetTemplateMappings)
            {
                if (asset.Contains(mapping.Key))
                {
                    return $"{mapping.Value}:{asset}";
                }
            }

            return originalTemplateId;
        }
    }
}
