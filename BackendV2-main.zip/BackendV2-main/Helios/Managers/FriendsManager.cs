﻿using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Utilities.Extensions;
using Newtonsoft.Json;

namespace Helios.Managers
{
    public static class FriendsManager
    {
        public const string StatusPending = "PENDING";
        public const string StatusAccepted = "ACCEPTED";
        public const string DirectionOutbound = "OUTBOUND";
        public const string DirectionInbound = "INBOUND";

        public static async Task CreateFriendshipAsync(string accountId, string friendId, string direction)
        {
            await Constants.repositoryPool.For<Friends>().SaveAsync(new Friends
            {
                AccountId = accountId,
                FriendId = friendId,
                Status = StatusPending,
                Direction = direction,
                CreatedAt = DateTime.UtcNow.ToIsoUtcString(),
                Alias = string.Empty
            });
        }

        public static string GetDirection(Friends friend)
        {
            if (friend.Status == StatusAccepted)
                return DirectionOutbound;

            return friend.Direction;
        }

        public static object CreateStanzaPayload(string friendId, string status, string direction, string timestamp)
        {
            return new
            {
                payload = new
                {
                    accountId = friendId,
                    status,
                    direction,
                    created = timestamp,
                    favorite = false
                },
                type = "com.epicgames.friends.core.apiobjects.Friend",
                timestamp
            };
        }

        public static async Task SendStanzaAsync(string toAccountId, object stanza)
        {
            string json = JsonConvert.SerializeObject(stanza);
            await Constants.GlobalXmppClientService.ForwardMessageAsync(toAccountId, json);
        }
    }
}