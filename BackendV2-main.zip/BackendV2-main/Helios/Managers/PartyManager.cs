﻿using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Party;
using Helios.Database.Tables.XMPP;
using Helios.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Concurrent;
using System.Xml.Linq;
using JsonException = System.Text.Json.JsonException;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace Helios.Managers;

public class PartyManager : IDisposable
{
    private readonly Func<Repository<Parties>> _pRepo = Constants.repositoryPool.Repo<Parties>(false);
    private ConcurrentDictionary<string, Parties> _parties = new();
    private Timer _cleanupTimer;
    private bool _disposed;
    private bool _initialized = false;
    private DateTime _lastCleanupTime;

    private const int CLEANUP_INTERVAL_SECONDS = 15;

    public PartyManager()
    {
        _cleanupTimer = new Timer(CleanupAndRefreshData, null, TimeSpan.Zero, TimeSpan.FromSeconds(CLEANUP_INTERVAL_SECONDS));
        _lastCleanupTime = DateTime.Now;
        Logger.Info($"PartyManager initialized.");
    }

    public async Task InitializeAsync()
    {
        try
        {
            await RefreshDataFromDatabase();
            _initialized = true;
            Logger.Info("PartyManager initialized successfully.");
        }
        catch (Exception ex)
        {
            Logger.Error($"Error initializing PartyManager: {ex}");
            throw;
        }
    }

    private async Task RefreshDataFromDatabase()
    {
        try
        {
            var parties = await _pRepo().FindAllByTableAsync(useCache: false);
            var distinctParties = parties.DistinctBy(p => p.PartyId).ToList();

            if (distinctParties.Count < parties.Count)
            {
            }

            var validParties = distinctParties.Where(p => !string.IsNullOrEmpty(p.PartyId)).ToList();

            if (validParties.Count < distinctParties.Count)
            {

            }

            var updatedParties = new ConcurrentDictionary<string, Parties>(
                validParties.Select(p => new KeyValuePair<string, Parties>(p.PartyId, p)));

            _parties = updatedParties;
        }
        catch (Exception ex)
        {
            Logger.Error($"Error refreshing data from database: {ex}");
        }
    }

    private async void CleanupAndRefreshData(object? state)
    {
        if (_disposed || !_initialized) return;

        TimeSpan elapsed = DateTime.Now - _lastCleanupTime;
        _lastCleanupTime = DateTime.Now;

        await RefreshDataFromDatabase();

        var partiesToRemove = new List<Parties>();

        foreach (var party in _parties.Values)
        {
            try
            {
                var partyMembers = JsonSerializer.Deserialize<List<PartyMember>>(party.Members);

                if (partyMembers == null)
                {
                    Logger.Warn($"Failed to deserialize members for party {party.PartyId}");
                    partiesToRemove.Add(party);
                    continue;
                }

                bool anyActiveMembers = false;

                try
                {
                    var connectedUsersResponse = await Constants.GlobalXmppClientService.GetConnectedUsersAsync();

                    anyActiveMembers = false;

                    if (connectedUsersResponse?.Users != null && connectedUsersResponse.Users.Count > 0)
                    {
                        var connectedAccountIds = new HashSet<string>();

                        foreach (var jid in connectedUsersResponse.Users)
                        {
                            if (string.IsNullOrWhiteSpace(jid)) continue;

                            var atIndex = jid.IndexOf('@');
                            if (atIndex > 0)
                            {
                                var accountId = jid.Substring(0, atIndex);
                                if (!string.IsNullOrEmpty(accountId))
                                    connectedAccountIds.Add(accountId);
                            }
                        }

                        anyActiveMembers = partyMembers.Any(member =>
                            !string.IsNullOrEmpty(member.AccountId) &&
                            connectedAccountIds.Contains(member.AccountId));
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Error checking connected users via XMPP service: {ex.Message}");
                    anyActiveMembers = true;
                }

                if (!anyActiveMembers)
                {
                    partiesToRemove.Add(party);
                }
            }
            catch (JsonException ex)
            {
                Logger.Error($"Error deserializing party {party.PartyId}: {ex.Message}");
                partiesToRemove.Add(party);
            }
        }

        var successfullyDeletedParties = new List<string>();

        foreach (var party in partiesToRemove)
        {
            try
            {
                Logger.Info($"Attempting to delete party {party.PartyId}");

                var verifyDeleted = await _pRepo().DeleteByColumnAsync("partyid", party.PartyId);

                if (verifyDeleted)
                {
                    successfullyDeletedParties.Add(party.PartyId);
                }
                else
                {
                    Logger.Error($"Party {party.PartyId} still exists in database after deletion attempt");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to delete party {party.PartyId} from database: {ex.Message}");
            }
        }

        foreach (var partyId in successfullyDeletedParties)
        {
            if (_parties.TryRemove(partyId, out var removedParty))
            {
            }
            else
            {
                Logger.Warn($"Party {partyId} was not found in memory cache during removal");
            }
        }

        if (partiesToRemove.Count > 0)
        {
            var failedDeletions = partiesToRemove.Where(p => !successfullyDeletedParties.Contains(p.PartyId)).ToList();
            if (failedDeletions.Any())
            {
                Logger.Warn($"Failed to delete parties: {string.Join(", ", failedDeletions.Select(p => p.PartyId))}");
            }
        }

        EnsureTimerIsRunning();
    }

    private void EnsureTimerIsRunning()
    {
        try
        {
            _cleanupTimer?.Dispose();

            _cleanupTimer = new Timer(CleanupAndRefreshData, null,
                TimeSpan.FromSeconds(CLEANUP_INTERVAL_SECONDS),
                TimeSpan.FromSeconds(CLEANUP_INTERVAL_SECONDS));
        }
        catch (Exception ex)
        {
            Logger.Error($"Error resetting cleanup timer: {ex.Message}");
        }
    }

    public static string CreateXmlMessage(string jid, string body)
    {
        var xml = new XElement(XNamespace.Get("jabber:client") + "message",
            new XAttribute("xmlns", "jabber:client"),
            new XAttribute("to", jid),
            new XAttribute("from", "xmpp-admin@prod.ol.epicgames.com"),
            new XElement("body", body)
        );
        return xml.ToString(SaveOptions.DisableFormatting);
    }

    private static object ExtractJTokenValue(JToken token)
    {
        switch (token.Type)
        {
            case JTokenType.String:
                return token.Value<string>();
            case JTokenType.Integer:
                return token.Value<long>();
            case JTokenType.Float:
                return token.Value<double>();
            case JTokenType.Boolean:
                return token.Value<bool>();
            case JTokenType.Object:
                return ConvertJTokenToObject(token);
            case JTokenType.Array:
                return token.Select(ExtractJTokenValue).ToList();
            case JTokenType.Null:
                return null;
            default:
                return token.ToString();
        }
    }

    public static Dictionary<string, object> ConvertJTokenToObject(JToken token)
    {
        var result = new Dictionary<string, object>();

        if (token is JObject jObject)
        {
            foreach (var property in jObject.Properties())
            {
                result[property.Name] = ExtractJTokenValue(property.Value);
            }
        }

        return result;
    }

    public (string PartyId, List<string> PartyMembers, string LeaderAccountId) GetUserPartyInfo(string accountId)
    {
        var party = _parties.Values.FirstOrDefault(p =>
        {
            try
            {
                var members = JsonSerializer.Deserialize<List<PartyMember>>(p.Members);
                return members?.Any(m => m.AccountId == accountId) == true;
            }
            catch (JsonException ex)
            {
                Logger.Warn($"Failed to deserialize party members for party {p.PartyId}: {ex.Message}");
                return false;
            }
        });

        string partyId = party?.PartyId ?? "none";
        var partyMembers = new List<string>();
        string leaderAccountId = "none";

        if (party != null)
        {
            try
            {
                var members = JsonSerializer.Deserialize<List<PartyMember>>(party.Members);
                if (members != null)
                {
                    partyMembers = members
                        .Where(m => !string.IsNullOrWhiteSpace(m.AccountId))
                        .Select(m => m.AccountId)
                        .ToList();

                    var leader = members.FirstOrDefault(m =>
                        !string.IsNullOrWhiteSpace(m.Role) &&
                        m.Role.Equals("CAPTAIN", StringComparison.OrdinalIgnoreCase));

                    if (leader != null)
                        leaderAccountId = leader.AccountId;
                }
            }
            catch (JsonException ex)
            {
                Logger.Warn($"Failed to deserialize members for party {party.PartyId}: {ex.Message}");
            }
        }

        return (partyId, partyMembers, leaderAccountId);
    }


    public async Task<bool> IsUserConnectedAsync(string accountId)
    {
        if (string.IsNullOrEmpty(accountId))
            return false;

        try
        {
            var connectedUsersResponse = await Constants.GlobalXmppClientService.GetConnectedUsersAsync();
            return connectedUsersResponse?.Users?.Contains(accountId) == true;
        }
        catch (Exception ex)
        {
            Logger.Error($"Error checking if user {accountId} is connected: {ex.Message}");
            return false;
        }
    }

    public void Dispose()
    {
        if (!_disposed)
        {
            _cleanupTimer?.Dispose();
            _disposed = true;
            Logger.Info("PartyManager disposed");
        }
    }
}