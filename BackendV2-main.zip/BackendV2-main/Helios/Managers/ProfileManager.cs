﻿using Helios.Classes.MCP;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Profiles;
using Helios.Utilities;
using Helios.Utilities.Caching;
using Helios.Utilities.Profile;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Helios.Managers;

public static class ProfileManager
{
    private static readonly TimeSpan DefaultCacheExpiration = TimeSpan.FromMinutes(15);
    private static readonly TimeSpan SemaphoreTimeout = TimeSpan.FromSeconds(30);
    private static readonly TimeSpan DatabaseTimeout = TimeSpan.FromSeconds(30);
    private static readonly int MaxRetryAttempts = 3;
    private static readonly TimeSpan BaseRetryDelay = TimeSpan.FromMilliseconds(500);

    private static readonly Dictionary<string, Func<string, List<Items>>> ProfileTypeInitializers = new();
    private static readonly ConcurrentDictionary<string, SemaphoreSlim> KeyLocks = new();
    private static readonly object InitializerLock = new object();
    private static volatile bool _initializerRegistered = false;

    static ProfileManager()
    {
        try
        {
            RegisterDefaultProfileInitializers();
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to initialize ProfileManager: {ex.Message}");
            throw;
        }
    }

    private static void RegisterDefaultProfileInitializers()
    {
        if (_initializerRegistered) return;

        lock (InitializerLock)
        {
            if (_initializerRegistered) return;

            try
            {
                ProfileTypeInitializers["athena"] = CreateAthenaItems;
                ProfileTypeInitializers["common_core"] = CreateCommonCoreItems;
                _initializerRegistered = true;

                Logger.Info("Profile type initializers registered successfully");
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to register profile initializers: {ex.Message}");
                throw;
            }
        }
    }

    public static async Task<Profiles> CreateProfileAsync(string type, string accountId, CancellationToken cancellationToken = default)
    {
        ValidateInputs(accountId, type);

        accountId = accountId.Trim();
        type = type.Trim().ToLowerInvariant();

        var cacheKey = GenerateCacheKey(accountId, type);
        var keyLock = KeyLocks.GetOrAdd(cacheKey, _ => new SemaphoreSlim(1, 1));

        var acquired = false;
        try
        {
            acquired = await keyLock.WaitAsync(SemaphoreTimeout, cancellationToken);
            if (!acquired)
            {
                Logger.Warn($"Timeout waiting for semaphore for profile creation: {cacheKey}");
                throw new TimeoutException($"Timeout waiting for profile creation lock: {cacheKey}");
            }

            cancellationToken.ThrowIfCancellationRequested();

            if (HeliosFastCache.TryGet<Profiles>(cacheKey, out var cachedProfile) && cachedProfile != null)
            {
                return cachedProfile;
            }

            var existingProfile = await GetExistingProfileWithRetry(accountId, type, cancellationToken);
            if (existingProfile != null)
            {
                await CacheProfileSafely(cacheKey, existingProfile);
                return existingProfile;
            }

            return await CreateNewProfileWithRetry(type, accountId, cacheKey, cancellationToken);
        }
        catch (OperationCanceledException)
        {
            Logger.Info($"Profile creation cancelled: {cacheKey}");
            throw;
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to create profile {type} for {accountId}: {ex.Message}");

            RemoveCacheSafely(cacheKey);
            throw;
        }
        finally
        {
            if (acquired)
            {
                keyLock.Release();
            }
        }
    }

    public static async Task<Profiles> GetProfileAsync(string type, string accountId, CancellationToken cancellationToken = default)
    {
        ValidateInputs(accountId, type);

        accountId = accountId.Trim();
        type = type.Trim().ToLowerInvariant();

        var cacheKey = GenerateCacheKey(accountId, type);

        try
        {
            var result = await HeliosFastCache.GetOrAddAsync(cacheKey, async () =>
            {
                cancellationToken.ThrowIfCancellationRequested();
                return await GetExistingProfileWithRetry(accountId, type, cancellationToken);
            }, DefaultCacheExpiration);

            return result;
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to get profile {type} for {accountId}: {ex.Message}");
            throw;
        }
    }

    public static async Task<bool> UpdateProfileAsync(Profiles profile, CancellationToken cancellationToken = default)
    {
        if (profile == null)
            throw new ArgumentNullException(nameof(profile));

        if (string.IsNullOrWhiteSpace(profile.AccountId) || string.IsNullOrWhiteSpace(profile.ProfileId))
            throw new ArgumentException("Invalid profile data (missing AccountId or ProfileId)");

        var cacheKey = GenerateCacheKey(profile.AccountId.Trim(), profile.ProfileId.Trim().ToLowerInvariant());

        try
        {
            var success = await UpdateProfileWithRetry(profile, cancellationToken);

            if (success)
            {
                await CacheProfileSafely(cacheKey, profile);
            }
            else
            {
                RemoveCacheSafely(cacheKey);
                Logger.Warn($"Profile update failed, removed from cache: {cacheKey}");
            }

            return success;
        }
        catch (Exception ex)
        {
            Logger.Error($"Update failed for {cacheKey}: {ex.Message}");
            RemoveCacheSafely(cacheKey);
            return false;
        }
    }

    public static bool IsValidProfileType(string type)
    {
        if (string.IsNullOrWhiteSpace(type))
            return false;

        return ProfileTypeInitializers.ContainsKey(type.Trim().ToLowerInvariant());
    }

    public static IReadOnlyList<string> GetSupportedProfileTypes()
    {
        try
        {
            return ProfileTypeInitializers.Keys.ToList().AsReadOnly();
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to get supported profile types: {ex.Message}");
            return new List<string>().AsReadOnly();
        }
    }

    private static void ValidateInputs(string accountId, string type)
    {
        if (string.IsNullOrWhiteSpace(accountId))
            throw new ArgumentException("Account ID cannot be null or empty", nameof(accountId));
        if (string.IsNullOrWhiteSpace(type))
            throw new ArgumentException("Profile type cannot be null or empty", nameof(type));
    }

    private static string GenerateCacheKey(string accountId, string type)
    {
        return $"profile_{accountId}_{type}".ToLowerInvariant();
    }

    private static async Task<Profiles> GetExistingProfileWithRetry(string accountId, string type, CancellationToken cancellationToken)
    {
        Exception lastException = null;

        for (int attempt = 1; attempt <= MaxRetryAttempts; attempt++)
        {
            try
            {
                cancellationToken.ThrowIfCancellationRequested();

                var profileRepository = Constants.repositoryPool?.Repo<Profiles>();
                if (profileRepository == null)
                {
                    throw new InvalidOperationException("Profile repository is not available");
                }

                using var timeoutCts = new CancellationTokenSource(DatabaseTimeout);
                using var combinedCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, timeoutCts.Token);

                var result = await profileRepository().FindAsync(new Profiles
                {
                    AccountId = accountId,
                    ProfileId = type
                });

                return result;
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                lastException = ex;
                Logger.Warn($"Database operation failed (attempt {attempt}/{MaxRetryAttempts}) for {accountId}:{type}: {ex.Message}");

                if (attempt < MaxRetryAttempts)
                {
                    var delay = TimeSpan.FromMilliseconds(BaseRetryDelay.TotalMilliseconds * Math.Pow(2, attempt - 1));
                    await Task.Delay(delay, cancellationToken);
                }
            }
        }

        Logger.Error($"All retry attempts failed for GetExistingProfile {accountId}:{type}: {lastException?.Message}");
        throw lastException ?? new InvalidOperationException("Unknown error occurred during profile retrieval");
    }

    private static async Task<Profiles> CreateNewProfileWithRetry(string type, string accountId, string cacheKey, CancellationToken cancellationToken)
    {
        var stopwatch = Stopwatch.StartNew();
        Exception lastException = null;

        for (int attempt = 1; attempt <= MaxRetryAttempts; attempt++)
        {
            try
            {
                cancellationToken.ThrowIfCancellationRequested();

                var newProfile = new Profiles
                {
                    AccountId = accountId,
                    ProfileId = type,
                    Revision = 0,
                };

                var profileRepository = Constants.repositoryPool?.Repo<Profiles>();
                if (profileRepository == null)
                {
                    throw new InvalidOperationException("Profile repository is not available");
                }

                await profileRepository().SaveAsync(newProfile);

                var itemsToCreate = GetItemsForProfileType(type, accountId);
                if (itemsToCreate != null && itemsToCreate.Count > 0)
                {
                    await SaveItemsWithRetry(itemsToCreate, cancellationToken);
                }

                await CacheProfileSafely(cacheKey, newProfile);

                stopwatch.Stop();
                return newProfile;
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                lastException = ex;
                Logger.Warn($"Profile creation failed (attempt {attempt}/{MaxRetryAttempts}) for {accountId}:{type}: {ex.Message}");

                if (attempt < MaxRetryAttempts)
                {
                    var delay = TimeSpan.FromMilliseconds(BaseRetryDelay.TotalMilliseconds * Math.Pow(2, attempt - 1));
                    await Task.Delay(delay, cancellationToken);
                }
            }
        }

        stopwatch.Stop();
        Logger.Error($"All retry attempts failed for CreateNewProfile {accountId}:{type} after {stopwatch.ElapsedMilliseconds}ms: {lastException?.Message}");
        throw lastException ?? new InvalidOperationException("Unknown error occurred during profile creation");
    }

    private static List<Items> GetItemsForProfileType(string type, string accountId)
    {
        try
        {
            if (ProfileTypeInitializers.TryGetValue(type, out var initializer) && initializer != null)
            {
                var items = initializer(accountId);
                if (items != null)
                {
                    return items;
                }
            }

            Logger.Warn($"No initializer found for profile type: {type}");
            return new List<Items>();
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to generate items for profile type {type}: {ex.Message}");
            return new List<Items>();
        }
    }

    private static async Task SaveItemsWithRetry(List<Items> items, CancellationToken cancellationToken)
    {
        if (items == null || items.Count == 0)
            return;

        var itemsRepository = Constants.repositoryPool?.Repo<Items>();
        if (itemsRepository == null)
        {
            throw new InvalidOperationException("Items repository is not available");
        }

        Exception lastException = null;

        for (int attempt = 1; attempt <= MaxRetryAttempts; attempt++)
        {
            try
            {
                cancellationToken.ThrowIfCancellationRequested();

                try
                {
                    await itemsRepository().BulkSaveAsync(items);
                    return;
                }
                catch (NotImplementedException)
                {
                    var successCount = 0;
                    foreach (var item in items)
                    {
                        try
                        {
                            cancellationToken.ThrowIfCancellationRequested();
                            await itemsRepository().SaveAsync(item);
                            successCount++;
                        }
                        catch (Exception itemEx)
                        {
                            Logger.Warn($"Failed to save individual item: {itemEx.Message}");
                        }
                    }
                    return;
                }
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                lastException = ex;
                Logger.Warn($"Items save failed (attempt {attempt}/{MaxRetryAttempts}): {ex.Message}");

                if (attempt < MaxRetryAttempts)
                {
                    var delay = TimeSpan.FromMilliseconds(BaseRetryDelay.TotalMilliseconds * Math.Pow(2, attempt - 1));
                    await Task.Delay(delay, cancellationToken);
                }
            }
        }

        Logger.Error($"All retry attempts failed for SaveItems: {lastException?.Message}");
        throw lastException ?? new InvalidOperationException("Unknown error occurred during items save");
    }

    private static async Task<bool> UpdateProfileWithRetry(Profiles profile, CancellationToken cancellationToken)
    {
        Exception lastException = null;

        for (int attempt = 1; attempt <= MaxRetryAttempts; attempt++)
        {
            try
            {
                cancellationToken.ThrowIfCancellationRequested();

                var profileRepository = Constants.repositoryPool?.Repo<Profiles>();
                if (profileRepository == null)
                {
                    throw new InvalidOperationException("Profile repository is not available");
                }

                await profileRepository().UpdateAsync(profile);
                return true;
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                lastException = ex;
                Logger.Warn($"Profile update failed (attempt {attempt}/{MaxRetryAttempts}): {ex.Message}");

                if (attempt < MaxRetryAttempts)
                {
                    var delay = TimeSpan.FromMilliseconds(BaseRetryDelay.TotalMilliseconds * Math.Pow(2, attempt - 1));
                    await Task.Delay(delay, cancellationToken);
                }
            }
        }

        Logger.Error($"All retry attempts failed for UpdateProfile: {lastException?.Message}");
        return false;
    }

    private static async Task CacheProfileSafely(string cacheKey, Profiles profile)
    {
        try
        {
            if (profile != null && !string.IsNullOrEmpty(cacheKey))
            {
                HeliosFastCache.Set(cacheKey, profile, DefaultCacheExpiration);
            }
        }
        catch (Exception ex)
        {
            Logger.Warn($"Failed to cache profile {cacheKey}: {ex.Message}");
        }
    }

    private static void RemoveCacheSafely(string cacheKey)
    {
        try
        {
            if (!string.IsNullOrEmpty(cacheKey))
            {
                HeliosFastCache.Remove(cacheKey);
            }
        }
        catch (Exception ex)
        {
            Logger.Warn($"Failed to remove cache entry {cacheKey}: {ex.Message}");
        }
    }

    private static List<Items> CreateCommonCoreItems(string accountId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(accountId))
            {
                Logger.Warn("Cannot create common_core items: accountId is null or empty");
                return new List<Items>();
            }

            var item = ProfileItemCreator.CreateCCItem("common_core", accountId, "Currency:MtxPurchased");
            if (item != null)
            {
                return new List<Items> { item };
            }

            Logger.Warn($"CreateCCItem returned null for {accountId}");
            return new List<Items>();
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to create common_core items for {accountId}: {ex.Message}");
            return new List<Items>();
        }
    }

    private static List<Items> CreateAthenaItems(string accountId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(accountId))
            {
                Logger.Warn("Cannot create athena items: accountId is null or empty");
                return new List<Items>();
            }

            var items = new List<Items>(capacity: 120);

            var coreItems = new[]
            {
                "AthenaPickaxe:DefaultPickaxe",
                "AthenaGlider:DefaultGlider",
                "AthenaDance:EID_DanceMoves",
                "AthenaCharacter:CID_001_Athena_Commando_F_Default"
            };

            foreach (var itemId in coreItems)
            {
                try
                {
                    var item = ProfileItemCreator.CreateItem("athena", accountId, itemId);
                    if (item != null)
                    {
                        items.Add(item);
                    }
                    else
                    {
                        Logger.Warn($"CreateItem returned null for {itemId}");
                    }
                }
                catch (Exception ex)
                {
                    Logger.Warn($"Failed to create core item {itemId} for {accountId}: {ex.Message}");
                }
            }

            try
            {
                var loadoutItem = ProfileItemCreator.CreateLoadoutItem("athena", accountId, "fortniteloadout1");
                if (loadoutItem != null)
                {
                    items.Add(loadoutItem);
                }
                else
                {
                    Logger.Warn($"CreateLoadoutItem returned null for {accountId}");
                }
            }
            catch (Exception ex)
            {
                Logger.Warn($"Failed to create loadout item for {accountId}: {ex.Message}");
            }

            var statItems = CreateAthenaStatItems();
            if (statItems != null)
            {
                foreach (var kvp in statItems)
                {
                    try
                    {
                        var statItem = ProfileItemCreator.CreateStatItem("athena", accountId, kvp.Key, kvp.Value);
                        if (statItem != null)
                        {
                            items.Add(statItem);
                        }
                        else
                        {
                            Logger.Warn($"CreateStatItem returned null for {kvp.Key}");
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Warn($"Failed to create stat item {kvp.Key} for {accountId}: {ex.Message}");
                    }
                }
            }

            return items;
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to create athena items for {accountId}: {ex.Message}");
            return new List<Items>();
        }
    }

    private static Dictionary<string, object> CreateAthenaStatItems()
    {
        try
        {
            var currentTime = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

            return new Dictionary<string, object>
            {
                ["use_random_loadout"] = false,
                ["past_seasons"] = new List<PastSeasons>(),
                ["season_match_boost"] = 0,
                ["loadouts"] = new List<string> { "fortniteloadout1" },
                ["mfa_reward_claimed"] = false,
                ["rested_xp_overflow"] = 0,
                ["current_mtx_platform"] = "Epic",
                ["last_xp_interaction"] = currentTime,
                ["quest_manager"] = new QuestManager
                {
                    DailyLoginInterval = "0001-01-01T00:00:00.000Z",
                    DailyQuestRerolls = 1,
                    QuestPoolStats = new QuestPoolStats()
                },
                ["book_level"] = 1,
                ["season_num"] = 13,
                ["book_xp"] = 0,
                ["creative_dynamic_xp"] = new Dictionary<string, int>(),
                ["party_assist_quest"] = "",
                ["pinned_quest"] = "",
                ["vote_data"] = new VoteData
                {
                    ElectionId = "",
                    VoteHistory = new Dictionary<string, object>(),
                    VotesRemaining = 0,
                    LastVoteGranted = ""
                },
                ["lifetime_wins"] = 0,
                ["book_purchased"] = false,
                ["rested_xp_exchange"] = 1,
                ["level"] = 1,
                ["rested_xp"] = 2500,
                ["rested_xp_mult"] = 4.4,
                ["accountLevel"] = 1,
                ["rested_xp_cumulative"] = 52500,
                ["xp"] = 0,
                ["battlestars"] = 0,
                ["battlestars_season_total"] = 0,
                ["season_friend_match_boost"] = 0,
                ["active_loadout_index"] = 0,
                ["purchased_bp_offers"] = new List<string>(),
                ["purchased_battle_pass_tier_offers"] = new List<string>(),
                ["last_match_end_datetime"] = "",
                ["mtx_purchase_history_copy"] = new List<object>(),
                ["last_applied_loadout"] = "",
                ["favorite_musicpack"] = "",
                ["banner_icon"] = "BRSeason01",
                ["favorite_character"] = "AthenaCharacter:CID_001_Athena_Commando_F_Default",
                ["favorite_itemwraps"] = new List<string> { "", "", "", "", "", "", "" },
                ["favorite_skydivecontrail"] = "",
                ["favorite_pickaxe"] = "AthenaPickaxe:DefaultPickaxe",
                ["favorite_glider"] = "AthenaGlider:DefaultGlider",
                ["favorite_backpack"] = "",
                ["favorite_dance"] = new List<string> { "", "", "", "", "", "", "" },
                ["favorite_loadingscreen"] = "",
                ["banner_color"] = "DefaultColor1",
            };
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to create athena stat items: {ex.Message}");
            return new Dictionary<string, object>();
        }
    }

    public static async Task<bool> DeleteProfileAsync(string type, string accountId, CancellationToken cancellationToken = default)
    {
        ValidateInputs(accountId, type);

        accountId = accountId.Trim();
        type = type.Trim().ToLowerInvariant();

        var cacheKey = GenerateCacheKey(accountId, type);
        var keyLock = KeyLocks.GetOrAdd(cacheKey, _ => new SemaphoreSlim(1, 1));

        var acquired = false;
        try
        {
            acquired = await keyLock.WaitAsync(SemaphoreTimeout, cancellationToken);
            if (!acquired)
            {
                Logger.Warn($"Timeout waiting for semaphore for profile deletion: {cacheKey}");
                throw new TimeoutException($"Timeout waiting for profile deletion lock: {cacheKey}");
            }

            cancellationToken.ThrowIfCancellationRequested();

            RemoveCacheSafely(cacheKey);

            var success = await DeleteProfileDataWithRetry(accountId, type, cancellationToken);

            if (success)
            {
                Logger.Info($"Successfully deleted profile {type} for account {accountId}");
            }
            else
            {
                Logger.Warn($"Failed to fully delete profile {type} for account {accountId}");
            }

            return success;
        }
        catch (OperationCanceledException)
        {
            Logger.Info($"Profile deletion cancelled: {cacheKey}");
            throw;
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to delete profile {type} for {accountId}: {ex.Message}");
            throw;
        }
        finally
        {
            if (acquired)
            {
                keyLock.Release();
                KeyLocks.TryRemove(cacheKey, out _);
            }
        }
    }

    private static async Task<bool> DeleteProfileDataWithRetry(string accountId, string type, CancellationToken cancellationToken)
    {
        Exception lastException = null;
        var stopwatch = Stopwatch.StartNew();

        for (int attempt = 1; attempt <= MaxRetryAttempts; attempt++)
        {
            try
            {
                cancellationToken.ThrowIfCancellationRequested();

                var profileRepository = Constants.repositoryPool?.Repo<Profiles>();
                var itemsRepository = Constants.repositoryPool?.Repo<Items>();

                if (profileRepository == null || itemsRepository == null)
                {
                    throw new InvalidOperationException("Repositories are not available");
                }

                var itemsDeleteSuccess = await DeleteItemsWithRetry(itemsRepository, accountId, type, cancellationToken);

                var profileDeleteSuccess = await profileRepository().DeleteAsync(new Profiles
                {
                    AccountId = accountId,
                    ProfileId = type
                });

                stopwatch.Stop();
                Logger.Info($"Deleted profile {type} for {accountId} in {stopwatch.ElapsedMilliseconds}ms (attempt {attempt})");

                return itemsDeleteSuccess && profileDeleteSuccess > 0;
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                lastException = ex;
                Logger.Warn($"Profile deletion failed (attempt {attempt}/{MaxRetryAttempts}) for {accountId}:{type}: {ex.Message}");

                if (attempt < MaxRetryAttempts)
                {
                    var delay = TimeSpan.FromMilliseconds(BaseRetryDelay.TotalMilliseconds * Math.Pow(2, attempt - 1));
                    await Task.Delay(delay, cancellationToken);
                }
            }
        }

        stopwatch.Stop();
        Logger.Error($"All retry attempts failed for DeleteProfileData {accountId}:{type} after {stopwatch.ElapsedMilliseconds}ms: {lastException?.Message}");
        throw lastException ?? new InvalidOperationException("Unknown error occurred during profile deletion");
    }

    private static async Task<bool> DeleteItemsWithRetry(Func<Repository<Items>> itemsRepository, string accountId, string type, CancellationToken cancellationToken)
    {
        Exception lastException = null;

        for (int attempt = 1; attempt <= MaxRetryAttempts; attempt++)
        {
            try
            {
                cancellationToken.ThrowIfCancellationRequested();

                try
                {
                    var entitiesToDelete = await itemsRepository().FindAllByColumnsAsync(new Dictionary<string, object>
                    {
                        { "accountid", accountId },
                        { "profileid", type }
                    });
                    await itemsRepository().BulkDeleteAsync(entitiesToDelete);
                    return true;
                }
                catch (NotImplementedException)
                {
                    var items = await itemsRepository().FindAllAsync(new Items
                    {
                        AccountId = accountId,
                        ProfileId = type
                    });

                    if (items == null || !items.Any())
                    {
                        return true;
                    }

                    var successCount = 0;
                    foreach (var item in items)
                    {
                        try
                        {
                            cancellationToken.ThrowIfCancellationRequested();
                            await itemsRepository().DeleteAsync(item);
                            successCount++;
                        }
                        catch (Exception itemEx)
                        {
                            Logger.Warn($"Failed to delete individual item: {itemEx.Message}");
                        }
                    }

                    return successCount == items.Count();
                }
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                lastException = ex;
                Logger.Warn($"Items deletion failed (attempt {attempt}/{MaxRetryAttempts}): {ex.Message}");

                if (attempt < MaxRetryAttempts)
                {
                    var delay = TimeSpan.FromMilliseconds(BaseRetryDelay.TotalMilliseconds * Math.Pow(2, attempt - 1));
                    await Task.Delay(delay, cancellationToken);
                }
            }
        }

        Logger.Error($"All retry attempts failed for DeleteItems: {lastException?.Message}");
        throw lastException ?? new InvalidOperationException("Unknown error occurred during items deletion");
    }
}