using Helios.Classes.AthenaSeason;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Microsoft.AspNetCore.Mvc;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Helios.Managers.Helpers;

public static class BattlepassHelper
{
    private static readonly Repository<User> UserRepo = Constants.repositoryPool.For<User>();

    public static IActionResult? ValidateUserLockerState(User user, HttpContext context)
    {
        if (user.AllItemsGranted)
            return MCPErrors.UserLockerAlreadyGranted.Apply(context);

        return null;
    }

    public static async Task<(Items bookPurchased, Items bookLevel, Items level)> GetUserProgress(Repository<Items> repository, string accountId)
    {
        var bookPurchased = await repository.FindByColumnsAsync(new Dictionary<string, object>
        {
            { "profileid", "athena" },
            { "templateid", "book_purchased" },
            { "accountid", accountId }
        });
        var bookLevel = await repository.FindByColumnsAsync(new Dictionary<string, object>
        {
            { "profileid", "athena" },
            { "templateid", "book_level" },
            { "accountid", accountId }
        });
        var level = await repository.FindByColumnsAsync(new Dictionary<string, object>
        {
            { "profileid", "athena" },
            { "templateid", "level" },
            { "accountid", accountId }
        });

        return (bookPurchased, bookLevel, level);
    }



    public static IActionResult? ValidateUserBalance(Items currency, int finalPrice, HttpContext context)
    {
        if (currency.Quantity <= finalPrice)
            return StorefrontErrors.CurrencyInsufficient.Apply(context);

        return null;
    }

    public static async Task RemoveCurrency(Repository<Items> repository, Items currency, int amount, List<object> profileChanges)
    {
        currency.Quantity -= amount;
        await repository.UpdateAsync(currency);

        profileChanges.Add(new
        {
            changeType = "itemQuantityChanged",
            itemId = currency.TemplateId,
            quantity = currency.Quantity,
        });
    }

    //public static (bool IsBattlePass, bool IsSingleTier) GetSeasonDevNames(int currentVersion, Entry catalogEntry)
    //{
    //    return (
    //        IsBattlePass: catalogEntry.DevName == $"BR.Season{currentVersion}.BattlePass.01",
    //        IsSingleTier: catalogEntry.DevName == $"BR.Season{currentVersion}.SingleTier.01"
    //    );
    //}

    public static IActionResult? ValidateBattlePassPurchase((bool IsBattlePass, bool IsSingleTier) seasonDevNames, bool bookPurchasedValue, HttpContext context)
    {
        if (!bookPurchasedValue && seasonDevNames.IsSingleTier)
            return StorefrontErrors.InvalidItem("").Apply(context);

        return null;
    }

    public static async Task<IActionResult?> HandleRewardAsync(
        RewardItem reward,
        HttpContext context,
        RewardHelper rewardHelper,
        Items currency,
        List<object> profileChanges,
        string accountId)
    {
        var user = await UserRepo.FindByColumnAsync("accountid", accountId);
        if (user is null) return null;

        var repository = Constants.repositoryPool.For<Items>();

        switch (reward.TemplateId)
        {
            case string templateId when templateId.StartsWith("Athena"):
                await rewardHelper.SaveAthenaItemAsync(templateId, accountId, reward.Quantity);
                break;

            case string _ when reward.TemplateId.StartsWith("Token:"):
                if (reward.TemplateId.Contains("athenaseasonxpboost", StringComparison.OrdinalIgnoreCase))
                    await rewardHelper.UpdateSeasonBoostAsync("season_match_boost", accountId, reward.Quantity);
                else if (reward.TemplateId.Contains("athenaseasonfriendxpboost", StringComparison.OrdinalIgnoreCase))
                    await rewardHelper.UpdateSeasonBoostAsync("season_friend_match_boost", accountId, reward.Quantity);
                break;

            case string _ when reward.TemplateId.StartsWith("Currency:"):
                currency.Quantity += reward.Quantity;
                await repository.UpdateAsync(currency);

                profileChanges.Add(new
                {
                    changeType = "itemQuantityChanged",
                    itemId = currency.TemplateId,
                    quantity = currency.Quantity,
                });
                break;

            default:
                Logger.Warn($"Missing item: {reward.TemplateId}");
                break;
        }

        return null;
    }
}
