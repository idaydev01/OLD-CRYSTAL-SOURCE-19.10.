using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Profiles;
using Helios.Utilities;
using Newtonsoft.Json;
using Helios.Classes.MCP;

namespace Helios.Managers.Helpers;

public class RewardHelper
{
    private readonly Repository<Items> _itemsRepository;
    private readonly List<object> _multiUpdates;
    private readonly List<object> _notifications;

    public RewardHelper(List<object> multiUpdates, List<object> notifications)
    {
        _itemsRepository = Constants.repositoryPool.For<Items>(); 
        _multiUpdates = multiUpdates;
        _notifications = notifications;
    }

    public async Task SaveAthenaItemAsync(string templateId, string accountId, int quantity)
    {
        string cleanTemplateId = templateId.Contains(":") ? templateId[(templateId.IndexOf(':') + 1)..] : templateId;

        var existingItem = await _itemsRepository.FindByColumnsAsync(new Dictionary<string, object>
        {
            { "templateid", cleanTemplateId },
            { "accountid", accountId },
            { "profileid", "athena" }
        });
        if (existingItem != null)
            return;

        try
        {
            var variantTask = Constants.FileProvider.GetVariantsAsync(cleanTemplateId);

            var newItem = new Items
            {
                AccountId = accountId,
                IsAttribute = false,
                Quantity = quantity,
                ProfileId = "athena",
                TemplateId = templateId,
                Value = JsonConvert.SerializeObject(new
                {
                    favorite = false,
                    item_seen = false,
                    level = 0,
                    max_level_bonus = 0,
                    rnd_sel_cnt = 0,
                    variants = await variantTask
                })
            };

            await _itemsRepository.SaveAsync(newItem);

            _notifications.Add(new
            {
                itemType = templateId,
                itemGuid = templateId,
                quantity = newItem.Quantity
            });

            _multiUpdates.Add(new
            {
                changeType = "itemAdded",
                itemId = templateId,
                item = new
                {
                    templateId = templateId,
                    attributes = JsonConvert.DeserializeObject<ItemValue>(newItem.Value),
                    quantity = newItem.Quantity,
                },
            });
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to save Athena item {cleanTemplateId} for account {accountId}: {ex.Message}");
        }
    }

    public async Task UpdateSeasonBoostAsync(string boostType, string accountId, int quantity)
    {
        try
        {
            var boostItem = await _itemsRepository.FindByColumnsAsync(new Dictionary<string, object> { { "templateid", boostType }, { "accountid", accountId }, { "profileid", "athena" } });
            int newBoostValue = quantity;

            if (boostItem != null)
            {
                if (int.TryParse(boostItem.Value, out int currentBoostValue))
                {
                    newBoostValue += currentBoostValue;
                }

                boostItem.Value = JsonConvert.SerializeObject(newBoostValue);
                await _itemsRepository.UpdateAsync(boostItem);
            }


            _notifications.Add(new
            {
                itemType = boostType,
                itemGuid = boostType,
                quantity = quantity
            });

            _multiUpdates.Add(new
            {
                changeType = "statModified",
                itemId = boostType,
                item = quantity
            });
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to update season boost {boostType} for account {accountId}: {ex.Message}");
        }
    }
}