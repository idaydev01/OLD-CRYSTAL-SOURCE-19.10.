﻿using Helios.Classes.Tournaments.DBInterfaces;

namespace Helios.Classes.Tournaments;

public class TemplateMapping
{
    public string eventTemplateId { get; set; }
    public string persistentScoreId { get; set; }
    public string playlistId { get; set; }
    public DB_TiebreakerFormula tiebreakerFormula { get; set; }
    public int matchCap { get; set; }
    public string gameId { get; set; }
    public List<DB_ScoringRules> scoringRules { get; set; }
    public object payoutTable { get; set; }
    public object liveSessionAttributes { get; set; }
    public bool clampsToZero { get; set; }
    public int onlyScoreTopN { get; set; }
    public object metadata { get; set; }
}