using Helios.Classes.Tournaments.DBInterfaces;
using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace Helios.Classes.Tournaments.Requests;

public class CreateTournamentRequestBody
{
    [JsonPropertyName("backendID")]
    public string backendID { get; set; }
    [JsonPropertyName("season")]
    public int SEASON { get; set; }
    [JsonPropertyName("id")]
    public string name { get; set; }
    [JsonPropertyName("name")]
    public string description { get; set; }
    [JsonPropertyName("image")]
    public string? image { get; set; } = null;
    [JsonPropertyName("startDate")]
    public string StartDate { get; set; }
    [JsonPropertyName("endDate")]
    public string EndDate { get; set; }
    [JsonPropertyName("status")]
    public string Status { get; set; }
    [JsonPropertyName("format")]
    public string Format { get; set; }
    [JsonPropertyName("regions")]
    public List<string> Regions { get; set; }
    [JsonPropertyName("prizes")]
    public List<string> Prizes { get; set; }
    [JsonPropertyName("rules")]
    public List<string> Rules { get; set; }
    [JsonPropertyName("Sessions")]
    public List<TournamentSessions> sessions { get; set; }

    [JsonProperty("displayInfo")]
    public TournamentDisplayInfo DisplayInfo { get; set; }
    [JsonProperty("templateInfo")]
    public TournamentTemplateInfo TemplateInfo { get; set; }
    [JsonProperty("eventInfo")]
    public TournamentEventInfo EventInfo { get; set; }
}

public class TournamentSessions
{
    [JsonPropertyName("date")]
    public string Date { get; set; }
    [JsonPropertyName("startTime")]
    public string StartTime { get; set; }
    [JsonPropertyName("endTime")]
    public string EndTime { get; set; }
}

public class TournamentSocring
{
    [JsonPropertyName("type")]
    public string Type { get; set; }
    [JsonPropertyName("value")]
    public int Value { get; set; }
    [JsonPropertyName("description")]
    public string Description { get; set; }
}

public class TournamentDisplayInfo
{
    [JsonProperty("title_line_1")]
    public string TitleLine1 { get; set; }

    [JsonProperty("title_line_2")]
    public string TitleLine2 { get; set; }
    [JsonProperty("flavor_description")]
    public string FlavorDescription { get; set; }

    [JsonProperty("details_description")]
    public string DetailsDescription { get; set; }

    [JsonProperty("poster_front_image")]
    public string PosterFrontImage { get; set; }

    [JsonProperty("poster_back_image")]
    public string PosterBackImage { get; set; }

    [JsonProperty("loading_screen_image")]
    public string LoadingScreenImage { get; set; }

    [JsonProperty("playlist_tile_image")]
    public string PlaylistTileImage { get; set; }

    [JsonProperty("title_color")]
    public string TitleColor { get; set; }

    [JsonProperty("background_text_color")]
    public string BackgroundTextColor { get; set; }

    [JsonProperty("background_left_color")]
    public string BackgroundLeftColor { get; set; }

    [JsonProperty("background_right_color")]
    public string BackgroundRightColor { get; set; }

    [JsonProperty("highlight_color")]
    public string HighlightColor { get; set; }

    [JsonProperty("primary_color")]
    public string PrimaryColor { get; set; }

    [JsonProperty("secondary_color")]
    public string SecondaryColor { get; set; }

    [JsonProperty("shadow_color")]
    public string ShadowColor { get; set; }

    [JsonProperty("base_color")]
    public string BaseColor { get; set; }

    [JsonProperty("poster_fade_color")]
    public string PosterFadeColor { get; set; }

    [JsonProperty("tournament_display_id")]
    public string TournamentDisplayId { get; set; }
    [JsonProperty("pin_score_requirement")]
    public int PinScoreRequirement { get; set; }
    [JsonProperty("pin_earned_text")]
    public string PinEarnedText { get; set; }
    [JsonProperty("type")]
    public string Type { get; set; }
    [JsonProperty("schedule_info")]
    public string ScheduleInfo { get; set; }
}


public class TournamentTemplateInfo
{
    [JsonProperty("event_id")]
    public string EventId { get; set; }
    [JsonProperty("tournament_id")]
    public string TournamentId { get; set; }

    [JsonProperty("playlist_id")]
    public string PlaylistId { get; set; }

    [JsonProperty("match_cap")]
    public int MatchCap { get; set; }

    [JsonProperty("event_template_id")]
    public string EventTemplateId { get; set; }

    [JsonProperty("scoring_rules")]
    public List<DB_ScoringRules> ScoringRules { get; set; }
    [JsonProperty("clamps_to_zero")]
    public bool ClampsToZero { get; set; }

    [JsonProperty("only_score_top_n")]
    public int OnlyScoreTopN { get; set; }
}

public class TournamentEventInfo
{
    [JsonProperty("tournament_id")]
    public string TournamentId { get; set; }

    //[JsonProperty("game_id")]
    //public string GameId { get; set; }

    [JsonProperty("event_id")]
    public string EventId { get; set; }

    [JsonProperty("begin_time")]
    public string BeginTime { get; set; }

    [JsonProperty("end_time")]
    public string EndTime { get; set; }

    [JsonProperty("display_data_id")]
    public string DisplayDataId { get; set; } //

    [JsonProperty("event_group")]
    public string EventGroup { get; set; }

    [JsonProperty("announcement_time")]
    public string AnnouncementTime { get; set; }

    [JsonProperty("regions")]
    public List<string> Regions { get; set; }

    [JsonProperty("region_mappings")]
    public string RegionMappings { get; set; }

    [JsonProperty("platforms")]
    public List<string> Platforms { get; set; }

    [JsonProperty("platform_mappings")]
    public string PlatformMappings { get; set; }

    //[JsonProperty("app_id")]
    //public string AppId { get; set; }

    [JsonProperty("environment")]
    public string Environment { get; set; }

    [JsonProperty("event_windows")]
    public List<DB_EventWindow> EventWindows { get; set; }

    [JsonProperty("format")]
    public string Format { get; set; }

    [JsonProperty("metadata")]
    public string Metadata { get; set; }
}
