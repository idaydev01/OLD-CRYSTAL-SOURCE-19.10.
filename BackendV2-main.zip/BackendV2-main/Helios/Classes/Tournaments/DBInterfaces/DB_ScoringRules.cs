﻿using Newtonsoft.Json;

namespace Helios.Classes.Tournaments.DBInterfaces;

public class DB_ScoringRules
{
    [JsonProperty("matchRule")]
    public string MatchRule { get; set; }
    [JsonProperty("rewardTiers")]
    public List<DB_RewardTiers> RewardTiers { get; set; }
    [JsonProperty("trackedStat")]
    public string TrackedStat { get; set; }
}