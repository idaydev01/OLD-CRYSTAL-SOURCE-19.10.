﻿using System.Text.Json.Serialization;

namespace Helios.Classes.Tournaments.DBInterfaces;

public class DB_TiebreakerFormula
{
    [JsonPropertyName("basePointsBits")]
    public int BasePointsBits { get; set; }
    [JsonPropertyName("bits")]
    public int Bits { get; set; }
    [JsonPropertyName("multiplier")]
    public double Multiplier { get; set; }
    [JsonPropertyName("aggregation")]
    public string Aggregation { get; set; }
}