﻿using System.Text.Json.Serialization;

namespace Helios.Classes.Tournaments.DBInterfaces;

public class DB_EventMetadata
{
    [JsonPropertyName("RoundType")]
    public string RoundType { get; set; } = string.Empty;

    [JsonPropertyName("ThresholdToAdvanceDivision")]
    public long ThresholdToAdvanceDivision { get; set; }

    [JsonPropertyName("divisionRank")]
    public int DivisionRank { get; set; }

    [JsonPropertyName("ServerReplays")]
    public bool ServerReplays { get; set; }

    [JsonPropertyName("liveSpectateAccessToken")]
    public string LiveSpectateAccessToken { get; set; } = string.Empty;
}
