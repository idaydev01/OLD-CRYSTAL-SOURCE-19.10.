﻿namespace Helios.Classes.CloudStorage;

public class CloudStorage
{
    public List<CloudStorageFile> Files { get; set; } = new List<CloudStorageFile>();
}