﻿namespace Helios.Classes.CloudStorage.Files;

public class Engine
{
    public static string GetDefaultEngine()
    {
        return @"
[OnlineSubsystemMcp.Xmpp]
bUseSSL=false
ServerAddr=""ws://127.0.0.1:443""
ServerPort=443

[OnlineSubsystemMcp.Xmpp Prod]
bUseSSL=false
ServerAddr=""ws://127.0.0.1:443""
ServerPort=443

[OnlineSubsystemMcp.OnlineWaitingRoomMcp]
bEnabled=false
ServiceName=""waitingroom""
GracePeriod=300
RetryConfigUrl=""https://s3-us-west-1.amazonaws.com/launcher-resources/waitingroom""

[OnlineSubsystemMcp]
bUsePartySystemV2=true

[OnlineSubsystemMcp.OnlinePartySystemMcpAdapter]
bUsePartySystemV2=true

[OnlineSubsystemMcp.OnlineIdentityMcp]
bAutoLoginToXmpp=true
bShouldReconnectXmpp=true
bOfflineAccountToken=true
bOfflineClientToken=true
bVerifyAuthIncludesPermissions=true

[ConsoleVariables]
n.VerifyPeer=0
SupervisedSettings.UseEOSIntegration=false
FortMatchmakingV2.ContentBeaconFailureCancelsMatchmaking=0
Fort.ShutdownWhenContentBeaconFails=0
FortMatchmakingV2.EnableContentBeacon=0
net.AllowAsyncLoading=0

[Core.Log]
LogEngine=Verbose
LogStreaming=Verbose
LogNetDormancy=Verbose
LogNetPartialBunch=Verbose
OodleHandlerComponentLog=Verbose
LogSpectatorBeacon=Verbose
PacketHandlerLog=Verbose
LogPartyBeacon=Verbose
LogNet=Verbose
LogBeacon=Verbose
LogNetTraffic=Verbose
LogDiscordRPC=Verbose
LogEOSSDK=Verbose
LogXmpp=Verbose
LogParty=Verbose
LogMatchmakingServiceClient=Verbose
LogScriptCore=Verbose
LogSkinnedMeshComp=Verbose
LogFortAbility=Verbose
LogContentBeacon=Verbose
LogPhysics=Verbose
LogStreaming=Error

[/Script/Qos.QosRegionManager]
NumTestsPerRegion=5
PingTimeout=3.0
!RegionDefinitions=ClearArray
+RegionDefinitions=(DisplayName=NSLOCTEXT(""MMRegion"", ""NA"", ""NA""), RegionId=""NAE"", bEnabled=true, bVisible=true, bAutoAssignable=true)
+RegionDefinitions=(DisplayName=NSLOCTEXT(""MMRegion"", ""EU"", ""EU""), RegionId=""EU"", bEnabled=true, bVisible=true, bAutoAssignable=true)
!DatacenterDefinitions=ClearArray
+DatacenterDefinitions=(Id=""NAE"", RegionId=""NAE"", bEnabled=true, Servers[0]=(Address=""ping-nae.ds.on.epicgames.com"", Port=22222))
+DatacenterDefinitions=(Id=""EU"", RegionId=""EU"", bEnabled=true, Servers[0]=(Address=""ping-eu.ds.on.epicgames.com"", Port=22222))
";
    }
}
