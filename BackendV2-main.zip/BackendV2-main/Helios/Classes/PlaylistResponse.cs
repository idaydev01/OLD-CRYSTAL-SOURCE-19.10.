using Helios.Utilities.Extensions;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Helios.Classes;

public class PlaylistResponse
{
    [JsonPropertyName("meta")]
    public MetaData Meta { get; set; } = new();

    [JsonPropertyName("assetData")]
    public AssetData PlaylistAssetData { get; set; } = new();

    public class MetaData
    {
        [JsonPropertyName("revision")] public int Revision { get; set; } = 1;
        [JsonPropertyName("headRevision")] public int HeadRevision { get; set; } = 1;
        [JsonPropertyName("revisedAt")] public string RevisedAt { get; set; } = DateTime.UtcNow.ToIsoUtcString();
        [JsonPropertyName("promotion")] public int Promotion { get; set; } = 0;
        [JsonPropertyName("promotedAt")] public string PromotedAt { get; set; } = DateTime.UtcNow.ToIsoUtcString();
    }

    public class AssetData
    {
        // Boolean Properties (b-prefix)
        [JsonPropertyName("bOwnerFilterDestructedBuildingsInGrid")] public bool BOwnerFilterDestructedBuildingsInGrid { get; set; } = false;
        [JsonPropertyName("bDisplayRespawnWidget")] public bool BDisplayRespawnWidget { get; set; } = false;
        [JsonPropertyName("bRequireCrossplayEnabled")] public bool BRequireCrossplayEnabled { get; set; } = true;
        [JsonPropertyName("bRequirePickaxeInStartingInventory")] public bool BRequirePickaxeInStartingInventory { get; set; } = true;
        [JsonPropertyName("bRewardsAllowXPProgression")] public bool BRewardsAllowXPProgression { get; set; } = true;
        [JsonPropertyName("bVehiclesDestroyAllBuildingSMActorsOnContact")] public bool BVehiclesDestroyAllBuildingSMActorsOnContact { get; set; } = false;
        [JsonPropertyName("bEnableSpawningStartup")] public bool BEnableSpawningStartup { get; set; } = true;
        [JsonPropertyName("bAllowReturnToMatchmakingOriginOnMatchEnd")] public bool BAllowReturnToMatchmakingOriginOnMatchEnd { get; set; } = false;
        [JsonPropertyName("bShouldSpreadTeams")] public bool BShouldSpreadTeams { get; set; } = true;
        [JsonPropertyName("bLimitedTimeMode")] public bool BLimitedTimeMode { get; set; } = false;
        [JsonPropertyName("bIgnoreWeatherEvents")] public bool BIgnoreWeatherEvents { get; set; } = false;
        [JsonPropertyName("bUsesAnimationSharing")] public bool BUsesAnimationSharing { get; set; } = false;
        [JsonPropertyName("bForceCameraFadeOnRespawn")] public bool BForceCameraFadeOnRespawn { get; set; } = true;
        [JsonPropertyName("bAllowBotsInHumanTeams")] public bool BAllowBotsInHumanTeams { get; set; } = false;
        [JsonPropertyName("bDisallowMultipleWeaponsOfType")] public bool BDisallowMultipleWeaponsOfType { get; set; } = false;
        [JsonPropertyName("bLeaderboardDisplaysIndividuals")] public bool BLeaderboardDisplaysIndividuals { get; set; } = true;
        [JsonPropertyName("bSkipAircraft")] public bool BSkipAircraft { get; set; } = false;
        [JsonPropertyName("bAircraftDropOnlyWithinSafeZone")] public bool BAircraftDropOnlyWithinSafeZone { get; set; } = false;
        [JsonPropertyName("bDisableMatchStatsDisplay")] public bool BDisableMatchStatsDisplay { get; set; } = false;
        [JsonPropertyName("bPlaylistUsesCustomCharacterParts")] public bool BPlaylistUsesCustomCharacterParts { get; set; } = false;
        [JsonPropertyName("bOverrideServerPerClientMaxAI")] public bool BOverrideServerPerClientMaxAI { get; set; } = false;
        [JsonPropertyName("bShowEliminationIndicatorForTeammates")] public bool BShowEliminationIndicatorForTeammates { get; set; } = true;
        [JsonPropertyName("bAllowSpectateAPartyMember")] public bool BAllowSpectateAPartyMember { get; set; } = true;
        [JsonPropertyName("bIgnoreGameModeStartingInventory")] public bool BIgnoreGameModeStartingInventory { get; set; } = false;
        [JsonPropertyName("bShowEliminationIndicatorForSelf")] public bool BShowEliminationIndicatorForSelf { get; set; } = false;
        [JsonPropertyName("bTeamFilterDestructedBuildingsInGrid")] public bool BTeamFilterDestructedBuildingsInGrid { get; set; } = true;
        [JsonPropertyName("bAllowBackfill")] public bool BAllowBackfill { get; set; } = false;
        [JsonPropertyName("bUseReloadRankedFormula")] public bool BUseReloadRankedFormula { get; set; } = false;
        [JsonPropertyName("bShouldFillWhenNoSquadFillOption")] public bool BShouldFillWhenNoSquadFillOption { get; set; } = false;
        [JsonPropertyName("bEnableStatsV2Stats")] public bool BEnableStatsV2Stats { get; set; } = true;
        [JsonPropertyName("bUseAsyncPhysics")] public bool BUseAsyncPhysics { get; set; } = true;
        [JsonPropertyName("bShowEliminationIndicatorForSquadmates")] public bool BShowEliminationIndicatorForSquadmates { get; set; } = true;
        [JsonPropertyName("bWarmUpInStorm")] public bool BWarmUpInStorm { get; set; } = false;
        [JsonPropertyName("bForceCustomMinigame")] public bool BForceCustomMinigame { get; set; } = false;
        [JsonPropertyName("bUseFriendlyFireAimAssist")] public bool BUseFriendlyFireAimAssist { get; set; } = false;
        [JsonPropertyName("bForceEnableProximityVoiceChat")] public bool BForceEnableProximityVoiceChat { get; set; } = false;
        [JsonPropertyName("bDisplayFinalStormPosition")] public bool BDisplayFinalStormPosition { get; set; } = false;
        [JsonPropertyName("bSkipWarmup")] public bool BSkipWarmup { get; set; } = false;
        [JsonPropertyName("bUseCustomAircraftPathSelection")] public bool BUseCustomAircraftPathSelection { get; set; } = false;
        [JsonPropertyName("bDrawCreativeDynamicIslands")] public bool BDrawCreativeDynamicIslands { get; set; } = false;
        [JsonPropertyName("bShowTeamSelectButton")] public bool BShowTeamSelectButton { get; set; } = false;
        [JsonPropertyName("bCheckSquadFillMapForAvailableSlotsInBackfill")] public bool BCheckSquadFillMapForAvailableSlotsInBackfill { get; set; } = true;
        [JsonPropertyName("bRewardsTrackPlacement")] public bool BRewardsTrackPlacement { get; set; } = true;
        [JsonPropertyName("bUseRankScaling")] public bool BUseRankScaling { get; set; } = false;
        [JsonPropertyName("bAllowJoinInProgress")] public bool BAllowJoinInProgress { get; set; } = false;
        [JsonPropertyName("bEnableRatingUpdate")] public bool BEnableRatingUpdate { get; set; } = true;
        [JsonPropertyName("bAllowHardcoreModifiers")] public bool BAllowHardcoreModifiers { get; set; } = true;
        [JsonPropertyName("bAllowPartyRift")] public bool BAllowPartyRift { get; set; } = false;
        [JsonPropertyName("bIsRankedMode")] public bool BIsRankedMode { get; set; } = false;
        [JsonPropertyName("bRespawnInAir")] public bool BRespawnInAir { get; set; } = true;
        [JsonPropertyName("bUsePlayerRating")] public bool BUsePlayerRating { get; set; } = true;
        [JsonPropertyName("bUseLocalizationService")] public bool BUseLocalizationService { get; set; } = false;
        [JsonPropertyName("bAllowedInLeto")] public bool BAllowedInLeto { get; set; } = false;
        [JsonPropertyName("bDisable_ReportAPlayerReason_TeamingUpWithEnemies_WhileInGame")] public bool BDisableReportAPlayerReasonTeamingUpWithEnemiesWhileInGame { get; set; } = false;
        [JsonPropertyName("bUseMultidivisionQueues")] public bool BUseMultidivisionQueues { get; set; } = false;
        [JsonPropertyName("bIsTournament")] public bool BIsTournament { get; set; } = false;
        [JsonPropertyName("bForceLTMLoadingScreenBackground")] public bool BForceLTMLoadingScreenBackground { get; set; } = false;
        [JsonPropertyName("bUseSameDirectionForOpposingAircraft")] public bool BUseSameDirectionForOpposingAircraft { get; set; } = false;
        [JsonPropertyName("bEnableDynamicBotBackfill")] public bool BEnableDynamicBotBackfill { get; set; } = true;
        [JsonPropertyName("bRequeueAfterFailedSessionAssignment")] public bool BRequeueAfterFailedSessionAssignment { get; set; } = true;
        [JsonPropertyName("bAllowWarmupPlayerStartInSetupPhase")] public bool BAllowWarmupPlayerStartInSetupPhase { get; set; } = true;
        [JsonPropertyName("bShouldErrorOnAdditionalContentFailure")] public bool BShouldErrorOnAdditionalContentFailure { get; set; } = false;
        [JsonPropertyName("bAllowEditingEnemyWalls")] public bool BAllowEditingEnemyWalls { get; set; } = false;
        [JsonPropertyName("bUsePointLeaderAsTeamLeaderInLeaderboard")] public bool BUsePointLeaderAsTeamLeaderInLeaderboard { get; set; } = true;
        [JsonPropertyName("bRewardForRevivingTeammates")] public bool BRewardForRevivingTeammates { get; set; } = false;
        [JsonPropertyName("bIsDefaultPlaylist")] public bool BIsDefaultPlaylist { get; set; } = true;
        [JsonPropertyName("bOverrideMaxPlayers")] public bool BOverrideMaxPlayers { get; set; } = true;
        [JsonPropertyName("bEnableBackfillDuringWarmupPhase")] public bool BEnableBackfillDuringWarmupPhase { get; set; } = false;
        [JsonPropertyName("bEnablePlaylistXPLogging")] public bool BEnablePlaylistXPLogging { get; set; } = false;
        [JsonPropertyName("bAllowBroadcasting")] public bool BAllowBroadcasting { get; set; } = false;
        [JsonPropertyName("bRemoveFromSquadOnLogout")] public bool BRemoveFromSquadOnLogout { get; set; } = false;
        [JsonPropertyName("bAllowTeamSwitching")] public bool BAllowTeamSwitching { get; set; } = false;
        [JsonPropertyName("bForceEncryptionKeychainRefresh")] public bool BForceEncryptionKeychainRefresh { get; set; } = false;
        [JsonPropertyName("bAllowSinglePartyMatches")] public bool BAllowSinglePartyMatches { get; set; } = false;
        [JsonPropertyName("bAllowSquadSizeTracking")] public bool BAllowSquadSizeTracking { get; set; } = true;
        [JsonPropertyName("bIsLargeTeamGame")] public bool BIsLargeTeamGame { get; set; } = false;
        [JsonPropertyName("bDrawLineToStormCircleIfOutside")] public bool BDrawLineToStormCircleIfOutside { get; set; } = true;
        [JsonPropertyName("bDisplayScoreInHUD")] public bool BDisplayScoreInHUD { get; set; } = false;
        [JsonPropertyName("bActivateCurie")] public bool BActivateCurie { get; set; } = true;
        [JsonPropertyName("bUseDefaultSupplyDrops")] public bool BUseDefaultSupplyDrops { get; set; } = true;
        [JsonPropertyName("bIgnoreDefaultQuests")] public bool BIgnoreDefaultQuests { get; set; } = false;
        [JsonPropertyName("bEnableBuildingCreatedEvent")] public bool BEnableBuildingCreatedEvent { get; set; } = false;
        [JsonPropertyName("bLimitedPoolMatchmakingEnabled")] public bool BLimitedPoolMatchmakingEnabled { get; set; } = true;
        [JsonPropertyName("bUseCreativeStarterIsland")] public bool BUseCreativeStarterIsland { get; set; } = false;
        [JsonPropertyName("bUnderfillMatchmaking")] public bool BUnderfillMatchmaking { get; set; } = false;
        [JsonPropertyName("bRestrictSquadFillToSoloPlayers")] public bool BRestrictSquadFillToSoloPlayers { get; set; } = false;
        [JsonPropertyName("bEnforceFullSquadInUI")] public bool BEnforceFullSquadInUI { get; set; } = false;
        [JsonPropertyName("bPreloadAthenaMapsForMatchmaking")] public bool BPreloadAthenaMapsForMatchmaking { get; set; } = true;
        [JsonPropertyName("bAllowSquadFillOption")] public bool BAllowSquadFillOption { get; set; } = true;
        [JsonPropertyName("bForceNewPlayerStateOnReconnect")] public bool BForceNewPlayerStateOnReconnect { get; set; } = false;
        [JsonPropertyName("bDisableAudioShapes")] public bool BDisableAudioShapes { get; set; } = false;
        [JsonPropertyName("bAllowInGameMatchMaking")] public bool BAllowInGameMatchMaking { get; set; } = true;
        [JsonPropertyName("bUseKeepTogetherId")] public bool BUseKeepTogetherId { get; set; } = false;
        [JsonPropertyName("bShowEliminationIndicatorForEnemies")] public bool BShowEliminationIndicatorForEnemies { get; set; } = false;
        [JsonPropertyName("bAllowLayoutRequirementsFeature")] public bool BAllowLayoutRequirementsFeature { get; set; } = false;
        [JsonPropertyName("bAutoAcquireSpawnChip")] public bool BAutoAcquireSpawnChip { get; set; } = false;
        [JsonPropertyName("bAllowKeepPlayingTogether")] public bool BAllowKeepPlayingTogether { get; set; } = false;

        // String Properties
        [JsonPropertyName("LootLevel")] public string LootLevel { get; set; } = "1";
        [JsonPropertyName("ForceKickAfterDeathMode")] public string ForceKickAfterDeathMode { get; set; } = "Disabled";
        [JsonPropertyName("EndOfMatchXpFirstElim")] public string EndOfMatchXpFirstElim { get; set; } = "50";
        [JsonPropertyName("RankScalingMaxDelta")] public string RankScalingMaxDelta { get; set; } = "500.000000";
        [JsonPropertyName("PlacementGainMin")] public string PlacementGainMin { get; set; } = "0.000000";
        [JsonPropertyName("ServerPerClientMaxAI")] public string ServerPerClientMaxAI { get; set; } = "-1";
        [JsonPropertyName("LootDropRounds")] public string LootDropRounds { get; set; } = "1";
        [JsonPropertyName("PlaylistName")] public string PlaylistName { get; set; } = "Playlist_DefaultSolo";
        [JsonPropertyName("SafeZoneStartUp")] public string SafeZoneStartUp { get; set; } = "UseDefaultGameBehavior";
        [JsonPropertyName("AircraftPathOffsetFromMapCenterMax")] public string AircraftPathOffsetFromMapCenterMax { get; set; } = "0.000000";
        [JsonPropertyName("ServerPerformanceEventFrequency")] public string ServerPerformanceEventFrequency { get; set; } = "0.000000";
        [JsonPropertyName("MaxBucketCapacity")] public string MaxBucketCapacity { get; set; } = "-1";
        [JsonPropertyName("MinTimeBeforeRespawnCameraFade")] public string MinTimeBeforeRespawnCameraFade { get; set; } = "3.000000";
        [JsonPropertyName("BuildingLevelOverride")] public string BuildingLevelOverride { get; set; } = "0";
        [JsonPropertyName("OutlierBracketBalanceMergeInterval")] public string OutlierBracketBalanceMergeInterval { get; set; } = "";
        [JsonPropertyName("DADTestValue")] public string DADTestValue { get; set; } = "0";
        [JsonPropertyName("SeasonNumber")] public string SeasonNumber { get; set; } = "-1";
        [JsonPropertyName("RewardTimePlayedType")] public string RewardTimePlayedType { get; set; } = "Default";
        [JsonPropertyName("MinPlayers")] public string MinPlayers { get; set; } = "20";
        [JsonPropertyName("GameData")] public string GameData { get; set; } = "/Game/Athena/Playlists/AthenaCompositeGameData.AthenaCompositeGameData";
        [JsonPropertyName("UnderfilledMaxPlayers")] public string UnderfilledMaxPlayers { get; set; } = "0";
        [JsonPropertyName("MinBackfillMatchPlayers")] public string MinBackfillMatchPlayers { get; set; } = "0";
        [JsonPropertyName("DelayForPreServerTransitionAnimation")] public string DelayForPreServerTransitionAnimation { get; set; } = "0.000000";
        [JsonPropertyName("LastStepPushAircraftCenterLine_Magnitude")] public string LastStepPushAircraftCenterLineMagnitude { get; set; } = "0.000000";
        [JsonPropertyName("RequiredEntitlementToken")] public string RequiredEntitlementToken { get; set; } = "";
        [JsonPropertyName("RewardTimePlayedXPPerMinute")] public string RewardTimePlayedXPPerMinute { get; set; } = "-1";
        [JsonPropertyName("MinPlayersForPrivateServer")] public string MinPlayersForPrivateServer { get; set; } = "0";
        [JsonPropertyName("DamageTakenMax")] public string DamageTakenMax { get; set; } = "0.000000";
        [JsonPropertyName("ForceOnlyBotsThreshold")] public string ForceOnlyBotsThreshold { get; set; } = "-1";
        [JsonPropertyName("BracketBalanceMergeInterval")] public string BracketBalanceMergeInterval { get; set; } = "";
        [JsonPropertyName("ServerMetricsEventFrequency")] public string ServerMetricsEventFrequency { get; set; } = "60.000000";
        [JsonPropertyName("LastStepPushAircraftCenterLine_Direction")] public string LastStepPushAircraftCenterLineDirection { get; set; } = "0.000000";
        [JsonPropertyName("QuickbarSelectionPreservationMode")] public string QuickbarSelectionPreservationMode { get; set; } = "KeepSelectionWhenRespawning";
        [JsonPropertyName("RankLossMax")] public string RankLossMax { get; set; } = "0.000000";
        [JsonPropertyName("RatingType")] public string RatingType { get; set; } = "fun";
        [JsonPropertyName("CustomGameChannel")] public string CustomGameChannel { get; set; } = "Squad";
        [JsonPropertyName("BotVersionPlaylistName")] public string BotVersionPlaylistName { get; set; } = "Playlist_Bots_DefaultSolo";
        [JsonPropertyName("BracketBalanceSplitInterval")] public string BracketBalanceSplitInterval { get; set; } = "";
        [JsonPropertyName("LastQueuedPlaylistPriority")] public string LastQueuedPlaylistPriority { get; set; } = "-1";
        [JsonPropertyName("AirCraftBehavior")] public string AirCraftBehavior { get; set; } = "Default";
        [JsonPropertyName("MaximumAspectRatio")] public string MaximumAspectRatio { get; set; } = "0.000000";
        [JsonPropertyName("LastSafeZoneIndex")] public string LastSafeZoneIndex { get; set; } = "-1";
        [JsonPropertyName("WarmupEarlyRequiredPlayerPercent")] public string WarmupEarlyRequiredPlayerPercent { get; set; } = "0.000000";
        [JsonPropertyName("RichPresenceAssetName")] public string RichPresenceAssetName { get; set; } = "solos";
        [JsonPropertyName("CompetitivePointClamp")] public string CompetitivePointClamp { get; set; } = "100";
        [JsonPropertyName("GameType")] public string GameType { get; set; } = "BR";
        [JsonPropertyName("WinConditionPlayersRemaining")] public string WinConditionPlayersRemaining { get; set; } = "1";
        [JsonPropertyName("MaxPriority")] public string MaxPriority { get; set; } = "0.000000";
        [JsonPropertyName("TimeAfterWarmupToDisableBackfill")] public string TimeAfterWarmupToDisableBackfill { get; set; } = "5.000000";
        [JsonPropertyName("MaxSquads")] public string MaxSquads { get; set; } = "-1";
        [JsonPropertyName("RewardsPlacementThreshold")] public string RewardsPlacementThreshold { get; set; } = "3";
        [JsonPropertyName("MaxTeamSize")] public string MaxTeamSize { get; set; } = "1";
        [JsonPropertyName("Strategy")] public string Strategy { get; set; } = "";
        [JsonPropertyName("FriendlyFireType")] public string FriendlyFireType { get; set; } = "Off";
        [JsonPropertyName("MaxHumanAndBotParticipants")] public string MaxHumanAndBotParticipants { get; set; } = "100";
        [JsonPropertyName("LootTierData")] public string LootTierData { get; set; } = "/Game/Athena/Playlists/AthenaCompositeLTD.AthenaCompositeLTD";
        [JsonPropertyName("RankScalingMinDelta")] public string RankScalingMinDelta { get; set; } = "-500.000000";
        [JsonPropertyName("ReplayChunkTimeSeconds")] public string ReplayChunkTimeSeconds { get; set; } = "0.000000";
        [JsonPropertyName("ForceKickAfterDeathTime")] public string ForceKickAfterDeathTime { get; set; } = "0.000000";
        [JsonPropertyName("MaxBracketPriority")] public string MaxBracketPriority { get; set; } = "0.000000";
        [JsonPropertyName("LootPackages")] public string LootPackages { get; set; } = "/BRPlaylists/Athena/Playlists/AthenaCompositeLP.AthenaCompositeLP";
        [JsonPropertyName("AircraftPathMidpointSelectionRadiusMin")] public string AircraftPathMidpointSelectionRadiusMin { get; set; } = "20000.000000";
        [JsonPropertyName("MaxPlayers")] public string MaxPlayers { get; set; } = "100";
        [JsonPropertyName("BotFillMMRCutoff")] public string BotFillMMRCutoff { get; set; } = "-1";
        [JsonPropertyName("TypeOfLeaderboard")] public string TypeOfLeaderboard { get; set; } = "Score";
        [JsonPropertyName("WaitForServerInitializationTimeoutSecondsOverride")] public string WaitForServerInitializationTimeoutSecondsOverride { get; set; } = "-1.000000";
        [JsonPropertyName("MaxOutlierBracketMergeMmrGap")] public string MaxOutlierBracketMergeMmrGap { get; set; } = "0";
        [JsonPropertyName("KillerRankShare")] public string KillerRankShare { get; set; } = "0.000000";
        [JsonPropertyName("MaxSquadSize")] public string MaxSquadSize { get; set; } = "1";
        [JsonPropertyName("KeepTogetherIdExpirationInSeconds")] public string KeepTogetherIdExpirationInSeconds { get; set; } = "1200";
        [JsonPropertyName("EndOfMatchXpMultiplier")] public string EndOfMatchXpMultiplier { get; set; } = "20";
        [JsonPropertyName("MapScaleOverride")] public string MapScaleOverride { get; set; } = "0.000000";
        [JsonPropertyName("MaxTeamScoreAllowedForBackfill")] public string MaxTeamScoreAllowedForBackfill { get; set; } = "0";
        [JsonPropertyName("WinConditionType")] public string WinConditionType { get; set; } = "MutatorControlledChinaSupported";
        [JsonPropertyName("PlaylistMissionGen")] public string PlaylistMissionGen { get; set; } = "/Game/World/MissionGens/Athena/MissionGen_Athena.MissionGen_Athena_C";
        [JsonPropertyName("MaxOutlierBracketPriority")] public string MaxOutlierBracketPriority { get; set; } = "0.000000";
        [JsonPropertyName("RewardTimePlayedXPFlatValue")] public string RewardTimePlayedXPFlatValue { get; set; } = "-1";
        [JsonPropertyName("RespawnType")] public string RespawnType { get; set; } = "None";
        [JsonPropertyName("InventorySystemConfiguration")] public string InventorySystemConfiguration { get; set; } = "";
        [JsonPropertyName("RankKillFarmCutoff")] public string RankKillFarmCutoff { get; set; } = "0";
        [JsonPropertyName("RankKillFarmFloor")] public string RankKillFarmFloor { get; set; } = "0.000000";
        [JsonPropertyName("GarbageCollectionFrequency")] public string GarbageCollectionFrequency { get; set; } = "0.000000";
        [JsonPropertyName("MaxPendingMatches")] public string MaxPendingMatches { get; set; } = "-1";
        [JsonPropertyName("AircraftPathOffsetFromMapCenterMin")] public string AircraftPathOffsetFromMapCenterMin { get; set; } = "0.000000";
        [JsonPropertyName("PlaylistStatId")] public string PlaylistStatId { get; set; } = "-1";
        [JsonPropertyName("NetActorDiscoveryBudgetInKBytesPerSec")] public string NetActorDiscoveryBudgetInKBytesPerSec { get; set; } = "0";
        [JsonPropertyName("RankKillFarmMultiplier")] public string RankKillFarmMultiplier { get; set; } = "0.000000";
        [JsonPropertyName("MaxTeamScoreDiscrepancyPercent")] public string MaxTeamScoreDiscrepancyPercent { get; set; } = "0.000000";
        [JsonPropertyName("NonRenderedCharacterAnimationScale")] public string NonRenderedCharacterAnimationScale { get; set; } = "1.000000";
        [JsonPropertyName("MinBracketPriority")] public string MinBracketPriority { get; set; } = "0.000000";
        [JsonPropertyName("primaryAssetId")] public string PrimaryAssetId { get; set; } = "FortPlaylistAthena:Playlist_DefaultSolo";
        [JsonPropertyName("FortReleaseVersion")] public FortReleaseVersion FortReleaseVersion { get; set; } = new();
        [JsonPropertyName("DBNOType")] public string DBNOType { get; set; } = "On";
        [JsonPropertyName("StormEffectDelay")] public string StormEffectDelay { get; set; } = "120.000000";
        [JsonPropertyName("ProximityVoiceChatAttenuationSettings")] public string ProximityVoiceChatAttenuationSettings { get; set; } = "";
        [JsonPropertyName("AircraftPathMidpointSelectionRadiusMax")] public string AircraftPathMidpointSelectionRadiusMax { get; set; } = "40000.000000";
        [JsonPropertyName("WarmupEarlyCountdownDuration")] public string WarmupEarlyCountdownDuration { get; set; } = "0.000000";
        [JsonPropertyName("PlaylistId")] public string PlaylistId { get; set; } = "2";
        [JsonPropertyName("ServerMaxTickRate")] public string ServerMaxTickRate { get; set; } = "UseDefault";
        [JsonPropertyName("WarmupCountdownDuration")] public string WarmupCountdownDuration { get; set; } = "0.000000";
        [JsonPropertyName("DestructedBuildingInGridTimeout")] public string DestructedBuildingInGridTimeout { get; set; } = "0.000000";
        [JsonPropertyName("MaxSocialPartySize")] public string MaxSocialPartySize { get; set; } = "1";
        [JsonPropertyName("RankLossFloorMod")] public string RankLossFloorMod { get; set; } = "0.000000";
        [JsonPropertyName("PlacementLossMin")] public string PlacementLossMin { get; set; } = "0.000000";
        [JsonPropertyName("RewardPlacementBonusType")] public string RewardPlacementBonusType { get; set; } = "Solo";
        [JsonPropertyName("DefaultFirstTeam")] public string DefaultFirstTeam { get; set; } = "3";
        [JsonPropertyName("DefaultLastTeam")] public string DefaultLastTeam { get; set; } = "102";
        [JsonPropertyName("MaxTeamCount")] public string MaxTeamCount { get; set; } = "100";

        // Complex Objects
        [JsonPropertyName("UIDisplaySubName")] public DisplayInfo UIDisplaySubName { get; set; } = new();
        [JsonPropertyName("UIDisplayName")] public DisplayInfo UIDisplayName { get; set; } = new();
        [JsonPropertyName("UIDescription")] public DisplayInfo UIDescription { get; set; } = new();
        [JsonPropertyName("JoinInProgressMatchType")] public DisplayInfo JoinInProgressMatchType { get; set; } = new();
        [JsonPropertyName("GameplayTagContainer")] public GameplayTagContainer GameplayTagContainer { get; set; } = new();
        [JsonPropertyName("FillRateTable")] public List<FillRateTableEntry> FillRateTable { get; set; } = new();
        [JsonPropertyName("ModifierList")] public List<string> ModifierList { get; set; } = new();
        [JsonPropertyName("GameFeaturePluginURLsToLoad")] public List<string> GameFeaturePluginURLsToLoad { get; set; } = new();
        [JsonPropertyName("CalendarEventsForEndOfMatchUpdate")] public List<object> CalendarEventsForEndOfMatchUpdate { get; set; } = new();
        [JsonPropertyName("CurieManagerConfigOverrides")] public List<object> CurieManagerConfigOverrides { get; set; } = new();
        [JsonPropertyName("SkippedGamePhaseNotification")] public List<object> SkippedGamePhaseNotification { get; set; } = new();
        [JsonPropertyName("PlayerRatingBrackets")] public List<object> PlayerRatingBrackets { get; set; } = new();
        [JsonPropertyName("BracketDefinitions")] public List<object> BracketDefinitions { get; set; } = new();
        [JsonPropertyName("PriorityRatingExpansion")] public List<object> PriorityRatingExpansion { get; set; } = new();
        [JsonPropertyName("BuiltInGameFeaturePluginsToLoad")] public List<object> BuiltInGameFeaturePluginsToLoad { get; set; } = new();
    }

    public class FortReleaseVersion
    {
        [JsonPropertyName("VersionName")] public string VersionName { get; set; } = "Legacy";
    }

    public class DisplayInfo
    {
        [JsonPropertyName("Category")] public string Category { get; set; } = "Game";
        [JsonPropertyName("NativeCulture")] public string NativeCulture { get; set; } = "";
        [JsonPropertyName("Namespace")] public string Namespace { get; set; } = "";
        [JsonPropertyName("LocalizedStrings")] public List<object> LocalizedStrings { get; set; } = new();
        [JsonPropertyName("bIsMinimalPatch")] public bool BIsMinimalPatch { get; set; } = false;
        [JsonPropertyName("NativeString")] public string NativeString { get; set; } = "";
        [JsonPropertyName("Key")] public string Key { get; set; } = "";
    }

    public class GameplayTagContainer
    {
        [JsonPropertyName("GameplayTags")]
        public List<GameplayTag> GameplayTags { get; set; } = new()
        {
            new GameplayTag { TagName = "Athena.Playlist.DefaultXP" },
            new GameplayTag { TagName = "Athena.Playlist.Default" },
            new GameplayTag { TagName = "Athena.Playlist.Core" },
            new GameplayTag { TagName = "Athena.Playlist.Solo" },
            new GameplayTag { TagName = "Athena.Plugin.GameMod.Gasket" },
            new GameplayTag { TagName = "Athena.Quests.NoBuild.Exclude" },
            new GameplayTag { TagName = "Behavior.Playlist.UseTimeSlicedWorldReady" }
        };
    }

    public class GameplayTag
    {
        [JsonPropertyName("TagName")] public string TagName { get; set; }
    }

    public class FillRateTableEntry
    {
        [JsonPropertyName("MinFillPct")] public string MinFillPct { get; set; }
        [JsonPropertyName("MinMmr")] public string MinMmr { get; set; }
        [JsonPropertyName("MaxPriority")] public string MaxPriority { get; set; }
        [JsonPropertyName("MaxFillPct")] public string MaxFillPct { get; set; }
        [JsonPropertyName("MaxMmr")] public string MaxMmr { get; set; }
    }
}