using System.Text.Json.Serialization;

namespace Helios.Classes.Storefront.Dashboard.FortniteAPI
{
    public class CosmeticType
    {
        [JsonPropertyName("value")]
        public string Value { get; set; }
        [JsonPropertyName("displayValue")]
        public string DisplayValue { get; set; }
        [JsonPropertyName("backendValue")]
        public string BackendValue { get; set; }
    }
}