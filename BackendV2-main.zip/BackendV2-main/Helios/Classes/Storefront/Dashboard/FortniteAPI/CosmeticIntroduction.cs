using System.Text.Json.Serialization;

namespace Helios.Classes.Storefront.Dashboard.FortniteAPI
{
    public class CosmeticIntroduction
    {
        [JsonPropertyName("chapter")]
        public string Chapter { get; set; }
        [JsonPropertyName("season")]
        public string Season { get; set; }
        [JsonPropertyName("text")]
        public string Text { get; set; }
        [JsonPropertyName("backendValue")]
        public int BackendValue { get; set; }
    }
}