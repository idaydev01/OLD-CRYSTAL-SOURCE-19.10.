using System.Text.Json.Serialization;

namespace Helios.Classes.Storefront.Dashboard.FortniteAPI
{
    public class CosmeticImages
    {
        [JsonPropertyName("smallIcon")]
        public string SmallIcon { get; set; }
        [JsonPropertyName("icon")]
        public string Icon { get; set; }
        [JsonPropertyName("featured")]
        public string Featured { get; set; }
    }
}