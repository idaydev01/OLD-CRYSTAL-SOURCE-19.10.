using Helios.Classes.Storefront.Dashboard.FortniteAPI;
using System.Text.Json.Serialization;

public class APIResponse
{
    [JsonPropertyName("status")]
    public int Status { get; set; }

    [JsonPropertyName("data")]
    public JSONResponse Data { get; set; }
}
