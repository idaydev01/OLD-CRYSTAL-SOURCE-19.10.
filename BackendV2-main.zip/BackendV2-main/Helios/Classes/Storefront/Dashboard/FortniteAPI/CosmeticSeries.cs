using System.Text.Json.Serialization;

namespace Helios.Classes.Storefront.Dashboard.FortniteAPI
{
    public class CosmeticSeries
    {
        [JsonPropertyName("value")]
        public string Value { get; set; }
        [JsonPropertyName("image")]
        public string Image { get; set; }
        [JsonPropertyName("colors")]
        public List<string> Colors { get; set; }
        [JsonPropertyName("backendValue")]
        public string BackendValue { get; set; }
    }
}