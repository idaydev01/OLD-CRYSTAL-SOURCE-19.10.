using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Helios.Classes.Storefront
{
    public class Meta
    {
        [JsonPropertyName("NewDisplayAssetPath")]
        public string NewDisplayAssetPath { get; set; }
        public string LayoutId { get; set; }
        public string TileSize { get; set; }
        public string AnalyticOfferGroupId { get; set; }
        public string SectionId { get; set; }
        [JsonPropertyName("templateId")]
        public string TemplateId { get; set; }
        [JsonPropertyName("displayAssetPath")]
        public string DisplayAssetPath { get; set; }
    }
}