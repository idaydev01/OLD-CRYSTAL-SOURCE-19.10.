﻿using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace Helios.Classes.MCP;

public class PastSeasons
{
    [JsonProperty("seasonNumber")]
    [JsonPropertyName("seasonNumber")]
    public int SeasonNumber { get; set; }
    [JsonProperty("numWins")]
    [JsonPropertyName("numWins")]
    public int NumWins { get; set; }
    [JsonProperty("numHighBracket")]
    [JsonPropertyName("numHighBracket")]
    public int NumHighBracket { get; set; }
    [JsonProperty("numLowBracket")]
    [JsonPropertyName("numLowBracket")]
    public int NumLowBracket { get; set; }
    [JsonProperty("seasonXp")]
    [JsonPropertyName("seasonXp")]
    public int SeasonXp { get; set; }
    [JsonProperty("seasonLevel")]
    [JsonPropertyName("seasonLevel")]
    public int SeasonLevel { get; set; }
    [JsonProperty("bookXp")]
    [JsonPropertyName("bookXp")]
    public int BookXp { get; set; }
    [JsonProperty("bookLevel")]
    public int BookLevel { get; set; }
    [JsonProperty("purchasedVIP")]
    [JsonPropertyName("purchasedVIP")]
    public bool PurchasedVIP { get; set; }
    [JsonProperty("numRoyalRoyales")]
    [JsonPropertyName("numRoyalRoyales")]
    public int NumRoyalRoyales { get; set; }
    [JsonProperty("survivorTier")]
    [JsonPropertyName("survivorTier")]
    public int SurvivorTier { get; set; }
    [JsonProperty("survivorPrestige")]
    [JsonPropertyName("survivorPrestige")]
    public int SurvivorPrestige { get; set; }
}