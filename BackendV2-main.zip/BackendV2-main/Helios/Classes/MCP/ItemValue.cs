using Newtonsoft.Json;

namespace Helios.Classes.MCP;

public class ItemValue
{
    public bool? item_seen { get; set; }
    public List<Variants>? variants { get; set; }
    public bool? favorite { get; set; }
    public int? xp { get; set; }
    public int? max_level_bonus { get; set; }
    public int? level { get; set; }

    public override string ToString()
    {
        return JsonConvert.SerializeObject(this, Formatting.Indented);
    }
}