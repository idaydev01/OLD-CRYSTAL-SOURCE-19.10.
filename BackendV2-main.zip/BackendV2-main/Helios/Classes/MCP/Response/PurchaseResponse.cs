using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace Helios.Classes.MCP.Response 
{
    public class PurchaseResponse : BaseMCPResponse
    {
        [JsonProperty("notifications")]
        public List<object> Notifications { get; set; } = new();
        [JsonProperty("multiUpdate")]
        public List<MultiUpdate> MultiUpdate { get; set; } = new List<MultiUpdate>();
    }
}