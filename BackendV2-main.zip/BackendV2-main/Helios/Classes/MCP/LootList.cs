namespace Helios.Classes.MCP;

public class LootList
{
    public string ItemType { get; set; }
    public string ItemGuid { get; set; }
    public int Quantity { get; set; }
}