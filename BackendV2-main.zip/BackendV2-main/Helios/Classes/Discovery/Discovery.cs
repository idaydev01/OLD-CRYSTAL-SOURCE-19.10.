﻿namespace Helios.Classes.Discovery;

public class Discovery
{
    public class DiscoveryResponse
    {
        public List<Panel> Panels { get; set; } = new();
        public List<string> TestCohorts { get; set; } = new();
        public Dictionary<string, object> ModeSets { get; set; } = new();
    }

    public class Panel
    {
        public string PanelName { get; set; } = string.Empty;
        public List<Page> Pages { get; set; } = new();
    }

    public class Page
    {
        public List<Result> Results { get; set; } = new();
        public bool HasMore { get; set; }
    }

    public class Result
    {
        public LinkData LinkData { get; set; } = new();
        public object? LastVisited { get; set; }
        public string LinkCode { get; set; } = string.Empty;
        public bool IsFavorite { get; set; }
    }

    public class LinkData
    {
        public string Namespace { get; set; } = string.Empty;
        public string Mnemonic { get; set; } = string.Empty;
        public string LinkType { get; set; } = string.Empty;
        public bool Active { get; set; }
        public bool Disabled { get; set; }
        public int Version { get; set; }
        public string ModerationStatus { get; set; } = string.Empty;
        public string AccountId { get; set; } = string.Empty;
        public string CreatorName { get; set; } = string.Empty;
        public List<string> DescriptionTags { get; set; } = new();
        public Dictionary<string, object> Metadata { get; set; } = new();
    }
}