﻿using System.Xml.Serialization;
using Helios.Configuration;

namespace Helios.Classes.Typings;

[XmlRoot("config", Namespace = Constants.xmlString)]
public class ConfigTypes
{
    [XmlElement("DatabaseConnectionUrl")]
    public string DatabaseConnectionUrl { get; set; }
    [XmlElement("JWTClientSecret")]
    public string JWTClientSecret { get; set; }
    [XmlElement("GameDirectory")]
    public string GameDirectory { get; set; }
    [XmlElement("CurrentVersion")]
    public string CurrentVersion { get; set; }

    [XmlElement("DiscordGuildId")]
    public string DiscordGuildId { get; set; }

    [XmlElement("DiscordClientId")]
    public string DiscordClientId { get; set; }
    [XmlElement("DiscordClientSecret")]
    public string DiscordClientSecret { get; set; }
    [XmlElement("DiscordBotToken")]
    public string DiscordBotToken { get; set; }
    [XmlElement("DiscordWebhookUrl")]
    public string DiscordWebhookUrl { get; set; }
    [XmlElement("Maintenance")]
    public bool Maintenance { get; set; }
    [XmlElement("isTesting")]
    public bool isTesting { get; set; }
}
