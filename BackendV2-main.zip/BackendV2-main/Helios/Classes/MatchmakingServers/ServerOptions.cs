using System.Text.Json.Serialization;

namespace Helios.Classes.MatchmakingServers;

public class ServerOptions
{
    [JsonPropertyName("region")]
    public string Region { get; set; }
    [JsonPropertyName("userAgent")]
    public string UserAgent { get; set; }
    [JsonPropertyName("matchId")]
    public string MatchId { get; set; }
    [JsonPropertyName("playlist")]
    public string Playlist { get; set; }
}