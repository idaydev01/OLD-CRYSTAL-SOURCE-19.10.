﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class TournamentInfo
    {
        [JsonPropertyName("tournaments")]
        public List<Tournament> Tournaments { get; set; }
        [JsonPropertyName("_type")]
        public string Type { get; set; }
    }
}
