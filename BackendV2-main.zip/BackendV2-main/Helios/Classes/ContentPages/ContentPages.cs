﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class ContentPages
    {
        [JsonPropertyName("jcr:isCheckedOut")]
        public bool IsCheckedOut { get; set; }

        [JsonPropertyName("_title")]
        public string Title { get; set; }

        [JsonPropertyName("jcr:baseVersion")]
        public string BaseVersion { get; set; }

        [JsonPropertyName("_activeDate")]
        public DateTime ActiveDate { get; set; }

        [JsonPropertyName("lastModified")]
        public DateTime LastModified { get; set; }

        [JsonPropertyName("_locale")]
        public string Locale { get; set; }

        [JsonPropertyName("creative")]
        public Creative Creative { get; set; }

        [JsonPropertyName("lobby")]
        public Lobby Lobby { get; set; }

        [JsonPropertyName("dynamicbackgrounds")]
        public DynamicBackgrounds DynamicBackgrounds { get; set; }

        [JsonPropertyName("battleroyalenews")]
        public BattleRoyaleNews BattleRoyaleNews { get; set; }

        [JsonPropertyName("battleroyalenewsv2")]
        public BattleRoyaleNewsV2 BattleRoyaleNewsV2 { get; set; }
        [JsonPropertyName("emergencynotice")]
        public EmergencyNotice EmergencyNotice { get; set; }
        [JsonPropertyName("emergencynoticev2")]
        public EmergencyNoticeV2 EmergencyNoticeV2 { get; set; }

        [JsonPropertyName("tournamentinformation")]
        public TournamentInformation TournamentInformation { get; set; }

        [JsonPropertyName("playlistinformation")]
        public PlaylistInformation PlaylistInformation { get; set; }
        [JsonPropertyName("shopSections")]
        public ShopSections ShopSections { get; set; }
        [JsonPropertyName("scoringrulesinformation")]
        public ScoringRulesInfo ScoringRulesInfo { get; set; }
    }
}
