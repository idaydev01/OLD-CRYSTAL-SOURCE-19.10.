using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class ScoringRulesInfo
    {
        [JsonPropertyName("_type")]
        public string Type { get; set; } = "Scoring Rules Info";

        [JsonPropertyName("scoring_rules_info")]
        public ScoringRulesInformation ScoringRulesInformation { get; set; }

        [JsonPropertyName("_title")]
        public string Title { get; set; }

        [JsonPropertyName("_noIndex")]
        public bool NoIndex { get; set; }

        [JsonPropertyName("_activeDate")]
        public string ActiveDate { get; set; }

        [JsonPropertyName("lastModified")]
        public string LastModified { get; set; }

        [JsonPropertyName("_locale")]
        public string Locale { get; set; }

        [JsonPropertyName("_templateName")]
        public string TemplateName { get; set; }

        [JsonPropertyName("_suggestedPrefetch")]
        public List<object> SuggestedPrefetch { get; set; } = new List<object>();
    }

    public class ScoringRulesInformation
    {
        [JsonPropertyName("_type")]
        public string Type { get; set; } = "Scoring Rules Info";

        [JsonPropertyName("scoring_rules")]
        public List<ScoringRulesDisplayInfo> ScoringRules { get; set; }
    }
}
