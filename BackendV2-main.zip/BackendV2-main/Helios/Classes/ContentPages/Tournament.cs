﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class Tournament
    {
        [JsonPropertyName("loading_screen_image")]
        public string LoadingScreenImage { get; set; }

        [JsonPropertyName("title_color")]
        public string TitleColor { get; set; }

        [JsonPropertyName("background_right_color")]
        public string BackgroundRightColor { get; set; }

        [JsonPropertyName("background_text_color")]
        public string BackgroundTextColor { get; set; }

        [JsonPropertyName("_type")]
        public string Type { get; set; }

        [JsonPropertyName("tournament_display_id")]
        public string TournamentDisplayId { get; set; }

        [JsonPropertyName("highlight_color")]
        public string HighlightColor { get; set; }

        [JsonPropertyName("primary_color")]
        public string PrimaryColor { get; set; }

        [JsonPropertyName("title_line_1")]
        public string TitleLine1 { get; set; } // make this a dictionary if you wanna do translations

        [JsonPropertyName("title_line_2")]
        public string TitleLine2 { get; set; } // make this a dictionary if you wanna do translations

        [JsonPropertyName("shadow_color")]
        public string ShadowColor { get; set; }

        [JsonPropertyName("background_left_color")]
        public string BackgroundLeftColor { get; set; }

        [JsonPropertyName("poster_fade_color")]
        public string PosterFadeColor { get; set; }

        [JsonPropertyName("secondary_color")]
        public string SecondaryColor { get; set; }

        [JsonPropertyName("playlist_tile_image")]
        public string PlaylistTileImage { get; set; }

        [JsonPropertyName("base_color")]
        public string BaseColor { get; set; }

        [JsonPropertyName("pin_score_requirement")]
        public int PinScoreRequirement { get; set; }

        [JsonPropertyName("pin_earned_text")]
        public string PinEarnedText { get; set; } // make this a dictionary if you wanna do translations

        [JsonPropertyName("schedule_info")]
        public string ScheduleInfo { get; set; } // make this a dictionary if you wanna do translations

        [JsonPropertyName("flavor_description")]
        public string FlavorDescription { get; set; } // make this a dictionary if you wanna do translations

        [JsonPropertyName("poster_front_image")]
        public string PosterFrontImage { get; set; }

        [JsonPropertyName("poster_back_image")]
        public string PosterBackImage { get; set; }

        [JsonPropertyName("short_format_title")]
        public string ShortFormatTitle { get; set; }

        [JsonPropertyName("long_format_title")]
        public string LongFormatTitle { get; set; }

        [JsonPropertyName("details_description")]
        public string DetailsDescription { get; set; } // make this a dictionary if you wanna do translations
    }
}
