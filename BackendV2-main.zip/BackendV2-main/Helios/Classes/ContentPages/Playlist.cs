﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class Playlist
    {
        [JsonPropertyName("image")]
        public string Image { get; set; }

        [JsonPropertyName("playlist_name")]
        public string PlaylistName { get; set; }

        [JsonPropertyName("hidden")]
        public bool Hidden { get; set; }

        [JsonPropertyName("special_border")]
        public string SpecialBorder { get; set; }

        [JsonPropertyName("_type")]
        public string Type { get; set; }

        [JsonPropertyName("displayName")]
        public string DisplayName { get; set; }
    }
}
