﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages;

public class EmergencyNotice
{
    [JsonPropertyName("news")]
    public EmergencyNoticeNews News { get; set; }
    [JsonPropertyName("_title")]
    public string Title { get; set; }
    [JsonPropertyName("_noIndex")]
    public bool NoIndex { get; set; }
    [JsonPropertyName("alwaysShow")]
    public bool AlwaysShow { get; set; }
    [JsonPropertyName("_activeDate")]
    public string ActiveDate { get; set; }
    [JsonPropertyName("lastModified")]
    public string LastModified { get; set; }
    [JsonPropertyName("_locale")]
    public string Locale { get; set; }
}