﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class PlaylistInformation
    {
        [JsonPropertyName("frontend_matchmaking_header_style")]
        public string FrontendMatchmakingHeaderStyle { get; set; }

        [JsonPropertyName("_title")]
        public string Title { get; set; }

        [JsonPropertyName("frontend_matchmaking_header_text")]
        public string FrontendMatchmakingHeaderText { get; set; }

        [JsonPropertyName("playlist_info")]
        public PlaylistInfo PlaylistInfo { get; set; }

        [JsonPropertyName("_noIndex")]
        public bool NoIndex { get; set; }

        [JsonPropertyName("_activeDate")]
        public string ActiveDate { get; set; }

        [JsonPropertyName("lastModified")]
        public string LastModified { get; set; }

        [JsonPropertyName("_locale")]
        public string Locale { get; set; }
    }
}
