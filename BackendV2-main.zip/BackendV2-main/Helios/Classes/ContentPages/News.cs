﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class News
    {
        [JsonPropertyName("_type")]
        public string Type { get; set; }

        [JsonPropertyName("messages")]
        public List<object> Messages { get; set; }

        [JsonPropertyName("motds")]
        public List<object> Motds { get; set; }

        [JsonPropertyName("platform_messages")]
        public List<object> PlatformMessages { get; set; }
    }
}
