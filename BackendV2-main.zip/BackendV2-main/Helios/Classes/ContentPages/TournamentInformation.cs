﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class TournamentInformation
    {
        [JsonPropertyName("tournament_info")]
        public TournamentInfo TournamentInfo { get; set; }

        [JsonPropertyName("_title")]
        public string Title { get; set; }

        [JsonPropertyName("_noIndex")]
        public bool NoIndex { get; set; }

        [JsonPropertyName("_activeDate")]
        public string ActiveDate { get; set; }

        [JsonPropertyName("lastModified")]
        public string LastModified { get; set; }

        [JsonPropertyName("_locale")]
        public string Locale { get; set; }
    }
}
