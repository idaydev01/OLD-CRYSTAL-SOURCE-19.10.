﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class BattleRoyaleNewsV2
    {
        [JsonPropertyName("news")]
        public NewsV2 News { get; set; }

        [JsonPropertyName("_title")]
        public string Title { get; set; }

        [JsonPropertyName("_noIndex")]
        public bool NoIndex { get; set; }

        [JsonPropertyName("alwaysShow")]
        public bool AlwaysShow { get; set; }

        [JsonPropertyName("_activeDate")]
        public DateTime ActiveDate { get; set; }

        [JsonPropertyName("lastModified")]
        public DateTime LastModified { get; set; }

        [JsonPropertyName("_locale")]
        public string Locale { get; set; }

        [JsonPropertyName("_templateName")]
        public string TemplateName { get; set; }
    }
}
