﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages;

public class EmergencyNoticeNews
{
    [JsonPropertyName("_type")]
    public string Type { get; set; }
    [JsonPropertyName("messages")]
    public List<EmergencyNoticeMessages> Messages { get; set; }
}