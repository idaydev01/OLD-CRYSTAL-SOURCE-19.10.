﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class PlaylistInfo
    {
        [JsonPropertyName("_type")]
        public string Type { get; set; }

        [JsonPropertyName("playlists")]
        public List<Playlist> Playlists { get; set; }
    }
}
