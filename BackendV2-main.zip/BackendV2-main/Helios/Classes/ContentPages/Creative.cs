﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class Creative
    {
        [JsonPropertyName("_type")]
        public string Type { get; set; }

        [JsonPropertyName("message")]
        public Message Message { get; set; }
    }
}
