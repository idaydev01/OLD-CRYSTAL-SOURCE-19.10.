﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class DynamicBackgrounds
    {
        [JsonPropertyName("backgrounds")]
        public BackgroundList Backgrounds { get; set; }

        [JsonPropertyName("_title")]
        public string Title { get; set; }

        [JsonPropertyName("_noIndex")]
        public bool NoIndex { get; set; }

        [JsonPropertyName("_activeDate")]
        public DateTime ActiveDate { get; set; }

        [JsonPropertyName("lastModified")]
        public DateTime LastModified { get; set; }

        [JsonPropertyName("_locale")]
        public string Locale { get; set; }
    }
}
