using System.Text.Json.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Helios.Classes.GameSessions;

public class MatchmakingSession
{
    [JsonPropertyName("ownerId")]
    public string? OwnerId { get; set; }

    [JsonPropertyName("ownerName")]
    public string? OwnerName { get; set; }

    [JsonPropertyName("serverName")]
    public string? ServerName { get; set; }

    [JsonPropertyName("maxPublicPlayers")]
    public int MaxPublicPlayers { get; set; }

    [JsonPropertyName("maxPrivatePlayers")]
    public int MaxPrivatePlayers { get; set; }

    [JsonPropertyName("shouldAdvertise")]
    public bool ShouldAdvertise { get; set; }

    [JsonPropertyName("allowJoinInProgress")]
    public bool AllowJoinInProgress { get; set; }

    [JsonPropertyName("isDedicated")]
    public bool IsDedicated { get; set; }

    [JsonPropertyName("usesStats")]
    public bool UsesStats { get; set; }

    [JsonPropertyName("allowInvites")]
    public bool AllowInvites { get; set; }

    [JsonPropertyName("usesPresence")]
    public bool UsesPresence { get; set; }

    [JsonPropertyName("allowJoinViaPresence")]
    public bool AllowJoinViaPresence { get; set; }

    [JsonPropertyName("allowJoinViaPresenceFriendsOnly")]
    public bool AllowJoinViaPresenceFriendsOnly { get; set; }

    [JsonPropertyName("buildUniqueId")]
    public string? BuildUniqueId { get; set; }

    [JsonPropertyName("attributes")]
    public Dictionary<string, object> Attributes { get; set; }

    [JsonPropertyName("serverPort")]
    public int ServerPort { get; set; }

    [JsonPropertyName("openPrivatePlayers")]
    public int OpenPrivatePlayers { get; set; }

    [JsonPropertyName("openPublicPlayers")]
    public int OpenPublicPlayers { get; set; }

    [JsonPropertyName("sortWeight")]
    public float SortWeight { get; set; }

    [JsonPropertyName("started")]
    public bool Started { get; set; }

    [JsonPropertyName("publicPlayers")]
    public List<string>? PublicPlayers { get; set; }

    [JsonPropertyName("privatePlayers")]
    public List<string>? PrivatePlayers { get; set; }

    [JsonPropertyName("serverAddress")]
    public string? ServerAddress { get; set; }

    [JsonPropertyName("lastUpdated")]
    public string? LastUpdated { get; set; }

    [JsonPropertyName("id")]
    public string? SessionId { get; set; }
}