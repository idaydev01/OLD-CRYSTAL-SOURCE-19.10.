﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.XMPP;
using Helios.HTTP.Utilities.Interfaces;
using Helios.Utilities;
using Helios.Utilities.Caching;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Tokens;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Helios.Controllers.OAuth;

[ApiController]
[Route("/account/api/oauth/")]
public class OAuthController : ControllerBase
{
    private readonly IBodyParser _bodyParser;
    private const int AccessTokenLifetimeHours = 87600;
    private const int RefreshTokenLifetimeDays = 3650;

    public OAuthController(IBodyParser bodyParser)
    {
        _bodyParser = bodyParser;
    }

    [HttpPost("token")]
    public async Task<IActionResult> AuthToken()
    {
        if (!Request.Headers.TryGetValue("Authorization", out var authHeaders) || string.IsNullOrEmpty(authHeaders))
            return AuthenticationErrors.InvalidHeader.Apply(HttpContext);

        var tokenParts = authHeaders.ToString().Split(' ', 2);
        if (tokenParts.Length != 2 || !tokenParts[0].Equals("Basic", StringComparison.OrdinalIgnoreCase))
        {
            return AuthenticationErrors.OAuth.InvalidClient
                .WithMessage("Invalid authorization header format. Expected 'Basic <token>'.")
                .Apply(HttpContext);
        }

        string decodedClientAuth;
        try
        {
            decodedClientAuth = Encoding.UTF8.GetString(Convert.FromBase64String(tokenParts[1]));
        }
        catch
        {
            return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);
        }

        int colonIndex = decodedClientAuth.IndexOf(':');
        if (colonIndex == -1)
            return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);

        string clientId = decodedClientAuth.Substring(0, colonIndex);

        Dictionary<string, string> body;
        try
        {
            var parsedBody = await _bodyParser.ParseAsync(Request);
            body = new Dictionary<string, string>(parsedBody);
        }
        catch
        {
            return AuthenticationErrors.InvalidRequest.Apply(HttpContext);
        }

        if (!body.TryGetValue("grant_type", out var grantType))
            return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);

        switch (grantType)
        {
            case "client_credentials":
                return HandleClientCredentialsGrant(clientId);

            case "password":
                return await HandlePasswordGrantAsync(clientId, body);

            case "exchange_code":
                return await HandleExchangeCode(body, clientId);

            case "refresh_token":
                return await HandleRefreshToken(body, clientId);

            default:
                Logger.Info($"Unsupported grant type: {grantType}");
                return AuthenticationErrors.OAuth.UnsupportedGrant(grantType).Apply(HttpContext);
        }
    }


    private async Task<IActionResult> HandleRefreshToken(Dictionary<string, string> body, string clientId)
    {
        if (!body.TryGetValue("refresh_token", out string refreshToken) || string.IsNullOrEmpty(refreshToken))
            return BasicErrors.BadRequest
                .WithMessage("'refresh_token' is missing or invalid.")
                .Apply(HttpContext);

        var tokensRepository = Constants.repositoryPool.For<Tokens>();
        var userRepository = Constants.repositoryPool.For<User>();

        refreshToken = refreshToken.Replace("eg1~", "").Replace("$", "");

        var validToken = await tokensRepository.FindByColumnsAsync(new Dictionary<string, object>
        {
            { "token", refreshToken },
            { "type", "refreshtoken" }
        });
        if (validToken == null)
            return AuthenticationErrors.OAuth.InvalidRefresh.Apply(HttpContext);

        var user = await userRepository.FindByColumnAsync("accountid", validToken.AccountId);
        if (user == null)
            return AccountErrors.AccountNotFound(validToken.AccountId)
                .WithMessage($"User with id {validToken.AccountId} not found")
                .Apply(HttpContext);

        if (user.Banned)
            return AccountErrors.DisabledAccount.Apply(HttpContext);

        await tokensRepository.DeleteAsync(new Tokens { AccountId = user.AccountId, Type = "refreshtoken" });

        string accessToken = await TokenUtilities.CreateAccessTokenAsync(clientId, "refresh_token", user);
        string newRefreshToken = await TokenUtilities.CreateRefreshTokenAsync(clientId, user);

        var deviceId = Request.Headers.TryGetValue("X-Epic-Device-Id", out var rawDeviceId)
            ? rawDeviceId.ToString()
            : Guid.NewGuid().ToString("N");

        return Ok(new
        {
            access_token = accessToken,
            expires_in = AccessTokenLifetimeHours * 60 * 60,
            expires_at = DateTime.UtcNow.AddHours(AccessTokenLifetimeHours).ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
            token_type = "bearer",
            refresh_token = newRefreshToken,
            refresh_expires = RefreshTokenLifetimeDays * 24 * 60 * 60, 
            refresh_expires_at = DateTime.UtcNow.AddDays(RefreshTokenLifetimeDays).ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
            account_id = user.AccountId,
            client_id = clientId,
            internal_client = true,
            client_service = "fortnite",
            displayName = user.Username,
            app = "fortnite",
            in_app_id = user.AccountId,
            device_id = deviceId,
        });
    }

    private async Task<IActionResult> HandleExchangeCode(Dictionary<string, string> body, string clientId)
    {
        if (!body.TryGetValue("exchange_code", out string exchangeCode) || string.IsNullOrEmpty(exchangeCode))
            return BasicErrors.BadRequest
                .WithMessage("'exchange_code' is missing or invalid.")
                .Apply(HttpContext);

        var tokensRepository = Constants.repositoryPool.For<Tokens>();
        var userRepository = Constants.repositoryPool.For<User>();

        var validToken = await tokensRepository.FindByColumnAsync("token", exchangeCode);
        if (validToken == null)
            return AuthenticationErrors.OAuth.InvalidExchange(exchangeCode).Apply(HttpContext);

        var user = await userRepository.FindByColumnAsync("accountid", validToken.AccountId);
        if (user == null)
            return AccountErrors.AccountNotFound(validToken.AccountId)
                .WithMessage($"User with id {validToken.AccountId} not found")
                .Apply(HttpContext);

        if (user.Banned)
            return AccountErrors.DisabledAccount.Apply(HttpContext);

        await tokensRepository.DeleteAsync(new Tokens { AccountId = user.AccountId, Type = "exchange" });
        CleanupOldTokens(user.AccountId);
        
        if (user.Ac)
        {
            user.Ac = false;
            await userRepository.UpdateAsync(user);
        }

        var requestKey = $"user_token_req:{user.AccountId}";

        var (accessToken, refreshToken) = await Task.Run(() => HeliosFastCache.GetOrAdd<(string, string)>(
            requestKey,
            () => {
                var accessTokenTask = TokenUtilities.CreateAccessTokenAsync(clientId, "password", user);
                var refreshTokenTask = TokenUtilities.CreateRefreshTokenAsync(clientId, user);

                Task.WhenAll(accessTokenTask, refreshTokenTask).GetAwaiter().GetResult();

                // CleanupOldTokens(user.AccountId);

                return (accessTokenTask.Result, refreshTokenTask.Result);
            },
            TimeSpan.FromSeconds(5)
        ));

        var deviceId = Request.Headers.TryGetValue("X-Epic-Device-Id", out var rawDeviceId)
            ? rawDeviceId.ToString()
            : Guid.NewGuid().ToString("N");

        return Ok(new
        {
            access_token = accessToken,
            expires_in = AccessTokenLifetimeHours * 60 * 60, 
            expires_at = DateTime.UtcNow.AddHours(AccessTokenLifetimeHours).ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
            token_type = "bearer",
            account_id = user.AccountId,
            client_id = clientId,
            internal_client = true,
            client_service = "fortnite",
            refresh_token = refreshToken,
            refresh_expires = RefreshTokenLifetimeDays * 24 * 60 * 60, 
            refresh_expires_at = DateTime.UtcNow.AddDays(RefreshTokenLifetimeDays).ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
            displayName = user.Username,
            app = "fortnite",
            in_app_id = user.AccountId,
            device_id = deviceId,
        });
    }

    private IActionResult HandleClientCredentialsGrant(string clientId)
    {
        string cacheKey = $"client_token:{clientId}";

        if (HeliosFastCache.TryGet<(string Token, DateTime Expiry)>(cacheKey, out var tokenInfo) &&
            tokenInfo.Expiry > DateTime.UtcNow.AddMinutes(5))
        {
            var timeRemaining = (int)(tokenInfo.Expiry - DateTime.UtcNow).TotalSeconds;

            return Ok(new
            {
                access_token = $"eg1~{tokenInfo.Token}",
                expires_in = timeRemaining,
                expires_at = tokenInfo.Expiry.ToIsoUtcString(),
                token_type = "bearer",
                client_id = clientId,
                internal_client = true,
                client_service = "fortnite"
            });
        }

        var accessToken = TokenGenerator.GenerateToken(Constants.config.JWTClientSecret,
            Constants.config.JWTClientSecret);
        var expiresAt = DateTime.UtcNow.AddHours(AccessTokenLifetimeHours);

        HeliosFastCache.Set(cacheKey, (accessToken, expiresAt), TimeSpan.FromHours(AccessTokenLifetimeHours));

        return Ok(new
        {
            access_token = $"eg1~{accessToken}",
            expires_in = AccessTokenLifetimeHours * 60 * 60, 
            expires_at = expiresAt.ToIsoUtcString(),
            token_type = "bearer",
            client_id = clientId,
            internal_client = true,
            client_service = "fortnite"
        });
    }

    private async Task<IActionResult> HandlePasswordGrantAsync(string clientId, Dictionary<string, string> body)
    {
        if (!body.TryGetValue("username", out var username) || !body.TryGetValue("password", out var password))
        {
            return BasicErrors.BadRequest
                .WithMessage("Invalid username or password.")
                .Apply(HttpContext);
        }

        var userRepository = Constants.repositoryPool.For<User>();

        var user = await userRepository.FindAsync(new User { Email = username });

        if (user == null || user.Banned || !PasswordHasher.VerifyPassword(password, user.Password))
            return AuthenticationErrors.OAuth.InvalidAccountCredentials.Apply(HttpContext);

        var accountId = user.AccountId;
        var now = DateTime.UtcNow;

        if (user.Ac)
        {
            user.Ac = false;
            await userRepository.UpdateAsync(user);
        }

        var requestKey = $"user_token_req:{accountId}";

        var (accessToken, refreshToken) = await Task.Run(() => HeliosFastCache.GetOrAdd<(string, string)>(
            requestKey,
            () => {
                CleanupOldTokens(accountId);

                var accessTokenTask = TokenUtilities.CreateAccessTokenAsync(clientId, "password", user);
                var refreshTokenTask = TokenUtilities.CreateRefreshTokenAsync(clientId, user);

                Task.WhenAll(accessTokenTask, refreshTokenTask).GetAwaiter().GetResult();

                return (accessTokenTask.Result, refreshTokenTask.Result);
            },
            TimeSpan.FromSeconds(5)
        ));

        var deviceId = Request.Headers.TryGetValue("X-Epic-Device-Id", out var rawDeviceId)
            ? rawDeviceId.ToString()
            : Guid.NewGuid().ToString("N");

        return Ok(new
        {
            access_token = accessToken,
            expires_in = AccessTokenLifetimeHours * 60 * 60, 
            expires_at = now.AddHours(AccessTokenLifetimeHours).ToIsoUtcString(),
            token_type = "bearer",
            account_id = accountId,
            client_id = clientId,
            internal_client = true,
            client_service = "prod-fn",
            refresh_token = refreshToken,
            refresh_expires = RefreshTokenLifetimeDays * 24 * 60 * 60, 
            refresh_expires_at = now.AddDays(RefreshTokenLifetimeDays).ToIsoUtcString(),
            displayName = user.Username,
            app = "prod-fn",
            in_app_id = accountId,
            device_id = deviceId
        });
    }

    private void CleanupOldTokens(string accountId)
    {
        Task.Run(async () =>
        {
            try
            {
                var tokensRepository = Constants.repositoryPool.For<Tokens>();
                await tokensRepository.DeleteAsync(new Tokens { AccountId = accountId, Type = "accesstoken" });
                await tokensRepository.DeleteAsync(new Tokens { AccountId = accountId, Type = "refreshtoken" });
            }
            catch (Exception ex)
            {
                Logger.Error($"Error cleaing up old tokens: {ex.Message}");
            }
        });
    }

    [HttpGet("verify")]
    public async Task<IActionResult> VerifyToken()
    {
        if (!Request.Headers.TryGetValue("Authorization", out var authHeaders) || string.IsNullOrEmpty(authHeaders))
            return AuthenticationErrors.InvalidHeader.Apply(HttpContext);

        const string bearerPrefix = "Bearer ";
        string authHeader = authHeaders.ToString();

        if (!authHeader.StartsWith(bearerPrefix, StringComparison.OrdinalIgnoreCase))
            return AuthenticationErrors.InvalidHeader.Apply(HttpContext);

        string accessToken = authHeader[bearerPrefix.Length..].Trim();

        if (string.IsNullOrEmpty(accessToken))
            return AuthenticationErrors.InvalidToken(accessToken).WithMessage("Invalid Token").Apply(HttpContext);

        var decodedToken = TokenGenerator.DecodeToken(accessToken);
        if (decodedToken == null)
            return AuthenticationErrors.InvalidToken("Failed to decode token").Apply(HttpContext);

        string accountId = decodedToken["sub"] as string;
        if (string.IsNullOrEmpty(accountId))
            return AuthenticationErrors.InvalidToken(accessToken).WithMessage("Missing subject in token").Apply(HttpContext);

        var userRepository = Constants.repositoryPool.For<User>();

        var user = await userRepository.FindByColumnAsync("accountid", accountId);
        if (user == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);

        if (user.Banned)
            return AccountErrors.DisabledAccount.Apply(HttpContext);

        if (!decodedToken.TryGetValue("creationDate", out var creationDateValue) ||
            !DateTime.TryParse(creationDateValue.ToString(), out var creationDate))
        {
            Logger.Error("Invalid or missing creationDate in token.");
            return AuthenticationErrors.InvalidToken(accessToken).WithMessage("Invalid or missing 'creation_date' in token.")
                .Apply(HttpContext);
        }

        if (!decodedToken.TryGetValue("expiresIn", out var expiresInValue) ||
            !int.TryParse(expiresInValue.ToString(), out var expiresIn))
        {
            Logger.Error("Invalid or missing expiresIn in token.");
            return AuthenticationErrors.InvalidToken(accessToken).WithMessage("Invalid or missing 'exp' in token.")
                .Apply(HttpContext);
        }

        var expiry = creationDate.AddHours(expiresIn);
        var deviceId = Request.Headers.TryGetValue("X-Epic-Device-Id", out var rawDeviceId)
            ? rawDeviceId.ToString()
            : Guid.NewGuid().ToString("N");

        if (!decodedToken.TryGetValue("jti", out var jti) ||
            !decodedToken.TryGetValue("clid", out var clid) ||
            !decodedToken.TryGetValue("am", out var am))
            return AuthenticationErrors.InvalidToken(accessToken).WithMessage("Missing required token claims.")
                .Apply(HttpContext);

        return Ok(new
        {
            token = accessToken,
            session_id = jti.ToString(),
            token_type = "bearer",
            client_id = clid.ToString(),
            internal_client = true,
            client_service = "fortnite",
            account_id = user.AccountId,
            expires_in = (int)(expiry - DateTime.UtcNow).TotalSeconds,
            expires_at = expiry.AddHours(AccessTokenLifetimeHours),
            auth_method = am.ToString(),
            display_name = user.Username,
            app = "fortnite",
            in_app_id = user.AccountId,
            device_id = deviceId
        });
    }

    [HttpPost("/publickey/v2/publickey")]
    [HttpPost("/publickey/v1/publickey")]
    public async Task<IActionResult> CreatePublicKey()
    {
        if (!Request.Headers.TryGetValue("Authorization", out var authHeaders) || string.IsNullOrEmpty(authHeaders))
            return AuthenticationErrors.InvalidHeader.Apply(HttpContext);

        const string bearerPrefix = "Bearer ";
        string authHeader = authHeaders.ToString();

        if (!authHeader.StartsWith(bearerPrefix, StringComparison.OrdinalIgnoreCase))
            return AuthenticationErrors.InvalidHeader.Apply(HttpContext);

        string token = authHeader[bearerPrefix.Length..].Trim();

        if (!token.StartsWith("eg1~", StringComparison.OrdinalIgnoreCase))
            return AuthenticationErrors.InvalidToken(token).WithMessage("Missing expected token prefix").Apply(HttpContext);

        string accessToken = token["eg1~".Length..];

        if (string.IsNullOrEmpty(accessToken))
            return AuthenticationErrors.InvalidToken(token).WithMessage("Invalid Token").Apply(HttpContext);

        var decodedToken = TokenGenerator.DecodeToken(accessToken);
        if (decodedToken == null)
            return AuthenticationErrors.InvalidToken("Failed to decode token").Apply(HttpContext);

        string accountId = decodedToken["sub"] as string;
        if (string.IsNullOrEmpty(accountId))
            return AuthenticationErrors.InvalidToken(token).WithMessage("Missing subject in token").Apply(HttpContext);

        var userRepository = Constants.repositoryPool.For<User>();

        var user = await userRepository.FindByColumnAsync("accountid", accountId);
        if (user == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);

        if (user.Banned)
            return AccountErrors.DisabledAccount.Apply(HttpContext);

        string requestBody = await new StreamReader(Request.Body).ReadToEndAsync();
        JObject requestData;

        try
        {
            requestData = JObject.Parse(requestBody);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        var key = requestData["key"]?.ToString();
        string kid = DateTime.UtcNow.ToString("yyyyMMdd");
        string keyGuid = Guid.NewGuid().ToString();

        var jwt = await TokenUtilities.CreatePublicKeyAsync(user, "legacy", keyGuid, kid, key);
        return Ok(new
        {
            key,
            account_id = user.AccountId,
            key_guid = keyGuid,
            kid,
            expiration = "9999-12-31T23:59:59.999Z",
            jwt,
            type = "legacy"
        });
    }

    [HttpDelete("sessions/kill/{token}")]
    public async Task<IActionResult> KillSession(string accessToken)
    {
        if (string.IsNullOrEmpty(accessToken))
            return BasicErrors.BadRequest.WithMessage("Token is missing.").Apply(HttpContext);

        if (accessToken.StartsWith("eg1~"))
            accessToken = accessToken.Substring(4);

        if (!Request.Headers.TryGetValue("Authorization", out var authHeaders) ||
            authHeaders.Count == 0 || string.IsNullOrEmpty(authHeaders[0]))
            return AuthenticationErrors.InvalidHeader.Apply(HttpContext);

        var decodedToken = TokenGenerator.DecodeToken(accessToken);
        if (decodedToken == null)
            return AuthenticationErrors.InvalidToken("Failed to decode token").Apply(HttpContext);

        if (!decodedToken.TryGetValue("sub", out var subClaim) || subClaim is not string accountId || string.IsNullOrEmpty(accountId))
            return AuthenticationErrors.InvalidToken(accessToken).WithMessage("Missing subject in token").Apply(HttpContext);

        var userRepository = Constants.repositoryPool.For<User>();

        var userTask = userRepository.FindByColumnAsync("accountid", accountId);
        var cleanupTask = Task.Run(() => CleanupOldTokens(accountId));

        var user = await userTask;
        if (user == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);

        if (user.Banned)
            return AccountErrors.DisabledAccount.Apply(HttpContext);

        await Constants.GlobalXmppClientService.DeleteUserAsync(user.AccountId);

        //var deletedCount = await sessionsRepository.DeleteByColumnAsync("accountid", accountId);
        await cleanupTask;

        return Ok();
    }
}
