﻿ using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.HTTP.Utilities.Interfaces;
using Helios.Utilities;
using Helios.Utilities.Caching;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Tokens;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
﻿﻿using System.Text;

namespace Helios.Controllers.OAuth;

public class EosController : ControllerBase
{
    private readonly IBodyParser _bodyParser;
    private const int AccessTokenLifetimeHours = 8;
    private const int RefreshTokenLifetimeDays = 7;

    public EosController(IBodyParser bodyParser)
    {
        _bodyParser = bodyParser;
    }

    [HttpPost("/auth/v1/oauth/token")]
    public async Task<IActionResult> Token()
    {
        if (!Request.Headers.TryGetValue("Authorization", out var authHeaders) || string.IsNullOrEmpty(authHeaders))
            return AuthenticationErrors.InvalidHeader.Apply(HttpContext);

        var tokenParts = authHeaders.ToString().Split(' ', 2);
        if (tokenParts.Length != 2 || !tokenParts[0].Equals("Basic", StringComparison.OrdinalIgnoreCase))
        {
            return AuthenticationErrors.OAuth.InvalidClient
                .WithMessage("Invalid authorization header format. Expected 'Basic <token>'.")
                .Apply(HttpContext);
        }

        Dictionary<string, string> body;
        try
        {
            var parsedBody = await _bodyParser.ParseAsync(Request);
            body = new Dictionary<string, string>(parsedBody);
        }
        catch
        {
            return AuthenticationErrors.InvalidRequest.Apply(HttpContext);
        }
        
        if (!body.TryGetValue("grant_type", out var grantType))
            return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);
        
        if (!body.TryGetValue("deployment_id", out var deploymentId))
            return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);


        switch (grantType)
        {
            case "client_credentials":
                return HandleClientCredentialsGrant(deploymentId);

            case "external_auth":
                if (!body.TryGetValue("external_auth_token", out var externalAuthToken))
                    return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);
                if (!body.TryGetValue("nonce", out var nonce))
                    return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);
                return await HandleExternalAuthGrant(deploymentId, externalAuthToken, nonce);

            default:
                Logger.Warn($"Unsuporrted grantType: {grantType}");
                return AuthenticationErrors.OAuth.UnsupportedGrant(grantType).Apply(HttpContext);
        }
    }

    private async Task<IActionResult> HandleExternalAuthGrant(string deploymentId, string externalAuthToken, string nonce)
    {
        const string prefix = "eg1~";
        if (externalAuthToken.StartsWith(prefix))
            externalAuthToken = externalAuthToken[prefix.Length..];

        externalAuthToken = externalAuthToken.Replace("eg1~", string.Empty);

        IDictionary<string, object> decodedToken;
        try
        {
            decodedToken = TokenGenerator.DecodeToken(externalAuthToken);
        }
        catch (Exception ex)
        {
            Logger.Error($"Token decoding failed: {ex.Message}");
            return AuthenticationErrors.InvalidToken("Malformed token structure")
                .Apply(HttpContext);
        }

        string accountId = decodedToken["sub"] as string;
        if (string.IsNullOrEmpty(accountId))
            return AuthenticationErrors.InvalidToken(externalAuthToken).WithMessage("Missing subject in token").Apply(HttpContext);

        var userRepository = Constants.repositoryPool.For<User>();

        var user = await userRepository.FindByColumnAsync("accountid", accountId);
        if (user == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);

        if (user.Banned)
            return AccountErrors.DisabledAccount.Apply(HttpContext);

        var access_token = "eg1~" + TokenGenerator.GenerateEosAccessToken(user.AccountId, user.Username);
        var id_token = "eg1~" + TokenGenerator.GenerateEosIdToken(user.AccountId, user.Username);

        return Ok(new
        {
            access_token,
            id_token,
            token_type = "bearer",
            expires_at = "9999-12-31T23:59:59.999Z",
            nonce,
            features = new[]
            {
                "Connect",
                "Ecom",
                "ExchangeCodeCreation"
            },
            organization_id = "o-aa83a0a9bc45e98c80c1b1c9d92e9e",
            product_id = "prod-fn",
            sandbox_id = "fn",
            deployment_id = deploymentId,
            organization_user_id = "000185f80b9a4dc3aaf1ca83611c2bf5",
            product_user_id = "00027b91959a4c57a1272efcc4d7480f",
            product_user_id_created = false,
            expires_in = 3599
        });
    }

    private IActionResult HandleClientCredentialsGrant(string deploymentId)
    {
        var accessToken = TokenGenerator.GenerateToken(Constants.config.JWTClientSecret,
            Constants.config.JWTClientSecret, deploymentId);
        var expiresAt = DateTime.UtcNow.AddMinutes(60);
        return Ok(new
        {
            access_token = $"eg1~{accessToken}",
            expires_in = 3600,
            expires_at = expiresAt.ToIsoUtcString(),
            token_type = "bearer",
            features = new List<string>
            {
                "AntiCheat",
                "Connect",
                "ContentService",
                "Ecom",
                "EpicConnect",
                "Inventories",
                "LockerService",
                "Matchmaking Service",
                "ExchangeCodeCreation",
                "Achievements",
                "Leaderboards",
                "Matchmaking",
                "Metrics",
                "PlayerReports",
                "Sanctions",
                "Stats",
                "TitleStorage",
                "Voice"
            },
            organization_id = "o-aa83a0a9bc45e98c80c1b1c9d92e9e",
            product_id = "prod-fn",
            sandbox_id = "fn",
            deployment_id = deploymentId
        });
    }

    [HttpPost("/epic/oauth/v2/token")]
    public async Task<IActionResult> CreateRefreshToken()
    {
        if (!Request.Headers.TryGetValue("Authorization", out var authHeaders) || string.IsNullOrEmpty(authHeaders))
            return AuthenticationErrors.InvalidHeader.Apply(HttpContext);

        var tokenParts = authHeaders.ToString().Split(' ', 2);
        if (tokenParts.Length != 2 || !tokenParts[0].Equals("Basic", StringComparison.OrdinalIgnoreCase))
        {
            return AuthenticationErrors.OAuth.InvalidClient
                .WithMessage("Invalid authorization header format. Expected 'Basic <token>'.")
                .Apply(HttpContext);
        }

        string decodedClientAuth;
        try
        {
            decodedClientAuth = Encoding.UTF8.GetString(Convert.FromBase64String(tokenParts[1]));
        }
        catch
        {
            return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);
        }

        int colonIndex = decodedClientAuth.IndexOf(':');
        if (colonIndex == -1)
            return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);

        string clientId = decodedClientAuth.Substring(0, colonIndex);
        
        Dictionary<string, string> body;
        try
        {
            var parsedBody = await _bodyParser.ParseAsync(Request);
            body = new Dictionary<string, string>(parsedBody);
        }
        catch
        {
            return AuthenticationErrors.InvalidRequest.Apply(HttpContext);
        }
        
        if (!body.TryGetValue("grant_type", out var grantType))
            return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);
        
        if (!body.TryGetValue("deployment_id", out var deploymentId))
            return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);
        
        if (!body.TryGetValue("refresh_token", out var refreshToken))
            return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);
        
        if (!body.TryGetValue("scope", out var scope))
            return AuthenticationErrors.OAuth.InvalidClient.Apply(HttpContext);
        if (string.IsNullOrEmpty(refreshToken) /* || !refreshToken.StartsWith("eg1~") */)
        {
            return AuthenticationErrors.InvalidToken(refreshToken)
                .WithMessage("Invalid token format")
                .Apply(HttpContext);
        }

        const string prefix = "eg1~";
        if (refreshToken.StartsWith(prefix))
            refreshToken = refreshToken[prefix.Length..];

        refreshToken = refreshToken.Replace("eg1~", string.Empty);

        IDictionary<string, object> decodedToken;
        try
        {
            decodedToken = TokenGenerator.DecodeToken(refreshToken);
        }
        catch (Exception ex)
        {
            Logger.Error($"Token decoding failed: {ex.Message}");
            return AuthenticationErrors.InvalidToken("Malformed token structure")
                .Apply(HttpContext);
        }

        string accountId = decodedToken["sub"] as string;
        if (string.IsNullOrEmpty(accountId))
            return AuthenticationErrors.InvalidToken(refreshToken).WithMessage("Missing subject in token").Apply(HttpContext);

        var userRepository = Constants.repositoryPool.For<User>();

        var user = await userRepository.FindByColumnAsync("accountid", accountId);
        if (user == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);

        if (user.Banned)
            return AccountErrors.DisabledAccount.Apply(HttpContext);
        
        var now = DateTime.UtcNow;

        var access_token = "eg1~" + TokenGenerator.GenerateEosAccessToken(user.AccountId, user.Username);
        var id_token = "eg1~" + TokenGenerator.GenerateEosIdToken(user.AccountId, user.Username);
        var refresh_token = TokenGenerator.GenerateEosRefreshToken(user.AccountId, user.Username);
        
        return Ok(new
        {
            access_token,
            refresh_token,
            id_token,
            scope,
            token_type = "bearer",
            expires_in = AccessTokenLifetimeHours * 60 * 60,
            expires_at = now.AddHours(AccessTokenLifetimeHours).ToIsoUtcString(),
            refresh_expires = RefreshTokenLifetimeDays * 86400,
            refresh_expires_at = now.AddDays(RefreshTokenLifetimeDays).ToIsoUtcString(),
            account_id = user.AccountId,
            client_id = clientId,
            application_id = Guid.NewGuid().ToString().Replace("-", ""),
            selected_account_id = user.AccountId,
            merged_accounts = new List<object>(),
            acr = "AAL1",
            auth_time = DateTime.UtcNow.ToIsoUtcString()
        });
    }

    [HttpGet("/epic/id/v2/sdk/accounts")]
    public async Task<IActionResult> GetSdkAccounts([FromQuery] string accountId)
    {
        Logger.Debug(accountId);
        var userRepository = Constants.repositoryPool.For<User>();

        var user = await userRepository.FindByColumnAsync("accountid", accountId);
        if (user == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);

        if (user.Banned)
            return AccountErrors.DisabledAccount.Apply(HttpContext);

        return Ok(new[]
        {
            new {
                accountId = user.AccountId,
                displayName = user.Username,
                preferredLanguage = "en",
                linkedAccounts = new List<object>(),
                cabinedMode = false,
                empty = false
            }
        });
    }

    [HttpPost("/epic/oauth/v2/revoke")]
    public IActionResult Revoke()
    {
        return NoContent();
    }

    [HttpPost("/epic/oauth/v2/tokenInfo")]
    public async Task<IActionResult> TokenInfo()
    {
        if (!Request.Headers.TryGetValue("Authorization", out var authHeaders) || string.IsNullOrEmpty(authHeaders))
            return AuthenticationErrors.InvalidHeader.Apply(HttpContext);

        const string bearerPrefix = "Bearer ";
        string authHeader = authHeaders.ToString();

        if (!authHeader.StartsWith(bearerPrefix, StringComparison.OrdinalIgnoreCase))
            return AuthenticationErrors.InvalidHeader.Apply(HttpContext);

        string token = authHeader[bearerPrefix.Length..].Trim();

        //if (!token.StartsWith("eg1~", StringComparison.OrdinalIgnoreCase))
        //    return AuthenticationErrors.InvalidToken(token).WithMessage("Missing expected token prefix").Apply(HttpContext);

        string accessToken = token["eg1~".Length..];

        if (string.IsNullOrEmpty(accessToken))
            return AuthenticationErrors.InvalidToken(token).WithMessage("Invalid Token").Apply(HttpContext);

        var decodedToken = TokenGenerator.DecodeToken(accessToken);
        if (decodedToken == null)
            return AuthenticationErrors.InvalidToken("Failed to decode token").Apply(HttpContext);

        string accountId = decodedToken["sub"] as string;
        if (string.IsNullOrEmpty(accountId))
            return AuthenticationErrors.InvalidToken(token).WithMessage("Missing subject in token").Apply(HttpContext);

        var userRepository = Constants.repositoryPool.For<User>();

        var user = await userRepository.FindByColumnAsync("accountid", accountId);
        if (user == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);

        if (user.Banned)
            return AccountErrors.DisabledAccount.Apply(HttpContext);

        return Ok(new
        {
            active = true,
            scope = "basic_profile openid offline_access",
            token_type = "bearer",
            expires_in = AccessTokenLifetimeHours * 90 * 90,
            expires_at = "9999-12-31T23:59:59.999Z",
            account_id = user.AccountId,
            client_id = "ec684b8c687f479fadea3cb2ad83f5c6",
            application_id = Guid.NewGuid().ToString().Replace("-", ""),
        });
    }

    [HttpGet("/epic/friends/v1/{accountId}/blocklist")]
    public async Task<IActionResult> GetFriendsBlocklist(string accountId)
    {
        return Ok(Array.Empty<object>());
    }
}