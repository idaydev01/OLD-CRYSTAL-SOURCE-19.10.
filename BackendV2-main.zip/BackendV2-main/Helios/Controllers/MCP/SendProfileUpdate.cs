using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Managers;
using Helios.Managers.Helpers;
using Helios.Utilities;
using Helios.Utilities.Dtos;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace Helios.Controllers.MCP;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/SendProfileUpdate")]
public class SendProfileUpdate : ControllerBase
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = false
    };

    [HttpPost]
    public async Task<IActionResult> Init([FromRoute] string accountId)
    {
        if (string.IsNullOrWhiteSpace(accountId))
            return MCPErrors.InvalidPayload.Apply(HttpContext);

        try
        {
            var userRepository = Constants.repositoryPool.For<User>();
            var profilesRepository = Constants.repositoryPool.For<Profiles>();
            var profileItemsRepository = Constants.repositoryPool.For<Items>();

            var userTask = userRepository.FindByColumnAsync("accountid", accountId);
            var profileTask = profilesRepository.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "profileid", "common_core" },
                { "accountid", accountId }
            });
            var athenaTask = profilesRepository.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "profileid", "athena" },
                { "accountid", accountId }
            });

            await Task.WhenAll(userTask, profileTask, athenaTask);

            var user = userTask.Result;
            var profile = profileTask.Result;
            var athena = athenaTask.Result;

            if (user == null)
                return AccountErrors.AccountNotFound(accountId)
                    .WithMessage($"User with id {accountId} not found")
                    .Apply(HttpContext);

            if (profile == null)
                return MCPErrors.ProfileNotFound("common_core").Apply(HttpContext);

            if (athena == null)
                return MCPErrors.ProfileNotFound("athena").Apply(HttpContext);

            profile.Revision++;
            athena.Revision++;

            var updateTask = Task.WhenAll(
                ProfileManager.UpdateProfileAsync(profile),
                ProfileManager.UpdateProfileAsync(athena)
            );

            var payload = new
            {
                type = "com.epicgames.gift.received",
                payload = new { },
                timestamp = DateTime.UtcNow.ToIsoUtcString(),
            };

            string jsonContent = JsonSerializer.Serialize(payload, JsonOptions);
            var xmppTask = Constants.GlobalXmppClientService.SendEmptyGiftAsync(accountId, jsonContent);
            var profileItemsTask = profileItemsRepository.FindAllAsync(new Items
            {
                AccountId = accountId,
                ProfileId = "common_core",
            }, useCache: false);

            await Task.WhenAll(updateTask, xmppTask, profileItemsTask);

            var profileItems = profileItemsTask.Result;
            var finalProfile = new ProfileBuilder(accountId, profile, user, profileItems.ToList());

            var profileChanges = new List<object>(1)
            {
                ProfileChangeDto.FullUpdate(finalProfile)
            };

            return Ok(ProfileResponseManager.Generate(profile, profileChanges, "common_core"));
        }
        catch (Exception ex)
        {
           return InternalErrors.ServerError
                .WithMessage($"An error occurred while processing the request: {ex.Message}")
                .Apply(HttpContext);
        }
    }
}