﻿using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace Helios.Controllers.MCP;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/DeleteCosmeticLoadout")]
public class DeleteCosmeticLoadout : ControllerBase
{
    private static readonly JsonDocumentOptions JsonOptions = new() { AllowTrailingCommas = true };

    [HttpPost]
    [VerifyToken]
    public async Task<IActionResult> Init([FromRoute] string accountId, [FromQuery] string profileId)
    {
        try
        {
            if (string.IsNullOrEmpty(profileId) || string.IsNullOrEmpty(accountId))
                return MCPErrors.InvalidPayload.Apply(HttpContext);

            var userRepository = Constants.repositoryPool.For<User>();
            var profilesRepository = Constants.repositoryPool.For<Profiles>();
            var userTask = userRepository.FindAsync(new User { AccountId = accountId });
            var profileTask = profilesRepository.FindAsync(new Profiles { ProfileId = profileId, AccountId = accountId });

            JsonDocument json;
            try
            {
                using var memoryStream = new MemoryStream();
                await Request.Body.CopyToAsync(memoryStream);
                memoryStream.Position = 0;
                json = JsonDocument.Parse(memoryStream, JsonOptions);
            }
            catch (JsonException)
            {
                return MCPErrors.InvalidPayload.Apply(HttpContext);
            }

            var root = json.RootElement;

            if (!root.TryGetProperty("index", out var indexProperty) ||
                !root.TryGetProperty("fallbackLoadoutIndex", out var fallbackLoadoutIndexProperty) ||
                !root.TryGetProperty("leaveNullSlot", out var leaveNullSlotProperty))
                return MCPErrors.InvalidPayload.Apply(HttpContext);

            int loadoutIndex = indexProperty.GetInt32();
            int fallbackLoadoutIndex = fallbackLoadoutIndexProperty.GetInt32();
            bool leaveNullSlot = leaveNullSlotProperty.GetBoolean();

            var user = await userTask;
            var profile = await profileTask;

            if (user is null || profile is null)
                return AccountErrors.AccountNotFound(accountId).Apply(HttpContext);

            var profileItemsRepository = Constants.repositoryPool.For<Items>();
            var loadouts = await profileItemsRepository.FindAsync(new Items
            {
                ProfileId = profileId,
                AccountId = accountId,
                TemplateId = "loadouts"
            });

            var profileChanges = new List<object>();
            var updateTasks = new List<Task>();
            bool hasChanges = false;

            if (loadouts?.Value != null)
            {
                var loadoutsList = JsonSerializer.Deserialize<List<string>>(loadouts.Value.ToString());

                if (loadoutsList?.Count > 0 && loadoutIndex >= 0 && loadoutIndex < loadoutsList.Count)
                {
                    var targetLoadoutId = loadoutsList[loadoutIndex];

                    var lockerItem = await profileItemsRepository.FindAsync(new Items
                    {
                        ProfileId = profileId,
                        AccountId = accountId,
                        TemplateId = targetLoadoutId
                    });

                    if (lockerItem?.Value != null)
                    {
                        var lockerItemNode = JsonNode.Parse(lockerItem.Value.ToString());

                        if (lockerItemNode != null)
                        {
                            loadoutsList.RemoveAt(loadoutIndex);
                            lockerItem.Value = JsonSerializer.Serialize(lockerItemNode.ToJsonString());
                            loadouts.Value = JsonSerializer.Serialize(loadoutsList);


                            updateTasks.Add(profileItemsRepository.DeleteAsync(lockerItem));
                            updateTasks.Add(profileItemsRepository.UpdateAsync(loadouts));

                            profileChanges.Add(new
                            {
                                changeType = "itemRemoved",
                                itemId = targetLoadoutId
                            });

                            profileChanges.Add(new
                            {
                                changeType = "statModified",
                                name = "loadouts",
                                value = loadoutsList
                            });

                            hasChanges = true;
                        }
                    }
                }
            }

            if (hasChanges)
            {
                profile.Revision++;
                updateTasks.Add(ProfileManager.UpdateProfileAsync(profile));
                await Task.WhenAll(updateTasks);
            }

            return Ok(ProfileResponseManager.Generate(profile, profileChanges, profileId));
        }
        catch (Exception ex)
        {
            Logger.Error($"An error occurred in DeleteCosmeticLoadout: {ex.Message}", ex);
            return InternalErrors.ServerError
                .WithMessage($"An error occurred while processing the request: {ex.Message}")
                .Apply(HttpContext);
        }
    }
}