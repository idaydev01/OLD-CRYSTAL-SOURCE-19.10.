﻿using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace Helios.Controllers.MCP;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/CopyCosmeticLoadout")]
public class CopyCosmeticLoadout : ControllerBase
{
    private static readonly JsonDocumentOptions JsonOptions = new() { AllowTrailingCommas = true };

    [HttpPost]
    [VerifyToken]
    public async Task<IActionResult> Init([FromRoute] string accountId, [FromQuery] string profileId)
    {
        try
        {
            if (string.IsNullOrEmpty(profileId) || string.IsNullOrEmpty(accountId))
                return MCPErrors.InvalidPayload.Apply(HttpContext);

            var userRepository = Constants.repositoryPool.For<User>();
            var profilesRepository = Constants.repositoryPool.For<Profiles>();
            var userTask = userRepository.FindAsync(new User { AccountId = accountId });
            var profileTask = profilesRepository.FindAsync(new Profiles { ProfileId = profileId, AccountId = accountId });

            JsonDocument json;
            try
            {
                using var memoryStream = new MemoryStream();
                await Request.Body.CopyToAsync(memoryStream);
                memoryStream.Position = 0;
                json = JsonDocument.Parse(memoryStream, JsonOptions);
            }
            catch (JsonException)
            {
                return MCPErrors.InvalidPayload.Apply(HttpContext);
            }

            var root = json.RootElement;

            if (!root.TryGetProperty("optNewNameForTarget", out var optNewNameForTarget) ||
                !root.TryGetProperty("sourceIndex", out var sourceIndexProperty) ||
                !root.TryGetProperty("targetIndex", out var targetIndexProperty))
                return MCPErrors.InvalidPayload.Apply(HttpContext);

            int sourceIndex = sourceIndexProperty.GetInt32();
            int targetIndex = targetIndexProperty.GetInt32();

            var user = await userTask;
            var profile = await profileTask;

            if (user is null || profile is null)
                return AccountErrors.AccountNotFound(accountId).Apply(HttpContext);

            var profileItemsRepository = Constants.repositoryPool.For<Items>();
            var loadouts = await profileItemsRepository.FindAsync(new Items
            {
                ProfileId = profileId,
                AccountId = accountId,
                TemplateId = "loadouts"
            });

            var profileChanges = new List<object>();
            var updateTasks = new List<Task>();
            bool hasChanges = false;

            if (loadouts?.Value != null)
            {
                var loadoutsList = JsonSerializer.Deserialize<List<string>>(loadouts.Value.ToString());

                if (loadoutsList?.Count > 0)
                {
                    var defaultLoadout = await profileItemsRepository.FindAsync(new Items
                    {
                        ProfileId = profileId,
                        AccountId = accountId,
                        TemplateId = loadoutsList[0]
                    });

                    if (defaultLoadout?.Value != null)
                    {
                        var defaultLockerNode = JsonNode.Parse(defaultLoadout.Value.ToString());

                        if (sourceIndex == 0)
                        {
                            var newName = $"fortniteloadout{targetIndex + 1}";

                            if (loadoutsList.Contains(newName))
                            {
                                var presetLoadout = await profileItemsRepository.FindAsync(new Items
                                {
                                    ProfileId = profileId,
                                    AccountId = accountId,
                                    TemplateId = newName
                                });

                                if (presetLoadout?.Value != null)
                                {
                                    var presetLockerNode = JsonNode.Parse(presetLoadout.Value.ToString());

                                    if (presetLockerNode?["locker_name"] != null && defaultLockerNode?["locker_name"] != null)
                                    {
                                        defaultLockerNode["locker_name"] = presetLockerNode["locker_name"]?.ToString();
                                        presetLoadout.Value = defaultLockerNode.ToJsonString();
                                        updateTasks.Add(profileItemsRepository.UpdateAsync(presetLoadout));

                                        profileChanges.Add(new
                                        {
                                            changeType = "itemAttrChanged",
                                            itemId = newName,
                                            attributeName = "locker_slots_data",
                                            attributeValue = defaultLockerNode["locker_slots_data"]
                                        });
                                        hasChanges = true;
                                    }
                                }
                            }
                            else
                            {
                                if (defaultLockerNode?["locker_name"] != null)
                                {
                                    var newLoadoutName = string.IsNullOrEmpty(optNewNameForTarget.GetString())
                                        ? $"Saved Loadout {loadoutsList.Count}"
                                        : optNewNameForTarget.GetString();

                                    defaultLockerNode["locker_name"] = newLoadoutName;
                                    defaultLockerNode["item_seen"] = true;

                                    await profileItemsRepository.SaveAsync(new Items
                                    {
                                        ProfileId = profileId,
                                        AccountId = accountId,
                                        Value = defaultLockerNode.ToJsonString(),
                                        TemplateId = newName,
                                        IsAttribute = false,
                                        Quantity = 1
                                    });

                                    loadoutsList.Add(newName);
                                    loadouts.Value = JsonSerializer.Serialize(loadoutsList);
                                    updateTasks.Add(profileItemsRepository.UpdateAsync(loadouts));

                                    profileChanges.Add(new
                                    {
                                        changeType = "statModified",
                                        name = "loadouts",
                                        value = loadoutsList
                                    });

                                    profileChanges.Add(new
                                    {
                                        changeType = "itemAdded",
                                        itemId = newName,
                                        item = new
                                        {
                                            templateId = "CosmeticLocker:cosmeticlocker_athena",
                                            attributes = defaultLockerNode,
                                            quantity = 1
                                        }
                                    });
                                    hasChanges = true;
                                }
                            }
                        }
                        else if (sourceIndex < loadoutsList.Count)
                        {
                            var presetLoadout = await profileItemsRepository.FindAsync(new Items
                            {
                                ProfileId = profileId,
                                AccountId = accountId,
                                TemplateId = loadoutsList[sourceIndex]
                            });

                            if (presetLoadout?.Value != null)
                            {
                                var presetLockerNode = JsonNode.Parse(presetLoadout.Value.ToString());

                                if (presetLockerNode?["locker_name"] != null && defaultLockerNode?["locker_name"] != null)
                                {
                                    presetLockerNode["locker_name"] = defaultLockerNode["locker_name"]?.ToString();
                                    defaultLoadout.Value = presetLockerNode.ToJsonString();
                                    updateTasks.Add(profileItemsRepository.UpdateAsync(defaultLoadout));

                                    profileChanges.Add(new
                                    {
                                        changeType = "itemAttrChanged",
                                        itemId = loadoutsList[0],
                                        attributeName = "locker_slots_data",
                                        attributeValue = presetLockerNode["locker_slots_data"]
                                    });
                                    hasChanges = true;
                                }
                            }
                        }
                    }
                }
            }

            if (hasChanges)
            {
                profile.Revision++;
                updateTasks.Add(ProfileManager.UpdateProfileAsync(profile));
                await Task.WhenAll(updateTasks);
            }

            return Ok(ProfileResponseManager.Generate(profile, profileChanges, profileId));
        }
        catch (Exception ex)
        {
            Logger.Error($"An error occurred in CopyCosmeticLoadout: {ex.Message}", ex);
            return InternalErrors.ServerError
                .WithMessage($"An error occurred while processing the request: {ex.Message}")
                .Apply(HttpContext);
        }
    }
}