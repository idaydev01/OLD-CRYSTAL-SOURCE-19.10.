﻿using System.Text.Json;
using System.Buffers;
using Helios.Classes.MCP;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Managers;
using Helios.Managers.Helpers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using JsonException = System.Text.Json.JsonException;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace Helios.Controllers.MCP;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/SetCosmeticLockerSlot")]
public class SetCosmeticLockerSlot : ControllerBase
{
    private static readonly Dictionary<string, Action<Loadouts, string>> CategoryPropertyMap = new(9)
    {
        { "CharacterId", (loadout, item) => loadout.CharacterId = item },
        { "BackpackId", (loadout, item) => loadout.BackpackId = item },
        { "PickaxeId", (loadout, item) => loadout.PickaxeId = item },
        { "GliderId", (loadout, item) => loadout.GliderId = item },
        { "ContrailId", (loadout, item) => loadout.ContrailId = item },
        { "LoadingScreenId", (loadout, item) => loadout.LoadingScreenId = item },
        { "MusicPackId", (loadout, item) => loadout.MusicPackId = item },
        { "BannerId", (loadout, item) => loadout.BannerId = item },
        { "BannerColorId", (loadout, item) => loadout.BannerColorId = item }
    };

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    [HttpPost]
    [VerifyToken]
    public async Task<IActionResult> Init(
        [FromRoute] string accountId,
        [FromQuery] string profileId,
        [FromHeader(Name = "User-Agent")] string userAgent)
    {
        if (userAgent is null)
            return InternalErrors.InvalidUserAgent.Apply(HttpContext);

        if (string.IsNullOrEmpty(profileId) || string.IsNullOrEmpty(accountId))
            return MCPErrors.InvalidPayload.Apply(HttpContext);

        var bodyResult = await ParseRequestBodyAsync();
        if (!bodyResult.Success)
            return MCPErrors.InvalidPayload.Apply(HttpContext);

        var root = bodyResult.JsonElement;

        if (!root.TryGetProperty("itemToSlot", out var itemToSlotProperty) ||
            !root.TryGetProperty("category", out var categoryProperty) ||
            !root.TryGetProperty("slotIndex", out var slotIndexProperty) ||
            !root.TryGetProperty("lockerItem", out var lockerItemProperty))
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        string category = categoryProperty.GetString();
        string lockerItem = lockerItemProperty.GetString();
        string itemToSlot = itemToSlotProperty.GetString();

        if (itemToSlot?.StartsWith("item:") == true)
            itemToSlot = itemToSlot.AsSpan(5).ToString();

        int slotIndex = slotIndexProperty.GetInt32();

        var userRepository = Constants.repositoryPool.For<User>();
        var profilesRepository = Constants.repositoryPool.For<Profiles>();
        var profileItemsRepository = Constants.repositoryPool.For<Items>();
        var loadoutsRepository = Constants.repositoryPool.For<Loadouts>();

        var userTask = userRepository.FindAsync(new User { AccountId = accountId });
        var profileTask = profilesRepository.FindAsync(new Profiles { ProfileId = profileId, AccountId = accountId });

        var loadoutTask = loadoutsRepository.FindAsync(new Loadouts { AccountId = accountId, ProfileId = profileId, LockerName = lockerItem });

        Task<Items> itemTask = null;
        Task<Items> actualItemTask = null;

        if (!string.IsNullOrEmpty(lockerItem))
        {
            itemTask = profileItemsRepository.FindAsync(new Items
            {
                ProfileId = profileId,
                AccountId = accountId,
                TemplateId = lockerItem
            });
        }

        if (!string.IsNullOrEmpty(itemToSlot) && !itemToSlot.Contains("_random"))
        {
            actualItemTask = profileItemsRepository.FindAsync(new Items
            {
                ProfileId = profileId,
                AccountId = accountId,
                TemplateId = itemToSlot
            });
        }

        var tasks = new List<Task>(5);
        tasks.Add(userTask);
        tasks.Add(profileTask);
        tasks.Add(loadoutTask);
        if (itemTask != null) tasks.Add(itemTask);
        if (actualItemTask != null) tasks.Add(actualItemTask);

        await Task.WhenAll(tasks);

        var user = await userTask;
        var profile = await profileTask;
        var loadout = await loadoutTask;

        if (user is null || profile is null || loadout is null)
            return AccountErrors.AccountNotFound(accountId).Apply(HttpContext);

        var item = itemTask != null ? await itemTask : null;
        var actualItem = actualItemTask != null ? await actualItemTask : null;

        if (item == null && (string.IsNullOrEmpty(itemToSlot) || itemToSlot.Contains("_random")))
        {
            return await HandleRandomItemAsync(accountId, profileId, category, slotIndex, itemToSlot, profile, profileItemsRepository);
        }

        if (item == null)
            return MCPErrors.ItemNotFound.WithMessage("Item not found.").Apply(HttpContext);

        var locker = JsonConvert.DeserializeObject<LoadoutDefinition>(item.Value);
        var lockerSlotsData = locker.locker_slots_data;

        if (!lockerSlotsData.slots.ContainsKey(category))
            return MCPErrors.ItemNotFound.WithMessage($"Category {category} not found.").Apply(HttpContext);

        var categoryInDb = LoadoutsBuilder.GetDatabaseId(category);
        bool updated = false;

        if (CategoryPropertyMap.TryGetValue(categoryInDb, out var updateAction))
        {
            lockerSlotsData.slots[category].items = new List<string>(1) { itemToSlot };
            updateAction(loadout, itemToSlot);
            updated = true;
        }
        else if (categoryInDb == "DanceId")
        {
            updated = UpdateArrayBasedCategory(loadout, lockerSlotsData, category, itemToSlot, slotIndex, loadout.DanceId, 6);
        }
        else if (categoryInDb == "ItemWrapId")
        {
            updated = UpdateArrayBasedCategory(loadout, lockerSlotsData, category, itemToSlot, slotIndex, loadout.ItemWrapId, 7);
        }

        if (!updated)
            return MCPErrors.ItemNotFound.WithMessage($"Unknown category {category}.").Apply(HttpContext);

        List<object> profileChanges = new List<object>();

        if (root.TryGetProperty("variantUpdates", out JsonElement variantUpdatesElement) &&
            variantUpdatesElement.ValueKind == JsonValueKind.Array &&
            variantUpdatesElement.GetArrayLength() > 0 &&
            actualItem != null && !string.IsNullOrEmpty(actualItem.Value))
        {
            try
            {
                var originalValue = actualItem.Value;

                var itemValueDict = JsonConvert.DeserializeObject<Dictionary<string, object>>(actualItem.Value);
                if (itemValueDict == null)
                {
                    Logger.Warn($"Failed to deserialize item value for {itemToSlot}, skipping variant updates");
                    goto SkipVariantUpdates;
                }

                var existingVariants = new List<Dictionary<string, object>>();

                if (itemValueDict.TryGetValue("variants", out var existingVariantsObj) && existingVariantsObj != null)
                {
                    try
                    {
                        var existingVariantsJson = JsonConvert.SerializeObject(existingVariantsObj);
                        var deserializedVariants = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(existingVariantsJson);
                        if (deserializedVariants != null)
                        {
                            existingVariants = deserializedVariants;
                        }
                    }
                    catch
                    {
                        Logger.Warn($"Failed to deserialize existing variants for {itemToSlot}, starting with empty variants");
                    }
                }

                bool variantsChanged = false;

                foreach (var variantUpdate in variantUpdatesElement.EnumerateArray())
                {
                    if (!variantUpdate.TryGetProperty("channel", out var channelElement) ||
                        !variantUpdate.TryGetProperty("active", out var activeElement) ||
                        channelElement.ValueKind == JsonValueKind.Null ||
                        activeElement.ValueKind == JsonValueKind.Null)
                        continue;

                    string channel = channelElement.GetString();
                    string active = activeElement.GetString();

                    if (string.IsNullOrEmpty(channel) || string.IsNullOrEmpty(active))
                        continue;

                    var existingIndex = existingVariants.FindIndex(v =>
                        v.TryGetValue("channel", out var ch) && ch?.ToString() == channel);

                    if (existingIndex != -1)
                    {
                        var existingVariant = existingVariants[existingIndex];
                        var oldActive = existingVariant.TryGetValue("active", out var oldActiveVal) ? oldActiveVal?.ToString() : "unknown";

                        var updatedVariant = new Dictionary<string, object>();
                        foreach (var kvp in existingVariant)
                        {
                            updatedVariant[kvp.Key] = kvp.Value;
                        }

                        updatedVariant["active"] = active;
                        existingVariants[existingIndex] = updatedVariant;

                        variantsChanged = true;
                    }
                    else
                    {
                        var newVariant = new Dictionary<string, object>
                        {
                            ["channel"] = channel,
                            ["active"] = active
                        };

                        if (variantUpdate.TryGetProperty("owned", out var ownedElement) &&
                            ownedElement.ValueKind != JsonValueKind.Null)
                        {
                            if (ownedElement.ValueKind == JsonValueKind.Array)
                                newVariant["owned"] = ownedElement.EnumerateArray().Select(x => x.GetString()).ToList();
                            else
                                newVariant["owned"] = ownedElement.GetString();
                        }

                        existingVariants.Add(newVariant);
                        variantsChanged = true;
                    }
                }

                if (variantsChanged)
                {
                    var updatedItemValue = new Dictionary<string, object>(itemValueDict);
                    updatedItemValue["variants"] = existingVariants;

                    var newValue = JsonConvert.SerializeObject(updatedItemValue);

                    try
                    {
                        var testDeserialize = JsonConvert.DeserializeObject<Dictionary<string, object>>(newValue);
                        if (testDeserialize != null && testDeserialize.ContainsKey("variants"))
                        {
                            actualItem.Value = newValue;
                            await profileItemsRepository.UpdateAsync(actualItem);

                            profileChanges.Add(new
                            {
                                changeType = "itemAttrChanged",
                                itemId = itemToSlot,
                                attributeName = "variants",
                                attributeValue = existingVariants
                            });
                        }
                        else
                        {
                            actualItem.Value = originalValue;
                        }
                    }
                    catch (Exception verifyEx)
                    {
                        Logger.Error($"Serialization verification failed for item {itemToSlot}: {verifyEx.Message}, reverting to original value");
                        actualItem.Value = originalValue;
                    }
                }
                else
                {
                    Logger.Info($"No variant changes needed for item {itemToSlot}");
                }
            }
            catch (JsonException ex)
            {
                Logger.Error($"JSON Error processing variants for item {itemToSlot}: {ex.Message}");
            }
            catch (Exception ex)
            {
                Logger.Error($"Unexpected error processing variants for item {itemToSlot}: {ex.Message}");
            }
        }

    SkipVariantUpdates:

        profileChanges.Add(new
        {
            changeType = "itemAttrChanged",
            itemId = lockerItem,
            attributeName = "locker_slots_data",
            attributeValue = lockerSlotsData
        });

        item.Value = JsonConvert.SerializeObject(locker);

        var updateTasks = new List<Task>
        {
            loadoutsRepository.UpdateAsync(loadout),
            profileItemsRepository.UpdateAsync(item)
        };

        profile.Revision++;
        updateTasks.Add(ProfileManager.UpdateProfileAsync(profile));

        await Task.WhenAll(updateTasks);

        return Ok(ProfileResponseManager.Generate(profile, profileChanges, profileId));
    }

    private async Task<IActionResult> HandleRandomItemAsync(
        string accountId,
        string profileId,
        string category,
        int slotIndex,
        string itemToSlot,
        Profiles profile,
        Repository<Items> profileItemsRepository)
    {
        var randomLoadoutData = new LoadoutDefinition
        {
            locker_slots_data = new LockerSlotData
            {
                slots = new Dictionary<string, LockerSlot>
                {
                    [category] = new LockerSlot { items = new List<string> { itemToSlot } }
                }
            }
        };

        var item = new Items
        {
            AccountId = accountId,
            ProfileId = "athena",
            TemplateId = itemToSlot,
            Value = JsonConvert.SerializeObject(randomLoadoutData)
        };

        await profileItemsRepository.UpdateAsync(item).ConfigureAwait(false);

        profile.Revision++;
        await ProfileManager.UpdateProfileAsync(profile).ConfigureAwait(false);

        var response = ProfileResponseManager.Generate(profile, new List<object>
        {
            new {
                changeType = "item_updated",
                item = itemToSlot,
                category,
                slotIndex,
                loadout = randomLoadoutData
            }
        }, profileId);

        return Ok(response);
    }

    private bool UpdateArrayBasedCategory(Loadouts loadout, LockerSlotData lockerSlotsData,
        string category, string itemToSlot, int slotIndex, string[] itemArray, int arraySize)
    {
        if (itemArray == null)
            itemArray = new string[arraySize];

        if (slotIndex == -1)
        {
            Array.Fill(itemArray, itemToSlot);
        }
        else if (slotIndex >= 0 && slotIndex < arraySize)
        {
            itemArray[slotIndex] = itemToSlot;
        }
        else
        {
            return false;
        }

        lockerSlotsData.slots[category].items = new List<string>(itemArray);
        return true;
    }

    private async Task<(bool Success, JsonElement JsonElement)> ParseRequestBodyAsync()
    {
        try
        {
            var reader = Request.BodyReader;
            var result = await reader.ReadAsync();
            var buffer = result.Buffer;

            if (buffer.IsEmpty)
                return (false, default);

            var json = JsonDocument.Parse(buffer);
            reader.AdvanceTo(buffer.End);
            return (true, json.RootElement);
        }
        catch (JsonException)
        {
            return (false, default);
        }
    }
}