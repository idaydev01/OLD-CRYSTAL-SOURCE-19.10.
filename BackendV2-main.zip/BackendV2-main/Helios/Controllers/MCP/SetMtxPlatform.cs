﻿using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Managers;
using Helios.Managers.Helpers;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Collections.Concurrent;

namespace Helios.Controllers.MCP;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/SetMtxPlatform")]
public class SetMtxPlatform : ControllerBase
{
    private static readonly JsonDocumentOptions JsonOptions = new() { AllowTrailingCommas = true };

    [HttpPost]
    [VerifyToken]
    public async Task<IActionResult> Init([FromRoute] string accountId, [FromQuery] string profileId)
    {
        var userRepository = Constants.repositoryPool.For<User>();
        var profilesRepository = Constants.repositoryPool.For<Profiles>();

        JsonDocument json;
        if (Request.ContentLength.HasValue && Request.ContentLength.Value <= 1024)
        {
            byte[] buffer = new byte[(int)Request.ContentLength.Value];
            int bytesRead = await Request.Body.ReadAsync(buffer);
            json = JsonDocument.Parse(buffer.AsMemory(0, bytesRead), JsonOptions);
        }
        else if (Request.ContentLength.HasValue && Request.ContentLength.Value < 4096)
        {
            byte[] buffer = System.Buffers.ArrayPool<byte>.Shared.Rent((int)Request.ContentLength.Value);
            try
            {
                int bytesRead = await Request.Body.ReadAsync(buffer, 0, (int)Request.ContentLength.Value);
                json = JsonDocument.Parse(buffer.AsMemory(0, bytesRead), JsonOptions);
            }
            finally
            {
                System.Buffers.ArrayPool<byte>.Shared.Return(buffer);
            }
        }
        else
        {
            using var memoryStream = new MemoryStream();
            await Request.Body.CopyToAsync(memoryStream);
            memoryStream.Position = 0;
            json = JsonDocument.Parse(memoryStream, JsonOptions);
        }

        if (!json.RootElement.TryGetProperty("newPlatform", out var newPlatformProperty))
            return MCPErrors.InvalidPayload.Apply(HttpContext);

        var newPlatform = newPlatformProperty.GetString() ?? "EpicPC";

        var userTask = userRepository.FindAsync(new User { AccountId = accountId });
        var profileTask = profilesRepository.FindAsync(new Profiles { ProfileId = profileId, AccountId = accountId });

        await Task.WhenAll(userTask, profileTask);

        var user = await userTask;
        var profile = await profileTask;

        if (user == null)
        {
            return AccountErrors.AccountNotFound(accountId)
                .WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);
        }

        if (profile == null && profileId == "common_public")
        {
            var defaultResponse = ProfileResponseManager.Generate(new Profiles
            {
                AccountId = accountId,
                ProfileId = "common_public",
                Revision = 0
            }, new List<object> { new DefaultProfileResponse(profileId, accountId) }, "common_public");

            return Ok(defaultResponse);
        }

        var profileItemsRepository = Constants.repositoryPool.For<Items>();
        var profileItems = await profileItemsRepository.FindAllAsync(new Items
        {
            AccountId = accountId,
            ProfileId = profileId,
        }, useCache: false);

        var itemsList = profileItems.ToList();
        var profileChanges = new ConcurrentBag<object>();

        if (itemsList.Count > 0)
        {
            var batchSize = Math.Min(50, itemsList.Count);
            var batches = itemsList.Chunk(batchSize);

            var batchTasks = batches.Select(async batch =>
            {
                var tasks = batch.Select(async item =>
                {
                    if (!string.IsNullOrEmpty(item.Value) && item.Value != "{}")
                    {
                        using var doc = JsonDocument.Parse(item.Value);
                        using var stream = new MemoryStream();
                        using var writer = new Utf8JsonWriter(stream);

                        writer.WriteStartObject();
                        foreach (var prop in doc.RootElement.EnumerateObject())
                        {
                            if (prop.Name == "platform")
                                writer.WriteString("platform", newPlatform);
                            else
                                prop.WriteTo(writer);
                        }
                        if (!doc.RootElement.TryGetProperty("platform", out _))
                            writer.WriteString("platform", newPlatform);
                        writer.WriteEndObject();
                        writer.Flush();

                        item.Value = System.Text.Encoding.UTF8.GetString(stream.ToArray());
                    }
                    else
                    {
                        item.Value = $"{{\"platform\":\"{newPlatform}\"}}";
                    }

                    if (item.IsAttribute && item.TemplateId == "current_mtx_platform")
                    {
                        item.Value = newPlatform;
                    }

                    profileChanges.Add(new
                    {
                        changeType = "statModified",
                        name = item.TemplateId,
                        value = newPlatform
                    });

                    await profileItemsRepository.UpdateAsync(item);
                });

                await Task.WhenAll(tasks);
            });

            await Task.WhenAll(batchTasks);
        }

        return Ok(ProfileResponseManager.Generate(profile, profileChanges, profileId));
    }
}