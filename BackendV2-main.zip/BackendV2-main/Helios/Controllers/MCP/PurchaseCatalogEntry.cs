using Discord;
using Helios.Classes.MCP;
using Helios.Classes.Storefront;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Managers;
using Helios.Managers.Helpers;
using Helios.Utilities;
using Helios.Utilities.Dtos;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Middleware.Attributes;
using Jose;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Buffers;
using System.Reactive;
using System.Text.Json;
using System.Threading.Tasks;
using System.Diagnostics;
using Helios.Database.Tables.Fortnite;
using Helios.Classes.UserAgent;

namespace Helios.Controllers.MCP;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/PurchaseCatalogEntry")]
public class PurchaseCatalogEntry : ControllerBase
{
    private static readonly JsonDocumentOptions JsonOptions = new()
    {
        AllowTrailingCommas = true,
        MaxDepth = 32
    };

    private static readonly JsonSerializerOptions SerializerOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = false
    };

    [HttpPost]
    [VerifyToken]
    public async Task<IActionResult> Init(
        [FromRoute] string accountId,
        [FromQuery] string profileId,
        [FromQuery] int rvn,
        [FromHeader(Name = "User-Agent")] string userAgent)
    {
        if (string.IsNullOrWhiteSpace(userAgent))
        {
            Logger.Error("[PURCHASE] User-Agent is null or empty");
            return InternalErrors.InvalidUserAgent.Apply(HttpContext);
        }

        if (string.IsNullOrWhiteSpace(profileId) || string.IsNullOrWhiteSpace(accountId))
        {
            Logger.Error($"[PURCHASE] Invalid parameters - ProfileId: {profileId ?? "null"}, AccountId: {accountId ?? "null"}");
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        if (profileId != "common_core")
        {
            Logger.Error($"[PURCHASE] Invalid profile ID: {profileId}");
            return MCPErrors.InvalidPayload.WithMessage("Invalid profile ID").Apply(HttpContext);
        }

        if (Constants.repositoryPool == null)
        {
            Logger.Error("[PURCHASE] Constants.repositoryPool is null");
            return InternalErrors.ServerError.WithMessage("Repository pool not initialized").Apply(HttpContext);
        }

        SeasonInfo parsedUserAgent;
        try
        {
            parsedUserAgent = UserAgentParser.Parse(userAgent);
            if (parsedUserAgent == null)
            {
                Logger.Error("[PURCHASE] UserAgentParser returned null");
                return InternalErrors.InvalidUserAgent.Apply(HttpContext);
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"[PURCHASE] UserAgent parsing failed: {ex.Message}");
            return InternalErrors.InvalidUserAgent.Apply(HttpContext);
        }

        JsonDocument json = null;
        try
        {
            if (Request.ContentLength.HasValue && Request.ContentLength.Value > 0 && Request.ContentLength.Value < 4096)
            {
                var buffer = ArrayPool<byte>.Shared.Rent((int)Request.ContentLength.Value);
                try
                {
                    var bytesRead = await Request.Body.ReadAsync(buffer.AsMemory(0, (int)Request.ContentLength.Value));
                    json = JsonDocument.Parse(buffer.AsMemory(0, bytesRead), JsonOptions);
                }
                finally
                {
                    ArrayPool<byte>.Shared.Return(buffer);
                }
            }
            else
            {
                using var memoryStream = new MemoryStream();
                await Request.Body.CopyToAsync(memoryStream);
                memoryStream.Position = 0;
                json = JsonDocument.Parse(memoryStream, JsonOptions);
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"[PURCHASE] JSON parsing failed: {ex.Message}");
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        if (json == null)
        {
            Logger.Error("[PURCHASE] JSON document is null after parsing");
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        using (json)
        {
            if (!json.RootElement.TryGetProperty("offerId", out var offerIdProperty) ||
                !json.RootElement.TryGetProperty("currency", out var currencyProperty))
            {
                Logger.Error("[PURCHASE] Missing required properties in JSON payload");
                return MCPErrors.InvalidPayload.Apply(HttpContext);
            }

            var offerId = offerIdProperty.GetString();
            var requiredCurrency = currencyProperty.GetString();

            if (string.IsNullOrWhiteSpace(offerId) || string.IsNullOrWhiteSpace(requiredCurrency))
            {
                Logger.Error($"[PURCHASE] Invalid offer or currency - OfferId: {offerId ?? "null"}, Currency: {requiredCurrency ?? "null"}");
                return MCPErrors.InvalidPayload.Apply(HttpContext);
            }

            if (requiredCurrency != "MtxCurrency")
            {
                Logger.Error($"[PURCHASE] Invalid currency type: {requiredCurrency}");
                return MCPErrors.InvalidPayload.WithMessage("Invalid currency").Apply(HttpContext);
            }

            var userRepository = Constants.repositoryPool.For<User>();
            var profilesRepository = Constants.repositoryPool.For<Profiles>();
            var profileItemsRepository = Constants.repositoryPool.For<Items>();
            var catalogRepository = Constants.repositoryPool.For<Catalog>();

            if (userRepository == null || profilesRepository == null || profileItemsRepository == null || catalogRepository == null)
            {
                Logger.Error("[PURCHASE] One or more repositories are null");
                return InternalErrors.ServerError.WithMessage("Repository initialization failed").Apply(HttpContext);
            }

            try
            {
                var userTask = userRepository.FindByColumnAsync("accountid", accountId);
                var profileTask = profilesRepository.FindByColumnsAsync(new Dictionary<string, object>
                {
                    ["profileid"] = profileId,
                    ["accountid"] = accountId
                });
                var athenaTask = profilesRepository.FindByColumnsAsync(new Dictionary<string, object>
                {
                    ["profileid"] = "athena",
                    ["accountid"] = accountId
                });
                var currencyTask = profileItemsRepository.FindByColumnsAsync(new Dictionary<string, object>
                {
                    ["profileid"] = "common_core",
                    ["accountid"] = accountId,
                    ["templateid"] = "Currency:MtxPurchased"
                });

                await Task.WhenAll(userTask, profileTask, currencyTask, athenaTask);

                var user = await userTask;
                var profile = await profileTask;
                var currency = await currencyTask;
                var athena = await athenaTask;

                if (user == null || profile == null || athena == null)
                {
                    Logger.Error($"[PURCHASE] Required entities not found - User: {user != null}, Profile: {profile != null}, Athena: {athena != null}");
                    return AccountErrors.AccountNotFound(accountId).Apply(HttpContext);
                }

                if (currency == null)
                {
                    Logger.Error("[PURCHASE] Currency not found in profile");
                    return StorefrontErrors.InvalidItem("Currency:MtxPurchased")
                        .WithMessage("Currency not found in profile.")
                        .Apply(HttpContext);
                }

                var notifications = new List<object>();
                var multiUpdates = new List<object>();
                var profileChanges = new List<object>();

                var index = offerId.IndexOf(':');
                var cleanOfferId = index >= 0 ? offerId.Substring(index + 1) : offerId;

                var foundItem = await StorefrontManager.FindItemByOfferId(catalogRepository, offerId);

                if (foundItem == null && cleanOfferId != offerId)
                {
                    foundItem = await StorefrontManager.FindItemByOfferId(catalogRepository, cleanOfferId);
                }

                if (foundItem == null)
                {
                    Logger.Error($"[PURCHASE] Offer not found in storefront: {offerId}");
                    return StorefrontErrors.InvalidItem(offerId)
                        .WithMessage("Offer ID not found in storefront.")
                        .Apply(HttpContext);
                }

                var currentItem = foundItem.Value;

                if (currentItem.Prices == null || currentItem.Prices.Count == 0)
                {
                    Logger.Error($"[PURCHASE] Item prices are null or empty for offer: {offerId}");
                    return StorefrontErrors.InvalidItem(offerId)
                        .WithMessage("Item pricing information not available.")
                        .Apply(HttpContext);
                }

                if (currentItem.ItemGrants == null)
                {
                    Logger.Error($"[PURCHASE] Item grants are null for offer: {offerId}");
                    return StorefrontErrors.InvalidItem(offerId)
                        .WithMessage("Item grant information not available.")
                        .Apply(HttpContext);
                }

                if (currentItem.Prices[0].FinalPrice > currency.Quantity)
                {
                    Logger.Error($"[PURCHASE] Insufficient funds - Required: {currentItem.Prices[0].FinalPrice}, Available: {currency.Quantity}");
                    return StorefrontErrors.PurchaseNotAllowed
                        .WithMessage("Insufficient funds.")
                        .Apply(HttpContext);
                }

                var templateIds = currentItem.ItemGrants
                    .Where(g => g != null && !string.IsNullOrWhiteSpace(g.TemplateId))
                    .Select(g => g.TemplateId)
                    .Distinct()
                    .ToArray();

                if (templateIds.Length == 0)
                {
                    Logger.Error($"[PURCHASE] No valid template IDs found for offer: {offerId}");
                    return StorefrontErrors.InvalidItem(offerId)
                        .WithMessage("No valid items to grant.")
                        .Apply(HttpContext);
                }

                var existingItems = await profileItemsRepository.FindByColumnsWithInClauseAsync(new Dictionary<string, object>
                {
                    ["accountid"] = user.AccountId,
                    ["profileid"] = "athena"
                }, "templateid", templateIds);

                if (existingItems != null && existingItems.Any())
                {
                    var ownedTemplateIds = existingItems.Select(item => item.TemplateId).ToHashSet();
                    var conflictingItems = templateIds.Where(tid => ownedTemplateIds.Contains(tid)).Take(3);
                    return StorefrontErrors.AlreadyOwned
                        .WithMessage($"You already own: {string.Join(", ", conflictingItems)}")
                        .Apply(HttpContext);
                }

                var newCurrency = currency.Quantity - currentItem.Prices[0].FinalPrice;
                currency.Quantity = newCurrency;

                if (currentItem.Prices[0].CurrencyType == "MtxCurrency")
                {
                    try
                    {
                        profileChanges.Add(new
                        {
                            changeType = "itemQuantityChanged",
                            itemId = "Currency:MtxPurchased",
                            quantity = newCurrency
                        });

                        await profileItemsRepository.UpdateAsync(currency);
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"[PURCHASE] Currency update failed: {ex.Message}");
                        return InternalErrors.ServerError
                            .WithMessage("An error occurred while processing your request.")
                            .Apply(HttpContext);
                    }
                }

                var itemQuantitiesByTemplateId = new Dictionary<string, int>();
                foreach (var grant in currentItem.ItemGrants.Where(g => g != null))
                {
                    if (string.IsNullOrWhiteSpace(grant.TemplateId))
                        continue;

                    if (itemQuantitiesByTemplateId.ContainsKey(grant.TemplateId))
                        itemQuantitiesByTemplateId[grant.TemplateId] += grant.Quantity;
                    else
                        itemQuantitiesByTemplateId[grant.TemplateId] = grant.Quantity;
                }

                var newItems = new List<Items>();
                var itemCreationTasks = itemQuantitiesByTemplateId.Select(async kvp =>
                {
                    var templateId = kvp.Key;
                    var quantity = kvp.Value;

                    try
                    {
                        var templateParts = templateId.Split(":");
                        if (templateParts.Length < 2)
                        {
                            Logger.Warn($"[PURCHASE] Invalid template ID format: {templateId}");
                            return null;
                        }

                        var variant = Constants.FileProvider != null
                            ? await Constants.FileProvider.GetVariantsAsync(templateParts[1])
                            : new List<Variants>();

                        var attributes = new
                        {
                            item_seen = false,
                            favorite = false,
                            level = 1,
                            xp = 0,
                            variants = variant ?? new List<Variants>()
                        };

                        var newItem = new Items
                        {
                            AccountId = accountId,
                            TemplateId = templateId,
                            Quantity = quantity,
                            Value = System.Text.Json.JsonSerializer.Serialize(attributes, SerializerOptions),
                            ProfileId = "athena",
                            IsAttribute = false
                        };

                        lock (multiUpdates)
                        {
                            multiUpdates.Add(new
                            {
                                changeType = "itemAdded",
                                itemId = templateId,
                                item = new
                                {
                                    templateId,
                                    attributes,
                                    quantity
                                }
                            });
                        }

                        lock (notifications)
                        {
                            notifications.Add(new
                            {
                                itemType = templateId,
                                itemGuid = templateId,
                                itemProfile = "athena",
                                quantity
                            });
                        }

                        lock (newItems)
                        {
                            newItems.Add(newItem);
                        }

                        return newItem;
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"[PURCHASE] Failed to create item {templateId}: {ex.Message}");
                        return null;
                    }
                });

                var createdItems = await Task.WhenAll(itemCreationTasks);
                var validItems = createdItems.Where(item => item != null).ToList();

                if (validItems.Count > 0)
                {
                    try
                    {
                        await profileItemsRepository.BulkSaveAsync(validItems);
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"[PURCHASE] Batch item save failed: {ex.Message}");
                        try
                        {
                            var saveTasks = validItems.Select(item => profileItemsRepository.SaveAsync(item));
                            await Task.WhenAll(saveTasks);
                        }
                        catch (Exception saveEx)
                        {
                            Logger.Error($"[PURCHASE] Individual item save also failed: {saveEx.Message}");
                            return InternalErrors.ServerError
                                .WithMessage("Failed to save purchased items.")
                                .Apply(HttpContext);
                        }
                    }
                }

                if (profileChanges.Count > 0)
                {
                    profile.Revision++;
                    athena.Revision++;

                    await Task.WhenAll(
                        ProfileManager.UpdateProfileAsync(profile),
                        ProfileManager.UpdateProfileAsync(athena)
                    );
                }

                await SendProfileUpdateRequest.UpdateAsync(accountId, user.Username);

                return Ok(ProfileResponseManager.GeneratePurchaseResponse(
                    profile, athena, profileChanges, multiUpdates, notifications, profileId));
            }
            catch (Exception ex)
            {
                Logger.Error($"[PURCHASE] Unexpected error: {ex.Message}\nStack Trace: {ex.StackTrace}");
                return InternalErrors.ServerError
                    .WithMessage("An unexpected error occurred while processing your request.")
                    .Apply(HttpContext);
            }
        }
    }
}