﻿using Helios.Classes.MCP;
using Helios.Classes.UserAgent;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Database.Tables.Stats;
using Helios.Managers;
using Helios.Managers.Helpers;
using Helios.Utilities;
using Helios.Utilities.Dtos;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Middleware.Attributes;
using Helios.Utilities.Profile;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using static Org.BouncyCastle.Math.EC.ECCurve;

namespace Helios.Controllers.MCP;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/QueryProfile")]
[Route("/fortnite/api/game/v2/profile/{accountId}/dedicated_server/QueryProfile")]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/ClaimMfaEnabled")]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/ClientQuestLogin")]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/SetHardcoreModifier")]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/RedeemRealMoneyPurchases")]
public class QueryProfile : ControllerBase
{
    private static readonly HashSet<string> DefaultPublicProfiles = new(StringComparer.OrdinalIgnoreCase)
    {
        "common_public",
        "collections",
        "creative"
    };
    
    private static readonly JsonSerializerOptions JsonOptions = new() { PropertyNamingPolicy = null };
    [HttpPost]
    [VerifyToken]
    public async Task<IActionResult> Init(
        [FromRoute] string accountId,
        [FromQuery] string profileId,
        [FromHeader(Name = "User-Agent")] string userAgent)
    {
        try
        {
            if (userAgent is null)
                return InternalErrors.InvalidUserAgent.Apply(HttpContext);

            if (string.IsNullOrEmpty(profileId) || string.IsNullOrEmpty(accountId))
                return MCPErrors.InvalidPayload.Apply(HttpContext);

            SeasonInfo parsedUserAgent;
            try
            {
                parsedUserAgent = UserAgentParser.Parse(userAgent);
            }
            catch (Exception ex)
            {
                Logger.Error($"Error parsing User-Agent: {ex}");
                return InternalErrors.InvalidUserAgent.WithMessage("Invalid User-Agent format").Apply(HttpContext);
            }

            var now = DateTime.Now;
            var utcNow = DateTime.UtcNow;
            var todayString = now.ToIsoUtcString();
            var utcNowString = utcNow.ToIsoUtcString();

            try
            {
                var userRepository = Constants.repositoryPool.For<User>();
                var profilesRepository = Constants.repositoryPool.For<Profiles>();

                var userTask = userRepository.FindByColumnAsync("accountid", accountId);
                var profileTask = profilesRepository.FindByColumnsAsync(new Dictionary<string, object>
                {
                    { "accountid", accountId },
                    { "profileid", profileId }
                });

                await Task.WhenAll(userTask, profileTask);

                var user = await userTask;
                if (user is null)
                    return AccountErrors.AccountNotFound(accountId).Apply(HttpContext);

                if (DefaultPublicProfiles.Contains(profileId))
                {
                    try
                    {
                        return Ok(GenerateDefaultPublicProfile(accountId, profileId, utcNowString));
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Error generating default public profile: {ex}");
                        return InternalErrors.ServerError.WithMessage("Failed to generate default profile").Apply(HttpContext);
                    }
                }

                var profile = await profileTask;
                if (profile is null)
                    return MCPErrors.TemplateNotFound.Apply(HttpContext);

                try
                {
                    var profileItemsRepository = Constants.repositoryPool.For<Items>(false);
                    List<Items> itemsList;
                    try
                    {
                        var profileItems = await profileItemsRepository.FindAllByColumnsAsync(new Dictionary<string, object>
                        {
                            { "accountid", accountId },
                            { "profileid", profileId }
                        }, useCache: false);

                        itemsList = profileItems.ToList();
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Error fetching profile items: {ex}");
                        return InternalErrors.ServerError.WithMessage("Failed to load profile items").Apply(HttpContext);
                    }

                    if (profile.ProfileId == "athena")
                    {
                        try
                        {
                            await ProcessSeasonItems(user.AccountId, profileItemsRepository, itemsList, parsedUserAgent);
                        }
                        catch (Exception ex)
                        {
                            Logger.Error($"Error processing season items: {ex}");
                        }
                    }

                    ProfileBuilder finalProfile;
                    try
                    {
                        finalProfile = new ProfileBuilder(accountId, profile, user, itemsList);
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Error building profile: {ex}");
                        return InternalErrors.ServerError.WithMessage("Failed to build profile").Apply(HttpContext);
                    }

                    var profileChanges = new List<object> { ProfileChangeDto.FullUpdate(finalProfile) };

                    try
                    {
                        return Ok(ProfileResponseManager.Generate(profile, profileChanges, profileId));
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Error generating profile response: {ex}");
                        return InternalErrors.ServerError.WithMessage("Failed to generate profile response").Apply(HttpContext);
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Error processing profile data: {ex}");
                    return InternalErrors.ServerError.WithMessage("Profile processing error").Apply(HttpContext);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error in profile query initialization: {ex}");
                return InternalErrors.ServerError.WithMessage("Initialization error").Apply(HttpContext);
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Unexpected error in QueryProfile: {ex}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    private static object GenerateDefaultPublicProfile(string accountId, string profileId, string utcNowString)
    {
        try
        {
            return new
            {
                profileRevision = 0,
                profileId,
                profileChanges = new object[]
                {
                new
                {
                    changeType = "fullProfileUpdate",
                    profile = new
                    {
                        _id = $"{profileId}-{accountId}",
                        created = utcNowString,
                        updated = utcNowString,
                        rvn = 0,
                        items = new object(),
                        stats = new
                        {
                            attributes = new object()
                        },
                        profileId,
                        accountId
                    }
                }
                },
                profileCommandRevision = 0,
                serverTime = utcNowString
            };
        }
        catch (Exception ex)
        {
            Logger.Error($"Error generating default public profile: {ex}");
            throw;
        }
    }

    private static async Task ProcessSeasonItems(
        string accountId,
        Repository<Items> repository,
        List<Items> items,
        SeasonInfo userAgent)
    {
        try
        {
            Items seasonNum;
            try
            {
                seasonNum = await repository.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "profileid", "athena" },
                { "templateid", "season_num" },
                { "accountid", accountId }
            });
            }
            catch (Exception ex)
            {
                Logger.Error($"Error fetching season_num item: {ex}");
                return;
            }

            if (seasonNum == null)
                return;

            try
            {
                seasonNum.Value = JsonConvert.SerializeObject(userAgent.Season);
                await repository.UpdateAsync(seasonNum);
            }
            catch (Exception ex)
            {
                Logger.Error($"Error updating season_num: {ex}");
            }

            var seasonStatsRepository = Constants.repositoryPool.For<SeasonStats>();

            List<SeasonStats>? seasonStats;
            try
            {
                seasonStats = (await seasonStatsRepository.FindAllByColumnsAsync(new Dictionary<string, object>
                {
                    { "accountid", accountId },
                    { "season", userAgent.Season }
                }))?.ToList();
            }
            catch (Exception ex)
            {
                Logger.Error($"Error fetching season stats: {ex}");
                seasonStats = new List<SeasonStats>();
            }

            if (seasonStats == null || !seasonStats.Any())
            {
                try
                {
                    await seasonStatsRepository.SaveAsync(new SeasonStats
                    {
                        AccountId = accountId,
                        Season = userAgent.Season,
                        Type = "",
                        Value = ""
                    });
                }
                catch (Exception ex)
                {
                    Logger.Error($"Error creating initial season stats: {ex}");
                }
            }

            var defaultFields = new Dictionary<string, object>
            {
                { "seasonNumber", userAgent.Season },
                { "numWins", 0 },
                { "numHighBracket", 0 },
                { "numLowBracket", 0 },
                { "seasonXp", 0 },
                { "seasonLevel", 1 },
                { "bookXp", 0 },
                { "bookLevel", 1 },
                { "purchasedVIP", false },
                { "survivorPrestige", 0 },
                { "survivorTier", 0 }
            };

            List<SeasonStats> seasonStatsList;
            try
            {
                seasonStatsList = (await seasonStatsRepository.FindAllByColumnsAsync(new Dictionary<string, object>
                {
                    { "accountid", accountId }
                }))?.ToList() ?? new List<SeasonStats>();
            }
            catch (Exception ex)
            {
                Logger.Error($"Error fetching all season stats: {ex}");
                seasonStatsList = new List<SeasonStats>();
            }

            var seasonStatsMap = seasonStatsList
                .GroupBy(stat => stat.Season)
                .ToDictionary(
                    group => group.Key,
                    group => group
                        .GroupBy(stat => stat.Type)
                        .ToDictionary(
                            typeGroup => typeGroup.Key,
                            typeGroup => typeGroup.First().Value
                        )
                );

            if (!seasonStatsMap.ContainsKey(userAgent.Season))
            {
                seasonStatsMap[userAgent.Season] = new Dictionary<string, string>();
            }

            var missingFields = new List<SeasonStats>();
            foreach (var (season, fields) in seasonStatsMap)
            {
                foreach (var (field, defaultValue) in defaultFields)
                {
                    string serializedValue = JsonConvert.SerializeObject(defaultValue);

                    if (!fields.TryGetValue(field, out var existingValue) ||
                        existingValue?.ToString() != serializedValue)
                    {
                        var existingEntry = seasonStatsList
                            .FirstOrDefault(s => s.Season == season && s.Type == field);

                        if (existingEntry == null)
                        {
                            missingFields.Add(new SeasonStats
                            {
                                AccountId = accountId,
                                Type = field,
                                Value = serializedValue,
                                Season = season,
                            });
                        }
                        else if (existingEntry.Value != serializedValue)
                        {
                            try
                            {
                                existingEntry.Value = serializedValue;
                                await seasonStatsRepository.UpdateAsync(existingEntry);
                            }
                            catch (Exception ex)
                            {
                                Logger.Error($"Error updating season stat {field}: {ex}");
                            }
                        }
                    }
                }
            }

            if (missingFields.Any())
            {
                try
                {
                    await Parallel.ForEachAsync(missingFields,
                        async (field, _) =>
                        {
                            try
                            {
                                await seasonStatsRepository.SaveAsync(field);
                            }
                            catch (Exception ex)
                            {
                                Logger.Error($"Error saving missing season stat {field.Type}: {ex}");
                            }
                        });
                }
                catch (Exception ex)
                {
                    Logger.Error($"Error processing missing fields: {ex}");
                }
            }

            var uniqueItems = items
                .GroupBy(item => item.TemplateId)
                .Select(group => group.First())
                .ToList();

            var templateItems = uniqueItems.ToDictionary(item => item.TemplateId);

            Items pastSeasons;
            try
            {
                if (!templateItems.TryGetValue("past_seasons", out pastSeasons) || pastSeasons.Value == null)
                {
                    pastSeasons = ProfileItemCreator.CreateStatItem(
                        "athena",
                        accountId,
                        "past_seasons",
                        new List<PastSeasons>()
                    );

                    templateItems["past_seasons"] = pastSeasons;

                    await repository.SaveAsync(pastSeasons);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error handling past_seasons item: {ex}");
                return;
            }

            List<PastSeasons> deserializedPastSeasons;
            try
            {
                deserializedPastSeasons = JsonConvert.DeserializeObject<List<PastSeasons>>(pastSeasons.Value)
                                          ?? new List<PastSeasons>();
            }
            catch (Exception ex)
            {
                Logger.Error($"Error deserializing past seasons: {ex}");
                deserializedPastSeasons = new List<PastSeasons>();
            }

            int currentSeason = Constants.CurrentVersion;
            var seasonLookup = deserializedPastSeasons
                .GroupBy(s => s.SeasonNumber)
                .ToDictionary(group => group.Key, group => group.First());

            try
            {
                var emptyTypeStats = await seasonStatsRepository.FindByColumnsAsync(new Dictionary<string, object>
                {
                    { "accountid", accountId },
                    { "type", "" }
                });
                if (emptyTypeStats != null)
                {
                    await seasonStatsRepository.DeleteAsync(emptyTypeStats);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error cleaning empty type stats: {ex}");
            }

            PastSeasons?[] updatedSeasons;
            try
            {
                updatedSeasons = await Task.WhenAll(
                    seasonStatsMap
                        .Where(entry => entry.Key == currentSeason)
                        .Select(async entry =>
                        {
                            try
                            {
                                var season = new PastSeasons
                                {
                                    SeasonNumber = entry.Key,
                                    NumWins = entry.Value.TryGetValue("numWins", out var numWins) &&
                                              int.TryParse(numWins as string, out var parsedNumWins)
                                        ? parsedNumWins
                                        : (int)defaultFields["numWins"],

                                    NumHighBracket = entry.Value.TryGetValue("numHighBracket", out var numHighBracket) &&
                                                     int.TryParse(numHighBracket as string, out var parsedNumHighBracket)
                                        ? parsedNumHighBracket
                                        : (int)defaultFields["numHighBracket"],

                                    NumLowBracket = entry.Value.TryGetValue("numLowBracket", out var numLowBracket) &&
                                                    int.TryParse(numLowBracket as string, out var parsedNumLowBracket)
                                        ? parsedNumLowBracket
                                        : (int)defaultFields["numLowBracket"],

                                    SeasonXp = entry.Value.TryGetValue("seasonXp", out var seasonXp) &&
                                               int.TryParse(seasonXp as string, out var parsedSeasonXp)
                                        ? parsedSeasonXp
                                        : (int)defaultFields["seasonXp"],

                                    SeasonLevel = entry.Value.TryGetValue("seasonLevel", out var seasonLevel) &&
                                                  int.TryParse(seasonLevel as string, out var parsedSeasonLevel)
                                        ? parsedSeasonLevel
                                        : (int)defaultFields["seasonLevel"],

                                    BookLevel = entry.Value.TryGetValue("bookLevel", out var bookLevel) &&
                                                int.TryParse(bookLevel as string, out var parsedBookLevel)
                                        ? parsedBookLevel
                                        : (int)defaultFields["bookLevel"],

                                    PurchasedVIP = entry.Value.TryGetValue("purchasedVIP", out var purchasedVIP) &&
                                                   bool.TryParse(purchasedVIP as string, out var parsedPurchasedVIP)
                                        ? parsedPurchasedVIP
                                        : (bool)defaultFields["purchasedVIP"]
                                };

                                var existingSeason = deserializedPastSeasons
                                    .FirstOrDefault(s => s.SeasonNumber == season.SeasonNumber);

                                if (existingSeason != null)
                                {
                                    existingSeason.NumWins = season.NumWins;
                                    existingSeason.NumHighBracket = season.NumHighBracket;
                                    existingSeason.NumLowBracket = season.NumLowBracket;
                                    existingSeason.SeasonXp = season.SeasonXp;
                                    existingSeason.SeasonLevel = season.SeasonLevel;
                                    existingSeason.BookLevel = season.BookLevel;
                                    existingSeason.PurchasedVIP = season.PurchasedVIP;

                                    var intKeys = new[] { "book_level", "book_xp", "level" };
                                    foreach (var key in intKeys)
                                    {
                                        if (templateItems.TryGetValue(key, out var item) &&
                                            int.TryParse(item.Value, out int value))
                                        {
                                            switch (key)
                                            {
                                                case "book_level": existingSeason.BookLevel = value; break;
                                                case "book_xp": existingSeason.BookXp = value; break;
                                                case "level": existingSeason.SeasonLevel = value; break;
                                            }
                                        }
                                    }

                                    if (templateItems.TryGetValue("book_purchased", out var purchasedItem) &&
                                        bool.TryParse(purchasedItem.Value, out bool purchased))
                                    {
                                        existingSeason.PurchasedVIP = purchased;
                                    }

                                    return existingSeason;
                                }

                                return season;
                            }
                            catch (Exception ex)
                            {
                                Logger.Error($"Error processing season stats for season {entry.Key}: {ex}");
                                return null;
                            }
                        })
                );
            }
            catch (Exception ex)
            {
                Logger.Error($"Error processing season updates: {ex}");
                return;
            }

            var newSeasons = updatedSeasons.Where(season => season != null).ToList();
            foreach (var season in newSeasons)
            {
                try
                {
                    var existingSeason = deserializedPastSeasons
                        .FirstOrDefault(s => s.SeasonNumber == season.SeasonNumber);

                    if (existingSeason != null)
                    {
                        existingSeason.NumWins = season.NumWins;
                        existingSeason.NumHighBracket = season.NumHighBracket;
                        existingSeason.NumLowBracket = season.NumLowBracket;
                        existingSeason.SeasonXp = season.SeasonXp;
                        existingSeason.SeasonLevel = season.SeasonLevel;
                        existingSeason.BookLevel = season.BookLevel;
                        existingSeason.PurchasedVIP = season.PurchasedVIP;
                    }
                    else
                    {
                        deserializedPastSeasons.Add(season);
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Error updating season {season?.SeasonNumber}: {ex}");
                }
            }

            try
            {
                deserializedPastSeasons = deserializedPastSeasons
                    .GroupBy(s => s.SeasonNumber)
                    .Select(group => group.First())
                    .ToList();

                pastSeasons.Value = JsonConvert.SerializeObject(deserializedPastSeasons);
                await repository.UpdateAsync(pastSeasons);
            }
            catch (Exception ex)
            {
                Logger.Error($"Error finalizing past seasons update: {ex}");
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Unexpected error in ProcessSeasonItems: {ex}");
        }
    }
}