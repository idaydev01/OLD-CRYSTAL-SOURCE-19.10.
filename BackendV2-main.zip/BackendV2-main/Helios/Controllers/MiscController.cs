﻿using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Fortnite;
using Helios.Database.Tables.Profiles;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Helios.Utilities.Tokens;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.Dynamic;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace Helios.Controllers;

[ApiController]
public class MiscController : ControllerBase
{
    [HttpGet("/hotconfigs/v2/{filename}")]
    public IActionResult HotConfigs(string filename)
    {
        var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Misc", filename);

        if (!System.IO.File.Exists(filePath))
            return BasicErrors.NotFound.WithMessage($"File '{filename}' not found.").Apply(HttpContext);

        var content = System.IO.File.ReadAllText(filePath);
        return Content(content, "application/json");
    }

    [HttpGet("/v1/epic-settings/public/users/{accountId}/values")]
    [HttpPatch("/v1/epic-settings/public/users/{accountId}/values")]
    public IActionResult GetPublicValues()
    {
        var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Misc", "epic-settings.json");

        if (!System.IO.File.Exists(filePath))
            return BasicErrors.NotFound.WithMessage($"File 'epic-settings.json' not found.").Apply(HttpContext);

        var content = System.IO.File.ReadAllText(filePath);
        return Content(content, "application/json");
    }

    [HttpGet("/eulatracking/api/public/agreements/fn/account/{accountId}")]
    public IActionResult GetAgreements(string accountId)
    {
        return NoContent();
    }

    [HttpGet("/content-controls/{accountId}")]
    public IActionResult GetContentControls(string accountId)
    {
        return Ok(new
        {
            data = new
            {
                ageGate = 0,
                controlsEnabled = false,
                maxEpicProfilePrivacy = "none",
                principalId = accountId
            }
        });
    }

    [HttpGet("/fortnite/api/game/v2/privacy/account/{accountId}")]
    public IActionResult GetPrivacyAccount(string accountId)
    {
        return Ok(new
        {
            accountId,
            optOutOfPublicLeaderboards = false
        });
    }

    [HttpGet("/sdk/v1/default")]
    [HttpGet("/sdk/v1/product/prod-fn")]
    public IActionResult GetEosSdkDefault()
    {
        var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Misc", "sdkv1default.json");

        if (!System.IO.File.Exists(filePath))
            return BasicErrors.NotFound.WithMessage($"File 'sdkv1default.json' not found.").Apply(HttpContext);

        var content = System.IO.File.ReadAllText(filePath);
        return Content(content, "application/json");
    }

    [HttpPost("/api/v1/fortnite-br/surfaces/motd/target")]
    [VerifyToken]
    public IActionResult CreateMotdTarget()
    {
        var contentItemId = Guid.NewGuid().ToString();
        var metaKey = Guid.NewGuid().ToString("N");

        const string imageUrl = "https://cdn.projecthelix.website/donatenewssize.png";

        var motd = new
        {
            contentType = "collection",
            contentId = "motd-default-collection",
            tcId = Guid.NewGuid().ToString(),
            contentItems = new[]
            {
            new
            {
                contentType = "content-item",
                contentId = contentItemId,
                tcId = Guid.NewGuid().ToString(),
                contentFields = new
                {
                    body = "You can now donate to Crystal! Get Full Locker, Starter Pack, or OG Pack.",
                    entryType = "Website",
                    image = new[]
                    {
                        new { width = 1920, height = 1080, url = imageUrl }
                    },
                    FullScreenBackground = new
                    {
                        Image = new[]
                        {
                            new { width = 1920, height = 1080, url = imageUrl }
                        },
                        _type = "FullScreenBackground"
                    },
                    tabTitleOverride = "CrystalFN",
                    tileImage = new[]
                    {
                        new { width = 1024, height = 512, url = imageUrl }
                    },
                    title = "DONATIONS",
                    videoAutoplay = false,
                    videoLoop = false,
                    videoMute = false,
                    videoStreamingEnabled = false,
                    websiteButtonText = "Donate",
                    websiteURL = "https://crystalmp.mysellauth.com/"
                },
                contentSchemaName = "MotdWebsiteNews"
            }
        },
            contentMeta = new Dictionary<string, List<string>>
            {
                [metaKey] = new List<string> { contentItemId }
            },
        };

        return Ok(motd);
    }

    [HttpGet("/api/v1/search")]
    [VerifyToken]
    public async Task<IActionResult> Search([FromQuery] string? prefix, [FromQuery] string? platform)
    {
        if (string.IsNullOrEmpty(prefix))
            return BasicErrors.BadRequest
                .WithMessage("Required String parameter 'prefix' is invalid or not present")
                .Apply(HttpContext);

        try
        {
            var response = new List<object>();
            var userRepository = Constants.repositoryPool.For<User>();
            var loweredPrefix = prefix.ToLower();

            var users = await userRepository.FindAllByPredicateAsync(
                          x => x.Username,
                          "STARTSWITH",
                          prefix,
                          limit: 100);

            var filteredUsers = users.Where(u => !u.Banned);
            foreach (var user in filteredUsers)
            {
                if (response.Count >= 100) break;

                if (string.IsNullOrEmpty(user.Username)) continue;

                var usernameLower = user.Username.ToLower();
                var prefixLower = prefix.ToLower();

                response.Add(new
                {
                    accountId = user.AccountId,
                    matches = new[]
                    {
                        new
                        {
                            value = user.Username,
                            platform = platform ?? "epic"
                        }
                    },
                    matchType = prefixLower == usernameLower ? "exact" : "prefix",
                    epicMutuals = 0,
                    sortPosition = response.Count
                });
            }

            return Ok(response);
        }
        catch (Exception ex)
        {
            Logger.Error($"Search error for prefix '{prefix}': {ex}");
            return InternalErrors.ServerError
                .WithMessage("An error occurred while processing your request. Please try again later.")
                .Apply(HttpContext);
        }
    }

    [HttpGet("/api/v1/search/{accountId}")]
    [VerifyToken]
    public async Task<IActionResult> SearchByAccountId(string accountId, [FromQuery] string prefix)
    {
        if (string.IsNullOrEmpty(accountId))
            return BasicErrors.BadRequest
                .WithMessage("Account ID is invalid or not present")
                .Apply(HttpContext);

        if (string.IsNullOrEmpty(prefix))
            return BasicErrors.BadRequest
                .WithMessage("Required String parameter 'prefix' is invalid or not present")
                .Apply(HttpContext);
        try
        {
            var response = new List<object>();
            var userRepository = Constants.repositoryPool.For<User>();
            var loweredPrefix = prefix.ToLower();

            var users = await userRepository.FindAllByPredicateAsync(
                          x => x.Username,
                          "STARTSWITH",
                          prefix,
                          limit: 100);

            var filteredUsers = users.Where(u => !u.Banned);
            foreach (var user in filteredUsers)
            {
                if (response.Count >= 100) break;

                if (string.IsNullOrEmpty(user.Username)) continue;

                var usernameLower = user.Username.ToLower();
                var prefixLower = prefix.ToLower();

                response.Add(new
                {
                    accountId = user.AccountId,
                    matches = new[]
                    {
                        new
                        {
                            value = user.Username,
                            platform = "epic"
                        }
                    },
                    matchType = prefixLower == usernameLower ? "exact" : "prefix",
                    epicMutuals = 0,
                    sortPosition = response.Count
                });
            }

            return Ok(response);
        }
        catch (Exception ex)
        {
            Logger.Error($"Search error for accountId '{accountId}': {ex}");
            return InternalErrors.ServerError
                .WithMessage("An error occurred while processing your request. Please try again later.")
                .Apply(HttpContext);
        }
    }

    [HttpPost("/api/v1/user/setting")]
    public async Task<IActionResult> UserSetting()
    {
        string requestBody = await new StreamReader(Request.Body).ReadToEndAsync();
        JObject requestData;

        try
        {
            requestData = JObject.Parse(requestBody);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        if (requestData["accountId"] == null)
            return BasicErrors.BadRequest.WithMessage("accountId is missing.").Apply(HttpContext);

        string accountId = requestData["accountId"]?.ToString();
        if (string.IsNullOrEmpty(accountId))
            return BasicErrors.BadRequest.WithMessage("accountId is invalid.").Apply(HttpContext);

        var userRepository = Constants.repositoryPool.For<User>();
        var user = await userRepository.FindByColumnAsync("accountid", accountId);
        if (user == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found").Apply(HttpContext);

        var loadoutsRepository = Constants.repositoryPool.For<Loadouts>();
        var loadout = await loadoutsRepository.FindByColumnsAsync(new Dictionary<string, object>
        {
            { "accountid", user.AccountId },
            { "profileid", "athena" },
            { "templateid", "CosmeticLocker:cosmeticlocker_athena" }
        });
        if (loadout == null)
            return BasicErrors.BadRequest.WithMessage("User loadouts not found").Apply(HttpContext);

        var favoriteCharacterItem = loadout.CharacterId;
        var favoriteCharacterValue = favoriteCharacterItem.ToString();
        if (string.IsNullOrWhiteSpace(favoriteCharacterValue))
            return BasicErrors.BadRequest.WithMessage("Favorite character value is empty").Apply(HttpContext);

        string favoriteCharacter = favoriteCharacterValue.Trim('"').Replace("AthenaCharacter:", "").ToLower();
        if (string.IsNullOrWhiteSpace(favoriteCharacter))
            return BasicErrors.BadRequest.WithMessage("Favorite character value is empty after processing").Apply(HttpContext);

        return Ok(new List<object>
        {
            new
            {
                accountId = user.AccountId,
                key = "avatar",
                value = favoriteCharacter
            },
            new
            {
                accountId = user.AccountId,
                key = "avatarBackground",
                value = "[\"#B4F2FE\",\"#00ACF2\",\"#005679\"]"
            },
            new
            {
                accountId = user.AccountId,
                key = "appInstalled",
                value = "init"
            }
        });
    }

    [HttpGet("/v1/avatar/fortnite/ids")]
    [VerifyToken]
    public async Task<IActionResult> GetFortniteAvatarIds([FromQuery] List<string> accountIds)
    {
        List<object> response = new();

        foreach (string accountId in accountIds)
        {
            var userRepository = Constants.repositoryPool.For<User>();
            var user = await userRepository.FindByColumnAsync("accountid", accountId);
            if (user == null)
                return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found").Apply(HttpContext);

            var loadoutsRepository = Constants.repositoryPool.For<Loadouts>();
            var loadout = await loadoutsRepository.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "accountid", user.AccountId },
                { "profileid", "athena" },
                { "templateid", "CosmeticLocker:cosmeticlocker_athena" }
            });
            if (loadout == null)
                return BasicErrors.BadRequest.WithMessage("User loadouts not found").Apply(HttpContext);

            var favoriteCharacterItem = loadout.CharacterId;
            var favoriteCharacterValue = favoriteCharacterItem.ToString();
            if (string.IsNullOrWhiteSpace(favoriteCharacterValue))
                return BasicErrors.BadRequest.WithMessage("Favorite character value is empty").Apply(HttpContext);

            string favoriteCharacter = favoriteCharacterValue.Trim('"').Replace("AthenaCharacter:", "").ToLower();
            if (string.IsNullOrWhiteSpace(favoriteCharacter))
                return BasicErrors.BadRequest.WithMessage("Favorite character value is empty after processing").Apply(HttpContext);

            response.Add(new
            {
                accountId = user.AccountId,
                @namespace = "fortnite",
                avatarId = favoriteCharacter
            });
        }

        return Ok(response);
    }

    [HttpGet("region")]
    public IActionResult GetRegion()
    {
        return Ok(new
        {
            continent = new
            {
                code = "EU",
                geoname_id = 6255148,
                names = new Dictionary<string, string>
                {
                    { "de", "Europa" },
                    { "en", "Europe" },
                    { "es", "Europa" },
                    { "fr", "Europe" },
                    { "ja", "ヨーロッパ" },
                    { "pt-BR", "Europa" },
                    { "ru", "Европа" },
                    { "zh-CN", "欧洲" }
                }
            },
            country = new
            {
                geoname_id = 2635167,
                is_in_european_union = false,
                iso_code = "GB",
                names = new Dictionary<string, string>
                {
                    { "de", "UK" },
                    { "en", "United Kingdom" },
                    { "es", "RU" },
                    { "fr", "Royaume Uni" },
                    { "ja", "英国" },
                    { "pt-BR", "Reino Unido" },
                    { "ru", "Британия" },
                    { "zh-CN", "英国" }
                }
            },
            subdivisions = new[]
            {
                new
                {
                    geoname_id = 6269131,
                    iso_code = "ENG",
                    names = new Dictionary<string, string>
                    {
                        { "de", "England" },
                        { "en", "England" },
                        { "es", "Inglaterra" },
                        { "fr", "Angleterre" },
                        { "ja", "イングランド" },
                        { "pt-BR", "Inglaterra" },
                        { "ru", "Англия" },
                        { "zh-CN", "英格兰" }
                    }
                },
                new
                {
                    geoname_id = 3333157,
                    iso_code = "KEC",
                    names = new Dictionary<string, string>
                    {
                        { "en", "Royal Kensington and Chelsea" }
                    }
                }
            }
        });
    }

    [HttpPut("/profiles")]
    public async Task<IActionResult> GetProfiles()
    {
        string requestBody = await new StreamReader(Request.Body).ReadToEndAsync();
        JObject requestData;

        try
        {
            requestData = JObject.Parse(requestBody);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        if (requestData["namespace"] == null || requestData["accountIds"] == null)
            return BasicErrors.BadRequest.WithMessage("Missing namespace or accountIds").Apply(HttpContext);

        var accountIds = ((IEnumerable<dynamic>)requestData["accountIds"]).Select(id => (string)id).ToList();

        var uRepo = Constants.repositoryPool.For<User>();
        var iRepo = Constants.repositoryPool.For<Items>();
        var profiles = new List<object>();

        foreach (var accountId in accountIds)
        {
            try
            {
                var user = await uRepo.FindByColumnAsync("accountid", accountId);
                if (user == null)
                    continue;

                var bookPurchased = await iRepo.FindAsync(new Items
                {
                    ProfileId = "athena",
                    AccountId = accountId,
                    TemplateId = "book_purchased"
                });

                var level = await iRepo.FindAsync(new Items
                {
                    ProfileId = "athena",
                    AccountId = accountId,
                    TemplateId = "level"
                });

                if (bookPurchased == null || level == null)
                {
                    Logger.Debug($"Missing items for accountId: {accountId}");
                    continue;
                }

                var isBookPurchased = JsonSerializer.Deserialize<bool>(bookPurchased.Value);
                var seasonLevel = JsonSerializer.Deserialize<int>(level.Value);

                var userGlobalRegionsRepository = Constants.repositoryPool.For<UserGlobalRegions>();
                var region = await userGlobalRegionsRepository.FindByColumnAsync("accountid", user.AccountId);

                var playRegion = region?.Region ?? "UNDEFINED_REGION";

                var profile = new
                {
                    accountId = user.AccountId,
                    hasBattlePass = isBookPurchased,
                    playRegion,
                    hasCrewMembership = false,
                    languages = new[] { "en" },
                    seasonLevel
                };

                profiles.Add(profile);
            }
            catch (Exception ex)
            {
                Logger.Error($"Error processing accountId: {accountId} {ex}");
            }
        }

        return Ok(new { profiles });
    }

    [HttpPut("/profile/play_region")]
    public async Task<IActionResult> UpdatePlayRegion()
    {
        if (!Request.Headers.TryGetValue("Authorization", out var authHeaders) ||
            string.IsNullOrWhiteSpace(authHeaders))
            return AuthenticationErrors.InvalidHeader.Apply(HttpContext);

        ReadOnlySpan<char> authHeader = authHeaders.ToString().AsSpan();
        const string bearerPrefix = "Bearer ";

        if (!authHeader.StartsWith(bearerPrefix, StringComparison.OrdinalIgnoreCase))
            return AuthenticationErrors.InvalidHeader.Apply(HttpContext);

        authHeader = authHeader.Slice(bearerPrefix.Length).Trim();
        const string expectedPrefix = "eg1~";

        string accessToken;
        if (authHeader.StartsWith(expectedPrefix, StringComparison.OrdinalIgnoreCase))
        {
            accessToken = authHeader.Slice(expectedPrefix.Length).ToString();
        }
        else
        {
            accessToken = authHeader.ToString();
        }

        if (string.IsNullOrEmpty(accessToken))
            return AuthenticationErrors.InvalidToken(authHeader.ToString())
                .WithMessage("Invalid Token")
                .Apply(HttpContext);

        IDictionary<string, object> decodedToken;
        try
        {
            decodedToken = TokenGenerator.DecodeToken(accessToken);
        }
        catch (Exception ex)
        {
            return AuthenticationErrors.InvalidToken("Failed to decode token")
                .WithMessage($"Token decoding failed: {ex.Message}")
                .Apply(HttpContext);
        }

        if (decodedToken == null || !(decodedToken["sub"] is string accountId) || string.IsNullOrEmpty(accountId))
            return AuthenticationErrors.InvalidToken("Failed to decode token or missing subject").Apply(HttpContext);

        var userRepository = Constants.repositoryPool.For<User>();
        var user = await userRepository.FindByColumnAsync("accountid", accountId);

        if (user == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);

        if (user.Banned)
            return AccountErrors.DisabledAccount.Apply(HttpContext);

        string requestBody;
        using (var reader = new StreamReader(Request.Body, leaveOpen: true))
        {
            requestBody = await reader.ReadToEndAsync();
        }

        if (string.IsNullOrEmpty(requestBody))
            return MCPErrors.InvalidPayload.Apply(HttpContext);

        JObject requestData;
        try
        {
            requestData = JObject.Parse(requestBody);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        if (requestData["namespace"] == null || requestData["play_region"] == null)
            return BasicErrors.BadRequest.WithMessage("Missing namespace or region").Apply(HttpContext);

        string region = requestData["play_region"]?.ToString();
        if (string.IsNullOrEmpty(region))
            return BasicErrors.BadRequest.WithMessage("Region is empty").Apply(HttpContext);

        var userGlobalRegionsRepository = Constants.repositoryPool.For<UserGlobalRegions>();
        var existingRegion = await userGlobalRegionsRepository.FindByColumnAsync("accountid", user.AccountId);

        if (existingRegion == null)
        {
            await userGlobalRegionsRepository.SaveAsync(new UserGlobalRegions
            {
                AccountId = user.AccountId,
                Region = region
            });
        }
        else if (!string.Equals(existingRegion.Region, region, StringComparison.OrdinalIgnoreCase))
        {
            existingRegion.Region = region;
            await userGlobalRegionsRepository.UpdateAsync(existingRegion);
        }

        return Ok(new { });
    }

    [HttpGet("/fortnite/api/receipts/v1/account/{accountId}/receipts")]
    public async Task<IActionResult> GetReceipts(string accountId)
    {
        var userRepository = Constants.repositoryPool.For<User>();
        var user = await userRepository.FindByColumnAsync("accountid", accountId);
        if (user == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found").Apply(HttpContext);

        var receiptsRepository = Constants.repositoryPool.For<FortniteReceipts>();
        var receipts = await receiptsRepository.FindAllByColumnAsync("accountid", new[] { accountId });
        if (receipts == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found").Apply(HttpContext);

        var formattedReceipts = receipts.Select(receipt => new
        {
            appStore = "EpicPurchasingService",
            appStoreId = receipt.AppStoreId ?? "",
            receiptId = receipt.ReceiptId ?? "",
            receiptInfo = receipt.ReceiptInfo ?? ""
        });

        return Ok(formattedReceipts);
    }

    [HttpGet("/ias/fortnite/{hash}")]
    [HttpHead("/ias/fortnite/{hash}")]
    public async Task<IActionResult> GetIasHash(string hash)
    {
        var targetUrl = $"https://epicgames-download1.akamaized.net/ias/fortnite/{hash}";

        using (var httpClient = new HttpClient())
        {
            var responseMessage = await httpClient.GetAsync(targetUrl, HttpCompletionOption.ResponseHeadersRead);

            if (!responseMessage.IsSuccessStatusCode)
            {
                return StatusCode((int)responseMessage.StatusCode);
            }

            var stream = await responseMessage.Content.ReadAsStreamAsync();

            return File(stream, "application/octet-stream");
        }
    }
}