﻿using Discord;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Database.Tables.XMPP;
using Helios.Socket;
using Helios.Sockets.Hermes.Exceptions;
using Helios.Sockets.Hermes.Responses;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json;

namespace Helios.Controllers.AntiCheat;

[ApiController]
[Route("/beryllium/api/v1/")]
public class BerylliumApiController : ControllerBase
{
    private static readonly HttpClient HttpClient = new HttpClient();

    private async Task SendDiscordEmbed(string username, string discordId, string message)
    {
        var embed = new
        {
            embeds = new[]
            {
                new
                {
                    title = "**Crystal AntiCheat**",
                    color = 16711680,
                    fields = new[]
                    {
                        new { name = "**Username**", value = username, inline = false },
                        new { name = "**Discord User**", value = $"<@{discordId ?? "Unknown User"}>", inline = false },
                        new { name = "**Detection**", value = message.Split(":")[0] ?? "Unknown Detection Type", inline = false },
                        new { name = "**Reason**", value = message.Contains(":")
                            ? string.Join(":", message.Split(':').Skip(1)).Trim()
                            : "DLL Injection", inline = false },
                    }
                }
            }
        };

        var json = JsonSerializer.Serialize(embed);
        var content = new StringContent(json, Encoding.UTF8, "application/json");
        await HttpClient.PostAsync(Constants.config.DiscordWebhookUrl, content);
    }

    private async Task SendDirectMessage(string discordId, string username)
    {
        if (string.IsNullOrEmpty(discordId) || Constants.DiscordSocketClient == null)
        {
            Logger.Warn($"Cannot send DM to {username}: Missing Discortd ID or bot client not initialized");
            return;
        }

        try
        {
            if (!ulong.TryParse(discordId, out var userId))
            {
                Logger.Error($"Invalid Discord ID format for {username}: {discordId}");
                return;
            }

            var user = await Constants.DiscordSocketClient.GetUserAsync(userId);
            if (user == null)
            {
                Logger.Warn($"Could not find Discord user {discordId} for {username}");
                return;
            }

            var banMessage = $"**Account Banned - Crystal AntiCheat**\n\n" +
                           $"Hello {username},\n\n" +
                           $"Your account has been banned due to anti-cheat detection.\n\n" +
                           $"**Date:** {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} UTC\n\n" +
                           $"If you believe this ban was issued in error, please create a ticket in our support server.";

            await user.SendMessageAsync(banMessage);
            Logger.Info($"Successfully sent ban DM to {username} ({discordId})");
        }
        catch (Exception ex)
        {
            Logger.Error($"Exception while sending DM to {username}: {ex.Message}");
        }
    }

    [HttpPost("auth")]
    public async Task<IActionResult> Authorize()
    {
        var repositories = (
            tokens: Constants.repositoryPool.For<Tokens>(),
            users: Constants.repositoryPool.For<User>(),
            hardwares: Constants.repositoryPool.For<Hardwares>(),
            bans: Constants.repositoryPool.For<Ban>()
        );

        var shitty = Request.Headers["Beryllium-Token"].FirstOrDefault();
        if (shitty != Constants.ArsenicToken)
            return BasicErrors.BadRequest.Apply(HttpContext);

        JsonDocument requestData;
        try
        {
            requestData = await JsonDocument.ParseAsync(Request.Body);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        using (requestData)
        {
            var root = requestData.RootElement;
            if (!root.TryGetProperty("token", out var tokenElement) ||
                !root.TryGetProperty("hwid", out var hwidElement))
                return BasicErrors.BadRequest.WithMessage("Missing request data.").Apply(HttpContext);

            var token = tokenElement.GetString();
            var hwid = hwidElement.GetString();

            if (string.IsNullOrEmpty(token) || hwid == null)
                return BasicErrors.BadRequest.WithMessage("Missing request data.").Apply(HttpContext);

            var validToken = await repositories.tokens.FindByColumnAsync("token", token);
            if (validToken == null)
                return AuthenticationErrors.InvalidToken(token).WithMessage("Invalid token.").Apply(HttpContext);

            using HttpClient client = new HttpClient();
            HttpResponseMessage response = await client.GetAsync("");

            if (response.IsSuccessStatusCode)
            {
                string responseBody = await response.Content.ReadAsStringAsync();
                if (responseBody != "true")
                    return AuthenticationErrors.InvalidToken(token).WithMessage("Invalid token.").Apply(HttpContext);
            }
            else
                return AuthenticationErrors.InvalidToken(token).WithMessage("Invalid token.").Apply(HttpContext);
        
            var user = await repositories.users.FindByColumnAsync("accountid", validToken.AccountId);
            if (user == null)
                return AccountErrors.AccountNotFound(validToken.AccountId)
                    .WithMessage($"User with id {validToken.AccountId} not found")
                    .Apply(HttpContext);

            var hardwareTask = repositories.hardwares.FindByColumnAsync("hwid", hwid);
            var userBansTask = repositories.bans.FindByColumnAsync("accountid", user.AccountId);

            await Task.WhenAll(hardwareTask, userBansTask);

            var hardware = hardwareTask.Result;
            var userBans = userBansTask.Result;

            if (hardware == null)
            {
                await repositories.hardwares.SaveAsync(new Hardwares
                {
                    Hwid = hwid,
                    Banned = false,
                    AccountId = validToken.AccountId
                });
            }

            if (userBans == null)
                return AccountErrors.AccountNotFound(validToken.AccountId)
                    .WithMessage($"User with id {user.AccountId} not found")
                    .Apply(HttpContext);

            if (userBans.IsRecentlyUnbanned)
            {
                userBans.IsRecentlyUnbanned = false;
                userBans.UnbannedAt = DateTime.UtcNow;
                user.Banned = false;

                if (!user.Ac)
                {
                    user.Ac = true;
                    await repositories.users.UpdateAsync(user);
                }

                await Task.WhenAll(
                    repositories.bans.UpdateAsync(userBans),
                    repositories.users.UpdateAsync(user)
                );

                return Ok(new
                {
                    unban = true
                });
            }

            if (user.Banned)
                return AccountErrors.DisabledAccount.Apply(HttpContext);

            if (!user.Ac)
            {
                user.Ac = true;
                await repositories.users.UpdateAsync(user);
            }

            return Ok(new
            {
                unban = false
            });
        }
    }

    [HttpPost("ban")]
    public async Task<IActionResult> BanUser()
    {
        var repositories = (
            tokens: Constants.repositoryPool.For<Tokens>(),
            users: Constants.repositoryPool.For<User>(),
            hardwares: Constants.repositoryPool.For<Hardwares>(),
            bans: Constants.repositoryPool.For<Ban>()
        );


        var shitty = Request.Headers["Beryllium-Token"].FirstOrDefault();
        if (shitty != Constants.ArsenicToken)
            return BasicErrors.BadRequest.Apply(HttpContext);

        JsonDocument requestData;
        try
        {
            requestData = await JsonDocument.ParseAsync(Request.Body);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        using (requestData)
        {
            var root = requestData.RootElement;
            if (!root.TryGetProperty("token", out var tokenElement) ||
                !root.TryGetProperty("message", out var messageElement))
                return BasicErrors.BadRequest.WithMessage("Missing request data.").Apply(HttpContext);

            var token = tokenElement.GetString();
            var message = messageElement.GetString();

            if (string.IsNullOrEmpty(token) || string.IsNullOrEmpty(message))
                return BasicErrors.BadRequest.WithMessage("Missing request data.").Apply(HttpContext);

            var validToken = await repositories.tokens.FindByColumnAsync("token", token);
            if (validToken == null)
                return AuthenticationErrors.InvalidToken(token).WithMessage("Invalid token.").Apply(HttpContext);

            var user = await repositories.users.FindByColumnAsync("accountid", validToken.AccountId);
            if (user == null)
                return AccountErrors.AccountNotFound(validToken.AccountId)
                    .WithMessage($"User with id {validToken.AccountId} not found")
                    .Apply(HttpContext);

            var hardwareTask = repositories.hardwares.FindByColumnAsync("accountid", user.AccountId);
            var userBansTask = repositories.bans.FindByColumnAsync("accountid", user.AccountId);

            await Task.WhenAll(hardwareTask, userBansTask);

            var hardware = hardwareTask.Result;
            var userBans = userBansTask.Result;

            if (hardware == null)
                return AccountErrors.AccountNotFound(validToken.AccountId)
                    .WithMessage($"User with id {validToken.AccountId} not found")
                    .Apply(HttpContext);

            if (userBans == null)
                return AccountErrors.AccountNotFound(validToken.AccountId)
                    .WithMessage($"User with id {user.AccountId} not found")
                    .Apply(HttpContext);

            Logger.Debug($"Socket Message: {message}");
            if (message == "Detected traces!")
            {
                userBans.IsShadowBanned = true;
                userBans.ShadowBanReason = "Traces Detected";
                userBans.ShadowBanStart = DateTime.UtcNow;
                userBans.ShadowBanEnd = DateTime.UtcNow.AddMonths(6);

                await repositories.bans.UpdateAsync(userBans);
            }
            else
            {
                hardware.Banned = true;
                user.Banned = true;

                await Task.WhenAll(
                    repositories.hardwares.UpdateAsync(hardware),
                    repositories.users.UpdateAsync(user)
                );

                _ = Task.Run(async () => await SendDirectMessage(user.DiscordId, user.Username));
            }

            await SendDiscordEmbed(user.Username, user.DiscordId, message);

            return Ok(Array.Empty<object>());
        }
    }

    [HttpPost("detection")]
    public async Task<IActionResult> Detection()
    {
        var repositories = (
            tokens: Constants.repositoryPool.For<Tokens>(),
            users: Constants.repositoryPool.For<User>(),
            hardwares: Constants.repositoryPool.For<Hardwares>(),
            bans: Constants.repositoryPool.For<Ban>()
        );


        var shitty = Request.Headers["Beryllium-Token"].FirstOrDefault();
        if (shitty != Constants.ArsenicToken)
            return BasicErrors.BadRequest.Apply(HttpContext);

        JsonDocument requestData;
        try
        {
            requestData = await JsonDocument.ParseAsync(Request.Body);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        using (requestData)
        {
            var root = requestData.RootElement;
            if (!root.TryGetProperty("token", out var tokenElement) ||
                !root.TryGetProperty("message", out var messageElement))
                return BasicErrors.BadRequest.WithMessage("Missing request data.").Apply(HttpContext);

            var token = tokenElement.GetString();
            var message = messageElement.GetString();

            if (string.IsNullOrEmpty(token) || string.IsNullOrEmpty(message))
                return BasicErrors.BadRequest.WithMessage("Missing request data.").Apply(HttpContext);

            var validToken = await repositories.tokens.FindByColumnAsync("token", token);
            if (validToken == null)
                return AuthenticationErrors.InvalidToken(token).WithMessage("Invalid token.").Apply(HttpContext);

            var user = await repositories.users.FindByColumnAsync("accountid", validToken.AccountId);
            if (user == null)
                return AccountErrors.AccountNotFound(validToken.AccountId)
                    .WithMessage($"User with id {validToken.AccountId} not found")
                    .Apply(HttpContext);

            var hardwareTask = repositories.hardwares.FindByColumnAsync("accountid", user.AccountId);
            var userBansTask = repositories.bans.FindByColumnAsync("accountid", user.AccountId);

            await Task.WhenAll(hardwareTask, userBansTask);

            var hardware = hardwareTask.Result;
            var userBans = userBansTask.Result;

            if (hardware == null)
                return AccountErrors.AccountNotFound(validToken.AccountId)
                    .WithMessage($"User with id {validToken.AccountId} not found")
                    .Apply(HttpContext);

            if (userBans == null)
                return AccountErrors.AccountNotFound(validToken.AccountId)
                    .WithMessage($"User with id {user.AccountId} not found")
                    .Apply(HttpContext);

            Logger.Debug($"Socket Message: {message}");
            await SendDiscordEmbed(user.Username, user.DiscordId, message);

            return Ok(Array.Empty<object>());
        }
    }

    [HttpPost("deauth")]
    public async Task<IActionResult> Deauth()
    {
        var repositories = (
            tokens: Constants.repositoryPool.For<Tokens>(),
            users: Constants.repositoryPool.For<User>()
        );


        var shitty = Request.Headers["Beryllium-Token"].FirstOrDefault();
        if (shitty != Constants.ArsenicToken)
            return BasicErrors.BadRequest.Apply(HttpContext);

        JsonDocument requestData;
        try
        {
            requestData = await JsonDocument.ParseAsync(Request.Body);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        using (requestData)
        {
            var root = requestData.RootElement;
            if (!root.TryGetProperty("token", out var tokenElement))
                return BasicErrors.BadRequest.WithMessage("Missing request data.").Apply(HttpContext);

            var token = tokenElement.GetString();
            var tokensRepository = Constants.repositoryPool.For<Tokens>();

            if (string.IsNullOrEmpty(token))
                return BasicErrors.BadRequest.WithMessage("Missing request data.").Apply(HttpContext);

            var validToken = await repositories.tokens.FindByColumnAsync("token", token);
            if (validToken == null)
                return AuthenticationErrors.InvalidToken(token).WithMessage("Invalid token.").Apply(HttpContext);

            var user = await repositories.users.FindByColumnAsync("accountid", validToken.AccountId);
            if (user == null)
                return AccountErrors.AccountNotFound(validToken.AccountId)
                    .WithMessage($"User with id {validToken.AccountId} not found")
                    .Apply(HttpContext);

            //UserInfoResponse activeSession = null;

            //try
            //{
            //    activeSession = await Constants.GlobalXmppClientService.GetUserAsync(user.AccountId);
            //}
            //catch (XmppForwarderException ex)
            //{
            //    if (!ex.Message.Contains("not found", StringComparison.OrdinalIgnoreCase))
            //    {
            //        Logger.Error($"XMPP lookup error for {user.AccountId}: {ex.Message}");
            //    }
            //}

            var dbTasks = new List<Task>();

            //if (activeSession != null)
            //{
            //    dbTasks.Add(Constants.GlobalXmppClientService.DeleteUserAsync(user.AccountId));
            //}

            _ = Task.Run(async () =>
            {
                try
                {
                    await Constants.GlobalXmppClientService.DeleteUserAsync(user.AccountId);
                }
                catch (Exception ex)
                {
                }
            });

            if (user.Ac != false)
            {
                user.Ac = false;
                dbTasks.Add(repositories.users.UpdateAsync(user));
            }

            if (dbTasks.Count > 0)
                await Task.WhenAll(dbTasks);

            //await tokensRepository.DeleteAsync(new Tokens { AccountId = user.AccountId, Type = "accesstoken" });
            //await tokensRepository.DeleteAsync(new Tokens { AccountId = user.AccountId, Type = "refreshtoken" });

            return Ok(Array.Empty<object>());
        }
    }
}
