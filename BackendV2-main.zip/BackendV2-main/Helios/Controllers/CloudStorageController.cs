﻿using System.Security.Cryptography;
using System.Text;
using Helios.Classes.CloudStorage;
using Helios.Classes.Errors;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using CloudStorage = Helios.Database.Tables.Fortnite.CloudStorage;

namespace Helios.Controllers;

[ApiController]
[Route("/fortnite/api/cloudstorage/")]
public class CloudStorageController : ControllerBase
{
    private static readonly int CurrentSeason;
    private static readonly string ClientSettingsPath;
    private readonly Repository<CloudStorage> _cloudStorageRepository = Constants.repositoryPool.For<CloudStorage>();
    private readonly string _clientSettingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Helios", "ClientSettings");
    
    static CloudStorageController()
    {
        ClientSettingsPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Helios",
            "ClientSettings");

        Directory.CreateDirectory(ClientSettingsPath);
        CurrentSeason = int.Parse(Constants.config.CurrentVersion.Split('.')[0]);
    }

    [HttpGet("system")]
    public async Task<IActionResult> GetCloudStorageFilesAsync()
    {
        var userAgent = Request.Headers["User-Agent"].ToString();
        var seasonData = UserAgentParser.Parse(userAgent);
        
        if (seasonData == null)
            return InternalErrors.InvalidUserAgent.Apply(HttpContext);

        if (seasonData.Season != CurrentSeason)
            return InternalErrors.InvalidUserAgent.Apply(HttpContext);

        var hotfixes = await _cloudStorageRepository.FindAllByTableAsync();
        var enabledHotfixes = hotfixes.Where(x => x.Enabled).ToList();
        if (enabledHotfixes.Count == 0)
            return MCPErrors.InvalidPayload.WithIntent(Intents.Prod).Apply(HttpContext);

        var uploadedTime = DateTime.UtcNow.ToIsoUtcString();
        
        using var sha1 = SHA1.Create();
        using var sha256 = SHA256.Create();
        
        var result = new List<CloudStorageFile>(enabledHotfixes.Count);
        
        foreach (var row in enabledHotfixes)
        {
            var valueBytes = Encoding.UTF8.GetBytes(row.Value);
            result.Add(new CloudStorageFile
            {
                UniqueFilename = row.Filename,
                Filename = row.Filename,
                Hash = Convert.ToHexString(sha1.ComputeHash(valueBytes)),
                Hash256 = Convert.ToHexString(sha256.ComputeHash(valueBytes)),
                Length = valueBytes.Length,
                ContentType = "application/octet-stream",
                Uploaded = uploadedTime,
                StorageType = "S3",
                DoNotCache = false
            });
        }

        return Ok(result);
    }
    
    [HttpGet("system/{filename}")]
    public async Task<IActionResult> GetFileByNameAsync(string filename)
    {
        var userAgent = Request.Headers["User-Agent"].ToString();
        var seasonData = UserAgentParser.Parse(userAgent);
        
        if (seasonData == null)
            return InternalErrors.InvalidUserAgent.Apply(HttpContext);

        if (seasonData.Season != CurrentSeason)
            return InternalErrors.InvalidUserAgent.Apply(HttpContext);
        
        var hotfixes = await _cloudStorageRepository.FindAllByTableAsync();
        var enabledHotfix = hotfixes?.FirstOrDefault(x => x.Enabled && x.Filename == filename);
        if (enabledHotfix is null)
            return MCPErrors.InvalidPayload.WithIntent(Intents.Prod).Apply(HttpContext);

        return Content(enabledHotfix.Value, "text/plain");
    }
    
    [HttpGet("system/config")]
    public IActionResult GetCloudStorageConfig()
    {
        return Ok(new { });
    }

    [HttpGet("user/{accountId}/{file}")]
    [VerifyToken]
    public async Task<IActionResult> GetClientSettingsFile(string accountId, string file)
    {
        string clientSettingsFile = Path.Combine(_clientSettingsPath, $"ClientSettings-{accountId}.Sav");
        string timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");

        if (file != "ClientSettings.Sav" || !System.IO.File.Exists(clientSettingsFile))
            return CloudStorageErrors.FileNotFound
                .WithMessage(
                    $"Sorry, we couldn't find a settings file with the filename {file} for the accountId {accountId}")
                .Apply(HttpContext);
        
        try
        {
            byte[] data = await System.IO.File.ReadAllBytesAsync(clientSettingsFile);
            return File(data, "application/octet-stream");
        }
        catch (Exception ex)
        {
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    [HttpGet("user/{accountId}")]
    public async Task<IActionResult> GetClientSettingsMetadata(string accountId)
    {
        string clientSettingsFile = Path.Combine(_clientSettingsPath, $"ClientSettings-{accountId}.Sav");
        

        if (System.IO.File.Exists(clientSettingsFile))
        {
            try
            {
                byte[] fileContent = await System.IO.File.ReadAllBytesAsync(clientSettingsFile);
                var fileInfo = new FileInfo(clientSettingsFile);
                string sha1Hash = HashAlgorithmGenerator.GenerateHashByByte(fileContent, SHA1.Create());
                string sha256Hash = HashAlgorithmGenerator.GenerateHashByByte(fileContent, SHA256.Create());

                var response = new[]
                {
                    new
                    {
                        uniqueFilename = "ClientSettings.Sav",
                        filename = "ClientSettings.Sav",
                        hash = sha1Hash,
                        hash256 = sha256Hash,
                        length = fileContent.Length,
                        contentType = "application/octet-stream",
                        uploaded = fileInfo.LastWriteTimeUtc,
                        storageType = "S3",
                        storageIds = new object(),
                        accountId,
                        doNotCache = false
                    }
                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                return InternalErrors.ServerError.Apply(HttpContext);
            }
        }

        return Ok(Array.Empty<object>());
    }

    [HttpPut("user/{accountId}/{file}")]
    [RequestSizeLimit(10 * 1024 * 1024)] 
    [VerifyToken]
    public async Task<IActionResult> UploadClientSettingsFile(string accountId, string file)
    {
        try
        {
            using (var memoryStream = new MemoryStream())
            {
                await Request.Body.CopyToAsync(memoryStream);
                byte[] body = memoryStream.ToArray();
                //
                // if (body.Length >= 400000)
                //     return CloudStorageErrors.FileTooLarge.Apply(HttpContext);

                if (file != "ClientSettings.Sav")
                    return CloudStorageErrors.FileNotFound.Apply(HttpContext);

                string clientSettingsFile = Path.Combine(_clientSettingsPath, $"ClientSettings-{accountId}.Sav");

                await System.IO.File.WriteAllBytesAsync(clientSettingsFile, body);
                return Ok();
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to save clientSettings: {ex}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }
}