﻿using Helios.Classes.Tournaments;
using Helios.Classes.Tournaments.DBInterfaces;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Tournaments;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Org.BouncyCastle.Utilities.Collections;
using Sentry.Protocol;
using System.Numerics;
using System.Text.RegularExpressions;
using static Org.BouncyCastle.Asn1.Cmp.Challenge;

namespace Helios.Controllers.Events;

[ApiController]
[Route("/api/v1/events/{appId}/")]
public class EventsController : ControllerBase
{
    private readonly Repository<TournamentHypeTokens> eventHypeTokensRepository;
    private readonly Repository<TournamentHype> eventHypeRepository;
    private readonly Repository<TournamentEvents> eventsRepository;
    private readonly Repository<TournamentPlayer> eventPlayersRepository;
    private readonly Repository<TournamentTokens> eventTokensRepository;
    private readonly Repository<TournamentTeams> eventTeamsRepository;
    private readonly Repository<TournamentTemplates> eventTemplatesRepository;
    private readonly Repository<TournamentDedicatedServer> eventDedicatedServers;
    private readonly Repository<TournamentScores> eventScoresRepository;
    private readonly Repository<TournamentHistory> eventHistoryRepository;
    private readonly Repository<Database.Tables.Account.User> userRepository;

    public EventsController()
    {
        eventHypeTokensRepository = Constants.repositoryPool.For<TournamentHypeTokens>();
        eventHypeRepository = Constants.repositoryPool.For<TournamentHype>();
        eventsRepository = Constants.repositoryPool.For<TournamentEvents>();
        eventPlayersRepository = Constants.repositoryPool.For<TournamentPlayer>();
        eventTokensRepository = Constants.repositoryPool.For<TournamentTokens>();
        eventTeamsRepository = Constants.repositoryPool.For<TournamentTeams>();
        eventTemplatesRepository = Constants.repositoryPool.For<TournamentTemplates>();
        eventScoresRepository = Constants.repositoryPool.For<TournamentScores>();
        eventDedicatedServers = Constants.repositoryPool.For<TournamentDedicatedServer>();
        eventHistoryRepository = Constants.repositoryPool.For<TournamentHistory>();
        userRepository = Constants.repositoryPool.For<Database.Tables.Account.User>();
    }

    [HttpGet("download/{accountId}")]
    //[VerifyToken]
    public async Task<IActionResult> Download(string appId, string accountId)
    {
        try
        {
            if (string.IsNullOrEmpty(accountId))
                return AccountErrors.AccountNotFound(accountId)
                    .WithMessage($"User with id {accountId} not found")
                    .Apply(HttpContext);

            var userAgent = Request.Headers["User-Agent"].ToString();
            if (string.IsNullOrEmpty(userAgent))
                return InternalErrors.InvalidUserAgent.Apply(HttpContext);

            var userAgentInfo = UserAgentParser.Parse(userAgent);
            if (userAgentInfo == null)
                return InternalErrors.InvalidUserAgent.Apply(HttpContext);

            var userTask = userRepository.FindByColumnAsync("accountid", accountId);
            var eventsTask = eventsRepository.FindAllByColumnAsync("season", new object[] { userAgentInfo.Season });
            var playerTask = eventPlayersRepository.FindByColumnAsync("accountid", accountId);

            var tokensTask = eventTokensRepository.FindAllByColumnsAsync(new Dictionary<string, object>
            {
                { "accountid", accountId },
                { "season", userAgentInfo.Season }
            });

            var teamsTask = eventTeamsRepository.FindByColumnAsync("accountid", accountId);
            var templatesTask =
                eventTemplatesRepository.FindAllByColumnAsync("season", new object[] { userAgentInfo.Season });
            var persistentScoresTask = eventHypeRepository.FindAllByColumnsAsync(new Dictionary<string, object>
            {
                { "accountid", accountId },
                { "season", userAgentInfo.Season }
            });
            var eventScoresTask = eventScoresRepository.FindAllByColumnsAsync(new Dictionary<string, object>
            {
                { "accountid", accountId },
                { "season", userAgentInfo.Season }
            });

            var arenaEventsTask = EventsManager.LoadFileWithCachingAsync("ArenaEvent.json");
            var arenaTemplatesTask = EventsManager.LoadFileWithCachingAsync("ArenaTemplates.json");

            await Task.WhenAll(userTask, eventsTask, playerTask, tokensTask, teamsTask,
                templatesTask, persistentScoresTask, eventScoresTask,
                arenaEventsTask, arenaTemplatesTask);

            var user = await userTask;
            if (user == null)
                return AccountErrors.AccountNotFound(accountId)
                    .WithMessage($"User with id {accountId} not found")
                    .Apply(HttpContext);

            if (user.Banned)
                return AccountErrors.DisabledAccount.Apply(HttpContext);

            var allEvents = await eventsTask;
            var player = await playerTask;
            var allTokens = await tokensTask; 
            var allTeams = await teamsTask;
            var allEventTemplates = await templatesTask;
            var persistentScores = await persistentScoresTask;
            var allEventScores = await eventScoresTask;

            var arenaEventsContent = await arenaEventsTask;
            var arenaTemplatesContent = await arenaTemplatesTask;

            if (arenaEventsContent == null || arenaTemplatesContent == null)
                return BasicErrors.NotFound.WithMessage("File not found.").Apply(HttpContext);

            var arenaEvents = JsonConvert.DeserializeObject<List<Classes.Tournaments.Event>>(arenaEventsContent);
            var arenaEventTemplates = JsonConvert.DeserializeObject<List<ArenaEventTemplate>>(arenaTemplatesContent);

            if (arenaEvents == null || arenaEventTemplates == null)
            {
                Logger.Error("Arena events deserialization resulted in null");
                return InternalErrors.ServerError.Apply(HttpContext);
            }

            var seasonReplacement = $"S{userAgentInfo.Season}";

            EventsManager.ProcessArenaEventsInParallel(arenaEvents, seasonReplacement);
            EventsManager.ProcessArenaTemplatesInParallel(arenaEventTemplates, seasonReplacement);

            player = await EventsManager.EnsurePlayerExistsAsync(player, accountId, userAgentInfo.Season,
                eventPlayersRepository);
            persistentScores = await EventsManager.EnsurePersistentScoresExistAsync(persistentScores, accountId,
                userAgentInfo.Season, eventHypeRepository);

            var divisions = EventsManager.CreateDivisions(userAgentInfo.Season);
            var hypeEntities = EventsManager.CreateHypeEntities(divisions, accountId, userAgentInfo.Season);

            var existingHypeTokens = await eventHypeTokensRepository.FindAllByColumnsAsync(new Dictionary<string, object>
            {
                { "accountid", accountId },
                { "season", userAgentInfo.Season }
            });

            await EventsManager.ProcessHypeTokensAsync(hypeEntities, existingHypeTokens, eventHypeTokensRepository);
            await EventsManager.ProcessNewTokensAsync(persistentScores, divisions, allTokens, accountId,
                userAgentInfo.Season, eventTokensRepository);

            allTokens = await eventTokensRepository.FindAllByColumnsAsync(new Dictionary<string, object>
            {
                { "accountid", accountId },
                { "season", userAgentInfo.Season }
            });

            var eventMappings = EventsManager.CreateEventMappings(allEvents, appId);
            var templateMappings = EventsManager.CreateTemplateMappings(allEventTemplates, appId);

            bool shouldIncludeArena = EventsManager.ShouldIncludeArenaEvents(userAgentInfo.Season, Constants.config.CurrentVersion);

            if (shouldIncludeArena)
            {
                var arenaEventMappings = EventsManager.CreateArenaEventMappings(arenaEvents);
                var arenaTemplateMappings = EventsManager.CreateArenaTemplateMappings(arenaEventTemplates, appId);

                eventMappings.AddRange(arenaEventMappings);
                templateMappings.AddRange(arenaTemplateMappings);
            }

            var existingTokens = new HashSet<string>(allTokens.Select(et => et.Token));
            var scores = EventsManager.CreateScoresDictionary(persistentScores, allEventScores);

            return Ok(new
            {
                events = eventMappings,
                templates = templateMappings,
                player = new
                {
                    accountId = accountId,
                    gameId = appId,
                    groupIdentity = new object(),
                    pendingPayouts = player.PendingPayouts ?? new List<object>(),
                    pendingPenalties = player.PendingPenalties ?? new List<object>(),
                    persistentScores = scores,
                    teams = allTeams?.Teams ?? new Dictionary<string, List<string>>(),
                    tokens = existingTokens
                },
                scores = new List<object>(),
            });
        }
        catch (Exception ex)
        {
            Logger.Error($"Error while downloading events: {ex}");
            return InternalErrors.ServerError.WithMessage("Internal Server Error").Apply(HttpContext);
        }
    }

    [HttpGet("{eventId}/history/{accountId}")]
    public async Task<IActionResult> GetEventHistory(string eventId, string accountId)
    {
        try
        {
            if (string.IsNullOrEmpty(accountId))
                return AccountErrors.AccountNotFound(accountId)
                    .WithMessage($"User with id {accountId} not found")
                    .Apply(HttpContext);

            if (string.IsNullOrEmpty(eventId))
                return BasicErrors.BadRequest.WithMessage("Invalid request.").Apply(HttpContext);

            var userAgent = Request.Headers["User-Agent"].ToString();
            if (string.IsNullOrEmpty(userAgent))
                return InternalErrors.InvalidUserAgent.Apply(HttpContext);

            var userTask = userRepository.FindByColumnAsync("accountid", accountId);
            var dedicatedPlayerTask = eventDedicatedServers.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "accountid", accountId },
                { "eventid", eventId }
            });
            var playerHistoryTask = eventHistoryRepository.FindAllByColumnsAsync(new Dictionary<string, object>
            {
                { "accountid", accountId },
                { "eventid", eventId }
            });
            var allDedicatedPlayersTask = eventDedicatedServers.FindAllByColumnAsync("eventid", new[] { eventId });
            var eventDetailsTask = eventsRepository.FindByColumnAsync("eventid", eventId);

            await Task.WhenAll(userTask, dedicatedPlayerTask, playerHistoryTask, allDedicatedPlayersTask, eventDetailsTask);

            var user = await userTask;
            var dedicatedPlayer = await dedicatedPlayerTask;
            var playerHistory = (await playerHistoryTask)?.ToList() ?? new List<TournamentHistory>();
            var allDedicatedPlayers = (await allDedicatedPlayersTask)?.ToList() ?? new List<TournamentDedicatedServer>();
            var eventDetails = await eventDetailsTask;

            if (user == null)
                return AccountErrors.AccountNotFound(accountId)
                    .WithMessage($"User with id {accountId} not found")
                    .Apply(HttpContext);

            if (user.Banned)
                return AccountErrors.DisabledAccount.Apply(HttpContext);

            if (dedicatedPlayer == null)
                return Ok(new List<object>());

            if (playerHistory == null || playerHistory.Count == 0)
                return Ok(new List<object>());

            if (eventDetails == null)
                return BasicErrors.NotFound.WithMessage("Event not found.").Apply(HttpContext);

            var sortedPlayers = allDedicatedPlayers
                .Where(p => p != null)
                .OrderByDescending(p => p.PointsEarned)
                .ToList();

            int playerRank = sortedPlayers.FindIndex(p => p.AccountId == accountId) + 1;
            int totalPlayers = sortedPlayers.Count;
            double percentile = totalPlayers > 1
                ? ((double)(totalPlayers - playerRank) / (totalPlayers - 1)) * 100
                : 100;

            var statTotals = new Dictionary<string, (int Times, int Points)>
            {
                ["TEAM_ELIMS"] = (0, 0),
                ["PLACEMENT"] = (0, 0),
                ["VICTORY_ROYALE"] = (0, 0),
                ["TIME_ALIVE"] = (0, 0),
                ["MATCHES_PLAYED"] = (0, 0)
            };

            var sessionHistoryEntries = new List<object>();
            var matches = dedicatedPlayer.Matches ?? new List<string>();

            foreach (var history in playerHistory)
            {
                void Accumulate(string key, DB_EventStatIndex stat)
                {
                    if (stat == null) return;
                    statTotals[key] = (
                        statTotals[key].Times + stat.TimesAchieved,
                        statTotals[key].Points + stat.PointsEarned
                    );
                }

                Accumulate("TEAM_ELIMS", history.TeamElimsStatIndex);
                Accumulate("PLACEMENT", history.PlacementStatIndex);
                Accumulate("VICTORY_ROYALE", history.VictoryRoyaleStatIndex);
                Accumulate("TIME_ALIVE", history.TimeAliveStatIndex);
                Accumulate("MATCHES_PLAYED", history.MatchesPlayedStatIndex);

                foreach (var sessionId in matches)
                {
                    var endTime = history?.SessionEndTimes?.GetValueOrDefault(sessionId) ?? DateTime.UtcNow.ToIsoUtcString();
                    var trackedStats = new Dictionary<string, DB_EventStatIndex>();

                    if (history.PlacementStatIndex != null)
                        trackedStats[$"PLACEMENT_STAT_INDEX:{history.PlacementStatIndex.PointsEarned}"] = history.PlacementStatIndex;

                    if (history.TeamElimsStatIndex != null)
                        trackedStats[$"TEAM_ELIMS_STAT_INDEX:{history.TeamElimsStatIndex.PointsEarned}"] = history.TeamElimsStatIndex;

                    if (history.VictoryRoyaleStatIndex != null)
                        trackedStats[$"VICTORY_ROYALE_STAT:{history.VictoryRoyaleStatIndex.PointsEarned}"] = history.VictoryRoyaleStatIndex;

                    if (history.TimeAliveStatIndex != null)
                        trackedStats[$"TIME_ALIVE_STAT:{history.TimeAliveStatIndex.PointsEarned}"] = history.TimeAliveStatIndex;

                    if (history.MatchesPlayedStatIndex != null)
                        trackedStats[$"MATCH_PLAYED_STAT:{history.MatchesPlayedStatIndex.TimesAchieved}"] = history.MatchesPlayedStatIndex;

                    sessionHistoryEntries.Add(new
                    {
                        sessionId,
                        endTime,
                        trackedStats
                    });
                }
            }

            var scoringStats = new Dictionary<string, string>
            {
                ["TEAM_ELIMS"] = "TEAM_ELIMS_STAT_INDEX",
                ["PLACEMENT"] = "PLACEMENT_STAT_INDEX",
                ["VICTORY_ROYALE"] = "VICTORY_ROYALE_STAT"
            };

            var pointBreakdown = statTotals
                .Where(kvp => scoringStats.ContainsKey(kvp.Key))
                .ToDictionary(
                    kvp =>
                    {
                        var formattedName = scoringStats[kvp.Key];
                        return $"{formattedName}:{kvp.Value.Points}";
                    },
                    kvp => new
                    {
                        timesAchieved = kvp.Value.Times,
                        pointsEarned = kvp.Value.Points
                    });

            var deserializedEventWindows = eventDetails.EventWindows != null
            ? eventDetails.EventWindows
                .Select(window => EventsManager.DeserializeEventWindow(window))
                .Where(window => window != null)
                .ToList()
            : new List<DB_EventWindow>();

            // Get the first event window ID whose template ID starts with the eventId
            string eventWindowId = deserializedEventWindows
                .FirstOrDefault(window => window.EventTemplateId != null && window.EventTemplateId.StartsWith(eventId))?.EventWindowId ?? string.Empty;

            var result = new List<object>
            {
                new
                {
                    scoreKey = new
                    {
                        gameId = "Fortnite",
                        eventId,
                        eventWindowId,
                        _scoreId = (string)null
                    },
                    teamId = dedicatedPlayer.TeamId ?? string.Empty,
                    teamAccountIds = dedicatedPlayer.Teammates ?? new List<string>(),
                    liveSessionId = "",
                    pointsEarned = dedicatedPlayer.PointsEarned,
                    rank = playerRank,
                    percentile = Math.Round(percentile),
                    pointsBreakdown = pointBreakdown,
                    sessionHistory = dedicatedPlayer.Matches ?? new List<string>(),
                    unscoredSessions = new List<string>()
                }
            };

            return Ok(result);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error while fetching event history: {ex}");
            return InternalErrors.ServerError.WithMessage("Internal Server Error").Apply(HttpContext);
        }
    }
}
