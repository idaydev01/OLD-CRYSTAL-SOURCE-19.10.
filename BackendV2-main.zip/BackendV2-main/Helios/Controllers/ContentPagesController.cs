﻿using Helios.Classes.ContentPages;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.ContentPages;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Runtime.ConstrainedExecution;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace Helios.Controllers;

[ApiController]
[Route("/content/api/pages/")]
public class ContentPagesController : ControllerBase
{
    [HttpGet("fortnite-game")]
    public async Task<IActionResult> GetFortniteGamePage()
    {
        if (!Request.Headers.TryGetValue("User-Agent", out var userAgent) || string.IsNullOrWhiteSpace(userAgent))
            return InternalErrors.InvalidUserAgent.Apply(HttpContext);

        var userAgentInfo = await UserAgentParser.ParseAsync(userAgent.ToString());
        if (userAgentInfo == null)
            return InternalErrors.InvalidUserAgent.WithMessage("Failed to parse User-Agent.").Apply(HttpContext);

        var now = DateTime.UtcNow;
        var isoNow = now.ToIsoUtcString();

        var tournamentInformationRepository = Constants.repositoryPool.For<Helios.Database.Tables.ContentPages.TournamentInformation>(false);
        var idkbro = await tournamentInformationRepository.FindAllByTableAsync();
        var tournamentInformation = await GetTournamentInformationAsync(tournamentInformationRepository);

        var pages = new ContentPages
        {
            IsCheckedOut = true,
            Title = "Fortnite Game",
            BaseVersion = Guid.NewGuid().ToString(),
            ActiveDate = now,
            LastModified = now,
            Locale = "en-US",
            Creative = CreateCreative(),
            EmergencyNotice = CreateEmergencyNotice(isoNow),
            EmergencyNoticeV2 = CreateEmergencyNoticeV2(),
            Lobby = CreateLobby(now),
            DynamicBackgrounds = CreateDynamicBackgrounds(userAgentInfo.Background, now),
            BattleRoyaleNews = CreateBattleRoyaleNews(now),
            BattleRoyaleNewsV2 = CreateBattleRoyaleNewsV2(userAgentInfo.Season),
            PlaylistInformation = CreatePlaylistInformation(isoNow, userAgentInfo.Season),
            TournamentInformation = CreateTournamentInformation(isoNow, tournamentInformation),
            ShopSections = CreateShopSections(isoNow),
            ScoringRulesInfo = CreateScoringRulesInfo(isoNow)
        };

        if (userAgentInfo.Season == 24)
        {
            pages.DynamicBackgrounds.Backgrounds.Backgrounds.ForEach(bg =>
            {
                bg.Stage = "defaultnotris";
                bg.BackgroundImage = "https://i.redd.it/does-anyone-know-what-this-is-v0-e2hh7we9fotc1.jpg?width=1125&format=pjpg&auto=webp&s=852b21be080a3d009cb48ea99355ec0bf8e3e3c5";
            });
        }

        var json = JsonSerializer.Serialize(pages);
        return Ok(json);
    }

    private async Task<List<Tournament>> GetTournamentInformationAsync(Repository<Helios.Database.Tables.ContentPages.TournamentInformation> tournamentInformationRepository)
    {
        var tournamentData = await tournamentInformationRepository.FindAllByTableAsync();

        return tournamentData
            .AsParallel()
            .WithDegreeOfParallelism(Environment.ProcessorCount)
            .Where(dbTournament => dbTournament != null)
            .Select(dbTournament => new Tournament
            {
                LoadingScreenImage = dbTournament.LoadingScreenImage,
                TitleColor = dbTournament.TitleColor,
                BackgroundRightColor = dbTournament.BackgroundRightColor,
                BackgroundTextColor = dbTournament.BackgroundTextColor,
                Type = dbTournament.Type,
                TournamentDisplayId = dbTournament.TournamentDisplayId,
                HighlightColor = dbTournament.HighlightColor,
                PrimaryColor = dbTournament.PrimaryColor,
                TitleLine1 = dbTournament.TitleLine1,
                TitleLine2 = dbTournament.TitleLine2,
                ShadowColor = dbTournament.ShadowColor,
                BackgroundLeftColor = dbTournament.BackgroundLeftColor,
                PosterFadeColor = dbTournament.PosterFadeColor,
                SecondaryColor = dbTournament.SecondaryColor,
                PlaylistTileImage = dbTournament.PlaylistTileImage,
                BaseColor = dbTournament.BaseColor,
                PinScoreRequirement = dbTournament.PinScoreRequirement,
                PinEarnedText = dbTournament.PinEarnedText,
                ScheduleInfo = dbTournament.ScheduleInfo,
                FlavorDescription = dbTournament.FlavorDescription,
                PosterFrontImage = dbTournament.PosterFrontImage,
                PosterBackImage = dbTournament.PosterBackImage,
                ShortFormatTitle = dbTournament.ShortFormatTitle,
                LongFormatTitle = dbTournament.LongFormatTitle,
                DetailsDescription = dbTournament.DetailsDescription
            })
            .ToList();
    }

    private static ScoringRulesInfo CreateScoringRulesInfo(string isoNow) => new()
    {
        Title = "scoringrulesinformation",
        Type = "Scoring Rules Info",
        NoIndex = false,
        ActiveDate = "2021-10-12T19:24:18.962Z",
        LastModified = isoNow,
        Locale = "en-US",
        TemplateName = "FortniteGameScoringRulesInfo",
        ScoringRulesInformation = new ScoringRulesInformation
        {
            Type = "Scoring Rules Info",
            ScoringRules = new List<ScoringRulesDisplayInfo>
            {
                CreateScoringRule("Loot Island Captured", "MMO_LootIsland", "Loot Island Captured"),
                CreateScoringRule("{0}|plural(one=Each Forcast Tower Captured,other=Every {0} Forcast Tower Captures)", "EACH_MMO_RadioTower", "{0} - {1} Forcast Towers Captured"),
                CreateScoringRule("{0}|plural(one=Each Vault Captured,other=Every {0} Vault Captures)", "EACH_MMO_Vault", "{0} - {1} Vault Captured"),
                CreateScoringRule("{0}|plural(one=Each Cache Captured,other=Every {0} Cache Captures)", "EACH_MMO_Cache", "{0} - {1} Cache Captured"),
                CreateScoringRule("Victory Royale", "VICTORY_ROYALE_STAT", "Victory Royale"),
                CreateScoringRule("{0} {0}|plural(one=Elimination,other=Eliminations)", "Eliminations", "{0} - {1} Eliminations", "/Game/Athena/HUD/Art/killsico_alt.KillsIco_Alt"),
                CreateScoringRule("{0} {0}|plural(one=Elimination,other=Eliminations)", "TEAM_ELIMS_STAT_INDEX", "{0} - {1} Eliminations", "/Game/Athena/HUD/Art/killsico_alt.KillsIco_Alt"),
                CreateScoringRule("{0}{0}|ordinal(one=st,two=nd,few=rd,other=th) Place", "Placement", "{0}{0}|ordinal(one=st,two=nd,few=rd,other=th) - {1}{1}|ordinal(one=st,two=nd,few=rd,other=th) Place", "/Game/UI/Foundation/Textures/Icons/Quest/T-Icon-Trophy-32.T-Icon-Trophy-32", "Reach Top {0}"),
                CreateScoringRule("{0}|plural(one=Each Elimination,other=Every {0} Eliminations)", "EachElimination", "", "/Game/Athena/HUD/Art/killsico_alt.KillsIco_Alt"),
                CreateScoringRule("{0}|plural(one=Each Elimination,other=Every {0} Eliminations)", "EACH_CREATIVE_ELIMINATIONS_STAT", "{0} - {1} Eliminations", "/Game/Athena/HUD/Art/killsico_alt.KillsIco_Alt"),
                CreateScoringRule("Bus Fare", "MatchEntryFee", null, "/Game/UI/Events/Icons/T-Icon-Bus-Fare-Flat.T-Icon-Bus-Fare-Flat"),
                CreateScoringRule("{0} {0}|plural(one=Bow Elimination,other=Bow Eliminations)", "BowKills", "{0} - {1} Bow Eliminations", "/Game/Athena/HUD/Art/killsico_alt.KillsIco_Alt"),
                CreateScoringRule("Each score of {0}", "EACH_CREATIVE_SCORE_STAT", "", "/Game/UI/Foundation/Textures/Icons/Quest/T-Icon-Trophy-32.T-Icon-Trophy-32", hideNotifications: true),
                CreateScoringRule("Score of {0}", "Scores", "Score of {0} - {1}"),
                CreateScoringRule("{0} {0}|plural(one=Time Eliminated,other=Times Eliminated)", "EACH_CREATIVE_ELIMINATED_STAT", "{0} - {1} Times Eliminated", "/Game/Athena/HUD/Art/killsico_alt.KillsIco_Alt"),
                CreateScoringRule("{0}|plural(one=Each Damage Dealt,other=Every {0} Damage Dealt)", "CREATIVE_DAMAGE_DEALT_STAT", null, "/Game/Athena/HUD/Art/icon_health.icon_health", hideNotifications: true),
                CreateScoringRule("{0}|plural(one=Each Damage Taken,other=Every {0} Damage Taken)", "CREATIVE_DAMAGE_TAKEN_STAT", null, "/Game/Athena/HUD/Art/icon_health.icon_health"),
                CreateScoringRule("{0}|plural(one=Each Item Collected,other=Every {0} Items Collected)", "EACH_CREATIVE_COLLECT_ITEMS_STAT", "{0} - {1} Items Collected"),
                CreateScoringRule("Every {0} Remaining Spawn", "CREATIVE_SPAWNS_LEFT_STAT"),
                CreateScoringRule("Every {0} Health Remaining", "CREATIVE_REMAINING_HEALTH_STAT", null, "/Game/Athena/HUD/Art/icon_health.icon_health"),
                CreateScoringRule("{0}|plural(one=Each Objective Completed,other=Every {0} Objectives Completed)", "EACH_CREATIVE_OBJECTIVES_STAT"),
                CreateScoringRule("{0}|plural(one=AI Elimination,other=Every {0} AI Eliminations)", "EACH_CREATIVE_AI_ELIMINATIONS_STAT", "{0} - {1} AI Eliminated", "/Game/Athena/HUD/Art/killsico_alt.KillsIco_Alt"),
                CreateScoringRule("{0}|plural(one=Each Assist,other=Assists)", "EACH_CREATIVE_ASSISTS_STAT", "{0} - {1} Assists", "/Game/Athena/HUD/Art/killsico_alt.KillsIco_Alt"),
                CreateScoringRule("{0}|plural(one=Each millisecond Alive,other=Every {0} Milliseconds Alive)", "EACH_CREATIVE_TIME_ALIVE_STAT", null, "/Game/Athena/HUD/Art/icon_health.icon_health", hideNotifications: true),
                CreateScoringRule("For every lap under {0} milliseconds", "CREATIVE_RACE_TIME_STAT", null, "ns/Quest/T-Icon-Trophy-32.T-Icon-Trophy-32")
            }
        },
        SuggestedPrefetch = new List<object>()
    };

    private static ScoringRulesDisplayInfo CreateScoringRule(string description, string ruleName, string? intervalDescription = null, string? icon = null, string? customDescription = null, bool hideNotifications = false)
    {
        return new ScoringRulesDisplayInfo
        {
            PosterDescription = description,
            RuleName = ruleName,
            Icon = icon ?? "/Game/UI/Foundation/Textures/Icons/Quest/T-Icon-Trophy-32.T-Icon-Trophy-32",
            Description = customDescription ?? description,
            HideScoreToastNotifications = hideNotifications,
            PosterIntervalDescription = intervalDescription
        };
    }

    private static PlaylistInformation CreatePlaylistInformation(string isoNow, int season) => new()
    {
        Title = "playlistinformation",
        FrontendMatchmakingHeaderText = "",
        FrontendMatchmakingHeaderStyle = "None",
        PlaylistInfo = new PlaylistInfo
        {
            Type = "Playlist Information",
            Playlists = new List<Playlist>
            {
                CreatePlaylist("Playlist_DefaultSolo", "Solo", season),
                CreatePlaylist("Playlist_DefaultDuo", "Duo", season),
                CreatePlaylist("Playlist_DefaultSquad", "Squad", season),
                CreatePlaylist("Playlist_PlaygroundV2", "Creative", season)
            }
        },
        NoIndex = false,
        ActiveDate = isoNow,
        LastModified = isoNow,
        Locale = "en-US"
    };

    private static Playlist CreatePlaylist(string playlistName, string displayName, int season)
    {
        return new Playlist
        {
            Image = $"https://overseasoverseasbackend.xyz/S{season}{displayName}.jpg",
            PlaylistName = playlistName,
            Hidden = false,
            SpecialBorder = "None",
            Type = "FortPlaylistInfo",
            DisplayName = displayName
        };
    }

    private static Helios.Classes.ContentPages.TournamentInformation CreateTournamentInformation(string isoNow, List<Tournament> tournamentInformation)
    {
        var tournaments = CreateDefaultTournaments();

        tournaments.AddRange(
            tournamentInformation
                .AsParallel()
                .WithDegreeOfParallelism(Environment.ProcessorCount)
                .Where(t => t != null)
                .Select(CreateTournamentFromData)
        );

        return new Helios.Classes.ContentPages.TournamentInformation
        {
            Title = "tournamentinformation",
            NoIndex = false,
            ActiveDate = isoNow,
            LastModified = isoNow,
            Locale = "en-US",
            TournamentInfo = new TournamentInfo
            {
                Type = "Tournaments Info",
                Tournaments = tournaments
            }
        };
    }

    private static List<Tournament> CreateDefaultTournaments()
    {
        return new List<Tournament>
        {
            new Tournament
            {
                LoadingScreenImage = "https://cdn2.unrealengine.com/s18-br-lategame2-newsheader-1900x600-4b329e68f671.jpg?resize=1&w=1600",
                TitleColor = "0BFFAC",
                BackgroundRightColor = "41108C",
                BackgroundTextColor = "390087",
                Type = "Tournament Display Info",
                TournamentDisplayId = "crystal_arena_lg_solo",
                HighlightColor = "FFFFFF",
                PrimaryColor = "0BFFAC",
                TitleLine1 = "ARENA LATEGAME SOLO",
                ShadowColor = "5000BE",
                BackgroundLeftColor = "B537FB",
                PosterFadeColor = "420793",
                SecondaryColor = "FF1A40",
                PlaylistTileImage = "https://cdn2.unrealengine.com/s18-br-lategame2-newsheader-1900x600-4b329e68f671.jpg?resize=1&w=1600",
                BaseColor = "FFFFFF"
            },
            new Tournament
            {
                LoadingScreenImage = "https://cdn-0001.qstv.on.epicgames.com/qVPfvcEpHeVOWcHQhL/image/landscape_comp.jpeg",
                TitleColor = "0BFFAC",
                BackgroundRightColor = "41108C",
                BackgroundTextColor = "390087",
                Type = "Tournament Display Info",
                TournamentDisplayId = "crystal_arena_solo",
                HighlightColor = "FFFFFF",
                PrimaryColor = "0BFFAC",
                TitleLine1 = "ARENA SOLO",
                ShadowColor = "5000BE",
                BackgroundLeftColor = "B537FB",
                PosterFadeColor = "420793",
                SecondaryColor = "FF1A40",
                PlaylistTileImage = "https://cdn-0001.qstv.on.epicgames.com/qVPfvcEpHeVOWcHQhL/image/landscape_comp.jpeg",
                BaseColor = "FFFFFF"
            }
        };
    }


    private static Tournament CreateTournamentFromData(Tournament t)
    {
        return new Tournament
        {
            LoadingScreenImage = t.LoadingScreenImage,
            TitleColor = t.TitleColor?.Replace("#", "") ?? string.Empty,
            BackgroundRightColor = t.BackgroundRightColor?.Replace("#", "") ?? string.Empty,
            BackgroundTextColor = t.BackgroundTextColor?.Replace("#", "") ?? string.Empty,
            Type = t.Type,
            TournamentDisplayId = t.TournamentDisplayId,
            HighlightColor = t.HighlightColor?.Replace("#", "") ?? string.Empty,
            PrimaryColor = t.PrimaryColor?.Replace("#", "") ?? string.Empty,
            TitleLine1 = t.TitleLine1,
            TitleLine2 = t.TitleLine2,
            ShadowColor = t.ShadowColor?.Replace("#", "") ?? string.Empty,
            BackgroundLeftColor = t.BackgroundLeftColor?.Replace("#", "") ?? string.Empty,
            PosterFadeColor = t.PosterFadeColor?.Replace("#", "") ?? string.Empty,
            SecondaryColor = t.SecondaryColor?.Replace("#", "") ?? string.Empty,
            PlaylistTileImage = t.PlaylistTileImage,
            BaseColor = t.BaseColor?.Replace("#", "") ?? string.Empty,
            PinScoreRequirement = t.PinScoreRequirement,
            PinEarnedText = t.PinEarnedText,
            ScheduleInfo = t.ScheduleInfo,
            FlavorDescription = t.FlavorDescription,
            PosterFrontImage = t.PosterFrontImage,
            PosterBackImage = t.PosterBackImage,
            ShortFormatTitle = t.ShortFormatTitle,
            LongFormatTitle = t.LongFormatTitle,
            DetailsDescription = t.DetailsDescription
        };
    }
    private static Creative CreateCreative() => new()
    {
        Type = "CommonUI Simple Message",
        Message = new Message
        {
            Image = "https://cdn2.unrealengine.com/subgameselect-cr-512x1024-371f42541731.png",
            Hidden = false,
            MessageType = "normal",
            Type = "CommonUI Simple Message Base",
            Title = "New Featured Islands!",
            Body = "Your Island. Your Friends. Your Rules.\n\nDiscover new ways to play Fortnite, play community made games with friends and build your dream island.",
            Spotlight = false
        }
    };

    private static EmergencyNotice CreateEmergencyNotice(string isoNow) => new()
    {
        Title = "emergencynotice",
        ActiveDate = isoNow,
        LastModified = isoNow,
        Locale = "en-US",
        News = new EmergencyNoticeNews
        {
            Type = "Battle Royale News",
            Messages = new List<EmergencyNoticeMessages>
            {
                new()
                {
                    bHidden = false,
                    Type = "CommonUI Simple Message Base",
                    SubGame = "br",
                    Title = "Test",
                    Body = "TEST",
                    bSpotlight = true
                }
            }
        }
    };

    private static EmergencyNoticeV2 CreateEmergencyNoticeV2()
    {
        return new EmergencyNoticeV2
        {
            JcrIsCheckedOut = true,
            JcrBaseVersion = Guid.NewGuid().ToString(),
            Title = "emergencynoticev2",
            NoIndex = false,
            EmergencyNotices = new EmergencyNoticesContainer
            {
                Type = "Emergency Notices",
                Notices = new List<NoticeV2>
                {
                    new NoticeV2
                    {
                        GameModes = new List<string>(),
                        Hidden = false,
                        Type = "CommonUI Emergency Notice Base",
                        Title = "Crystal",
                        Body = "Welcome to Crystal! If you run into any bugs or issues, please report them in #reports.",
                        Spotlight = true
                    }
                }
            },
            AlwaysShow = false,
            ActiveDate = DateTime.Parse("2018-08-06T19:00:26.217Z"),
            LastModified = DateTime.Parse("2021-03-17T15:07:27.924Z"),
            Locale = "en-US"
        };
    }

    private static Lobby CreateLobby(DateTime now) => new()
    {
        BackgroundImage = "https://cdn2.unrealengine.com/Fortnite/fortnite-game/lobby/T_Lobby_SeasonX-2048x1024-24e02780ed533da8001016f4e6fb14dd15e2f860.png",
        Stage = "seasonx",
        Title = "lobby",
        ActiveDate = now,
        LastModified = now,
        Locale = "en-US"
    };

    private static DynamicBackgrounds CreateDynamicBackgrounds(string backgroundStage, DateTime now) => new()
    {
        Title = "dynamicbackgrounds",
        NoIndex = false,
        ActiveDate = now,
        LastModified = now,
        Locale = "en-US",
        Backgrounds = new BackgroundList
        {
            Type = "DynamicBackgroundList",
            Backgrounds = new List<Backgrounds>
            {
                new()
                {
                    Stage = backgroundStage,
                    Type = "DynamicBackground",
                    Key = "vault"
                },
                new()
                {
                    Stage = backgroundStage,
                    Type = "DynamicBackground",
                    Key = "lobby"
                }
            }
        }
    };

    private static BattleRoyaleNews CreateBattleRoyaleNews(DateTime now) => new()
    {
        Title = "battleroyalenews",
        Header = "",
        Style = "none",
        NoIndex = false,
        AlwaysShow = true,
        ActiveDate = now,
        LastModified = now,
        Locale = "en-US",
        TemplateName = "FortniteGameMOTD",
        News = new News
        {
            Type = "Battle Royale News",
            Messages = new List<object>(),
            Motds = new List<object>(),
            PlatformMessages = new List<object>()
        }
    };

    private static ShopSections CreateShopSections(string isoNow) => new()
    {
        Title = "shop-sections",
        SectionList = new ShopSectionList
        {
            Type = "ShopSectionList",
            Sections = new List<ShopSection>
            {
                CreateShopSection("Silver", "Diamond Diva", false),
                CreateShopSection("FlairSpecial", "Flair Special", false),
                CreateShopSection("Featured", "Featured", true),
                CreateShopSection("Daily", "Daily", false)
            }
        },
        NoIndex = false,
        ActiveDate = DateTime.Parse("2022-12-01T23:45:00.000Z"),
        LastModified = DateTime.Parse("2022-12-01T21:50:44.089Z"),
        Locale = "en-US",
        TemplateName = "FortniteGameShopSections"
    };

    private static ShopSection CreateShopSection(string sectionId, string displayName, bool showTimer)
    {
        return new ShopSection
        {
            SortOffersByOwnership = false,
            ShowIneligibleOffersIfGiftable = false,
            EnableToastNotification = true,
            Background = new DynamicBackground
            {
                Stage = "default",
                Type = "DynamicBackground",
                Key = "vault"
            },
            Type = "ShopSection",
            LandingPriority = 70,
            Hidden = false,
            SectionId = sectionId,
            ShowTimer = showTimer,
            SectionDisplayName = displayName,
            ShowIneligibleOffers = true
        };
    }

    private static BattleRoyaleNewsV2 CreateBattleRoyaleNewsV2(int season)
    {
        const string motdImage = "https://cdn.projecthelix.website/donatenewssize.png";

        return new BattleRoyaleNewsV2
        {
            Title = "battleroyalenewsv2",
            NoIndex = false,
            AlwaysShow = false,
            ActiveDate = DateTime.MaxValue,
            LastModified = DateTime.MaxValue,
            Locale = "en-US",
            TemplateName = "FortniteGameMOTD",
            News = new NewsV2
            {
                Type = "Battle Royale News v2",
                Motds = new List<object>
                {
                    new
                    {
                        entryType = "Website",
                        image = motdImage,
                        tileImage = motdImage,
                        videoMute = false,
                        hidden = false,
                        tabTitleOverride = "DONATIONS",
                        _type = "CommonUI Simple Message MOTD",
                        title = "DONATIONS",
                        body = "You can now donate to Crystal! Get Full Locker, Starter Pack, or OG Pack.",
                        videoLoop = false,
                        videoStreamingEnabled = false,
                        sortingPriority = 0,
                        id = "1",
                        videoAutoplay = false,
                        videoFullscreen = false,
                        spotlight = false,
                        websiteURL = "https://crystalmp.mysellauth.com/",
                        websiteButtonText = "Donate"
                    }
                }
            }
        };
    }
}