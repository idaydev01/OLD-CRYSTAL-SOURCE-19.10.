﻿using Discord;
using Helios.Classes.Launcher;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Database.Tables.Stats;
using Helios.Database.Tables.Tournaments;
using Helios.Database.Tables.XMPP;
using Helios.Services;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Launcher;
using Helios.Utilities.Profile;
using Helios.Utilities.Tokens;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Web;

namespace Helios.Controllers.Launcher.Launcher;

[ApiController]
[Route(("/h/d/v1"))]
public class LauncherController : ControllerBase
{
    private readonly HttpClient _client = new();
    private static readonly HashSet<string> DONATOR_ROLES = new()
    {
        "Donator", "OG Donator", "Owner", "Co Owner", "Admin",
        "Head Mod", "Mod", "Support", "Lead Support", "Manager", "Developer",
        "Content Creator", "Media Manager", "Crystal Donator", "Crystal Booster",
        "Founder", "Head Admin"
    };
    private static readonly HashSet<string> MAINTENANCE_BYPASS_ROLES = new()
    {
        "Owner", "Co Owner", "Manager"
    };

    [HttpGet("discord/callback")]
    public async Task<IActionResult> Callback()
    {
        try
        {
            var code = Request.Query["code"].ToString();

            if (string.IsNullOrEmpty(code))
            {
                var redirectUri = $"{Request.Scheme}://{Request.Host}/h/d/v1/discord/callback";
                var encodedRedirectUri = HttpUtility.UrlEncode(redirectUri);
                var discordAuthUrl = $"https://discord.com/oauth2/authorize?client_id={Constants.config.DiscordClientId}&response_type=code&redirect_uri={encodedRedirectUri}&scope=identify%20guilds.members.read";
                return Ok(discordAuthUrl);
            }

            string accessToken;
            try
            {
                var parameters = new Dictionary<string, string>
                {
                    { "client_id", Constants.config.DiscordClientId },
                    { "client_secret", Constants.config.DiscordClientSecret },
                    { "grant_type", "authorization_code" },
                    { "code", code },
                    { "redirect_uri", $"{Request.Scheme}://{Request.Host}/h/d/v1/discord/callback" },
                    { "scope", "identify guilds.members.read" }
                };

                using var content = new FormUrlEncodedContent(parameters);
                using var response = await _client.PostAsync("https://discord.com/api/v10/oauth2/token", content);
                var responseBody = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {

                    if (responseBody.Contains("invalid_grant"))
                    {
                        var redirectUri = $"{Request.Scheme}://{Request.Host}/h/d/v1/discord/callback";
                        var encodedRedirectUri = HttpUtility.UrlEncode(redirectUri);
                        var discordAuthUrl = $"https://discord.com/oauth2/authorize?client_id={Constants.config.DiscordClientId}&response_type=code&redirect_uri={encodedRedirectUri}&scope=identify%20guilds.members.read";
                        return Redirect(discordAuthUrl);
                    }

                    return BasicErrors.BadRequest.WithMessage("Authentication failed: Failed to exchange authorization code").Apply(HttpContext);
                }

                var tokenData = JObject.Parse(responseBody);
                accessToken = tokenData["access_token"]?.ToString();

                if (string.IsNullOrEmpty(accessToken))
                {
                    return BasicErrors.BadRequest.WithMessage("Authentication failed: No access token received").Apply(HttpContext);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Exception during token exchange: {ex.Message}");
                return BasicErrors.BadRequest.WithMessage("Authentication failed: Token exchange error").Apply(HttpContext);
            }

            JObject discordUser;
            try
            {
                using var request = new HttpRequestMessage(HttpMethod.Get, "https://discord.com/api/v10/users/@me");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                using var response = await _client.SendAsync(request);
                var responseBody = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    Logger.Error($"Discord user info request failed: {response.StatusCode} - {responseBody}");
                    return BasicErrors.BadRequest.WithMessage("Failed to get user information").Apply(HttpContext);
                }

                discordUser = JObject.Parse(responseBody);
            }
            catch (Exception ex)
            {
                Logger.Error($"Exception getting Discord user info: {ex.Message}");
                return BasicErrors.BadRequest.WithMessage("Failed to fetch user data").Apply(HttpContext);
            }

            var discordUserId = discordUser["id"]?.ToString();
            var discordUsername = discordUser["username"]?.ToString();

            if (string.IsNullOrEmpty(discordUserId))
            {
                return BasicErrors.BadRequest.WithMessage("Invalid Discord user ID").Apply(HttpContext);
            }

            string[] userRoles;
            try
            {
                userRoles = await GetUserRolesWithRetry(discordUserId, accessToken);
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to get user roles after all retries: {ex.Message}");
                userRoles = Array.Empty<string>();
            }

            if (Constants.config.Maintenance)
            {
                bool canBypassMaintenance = userRoles?.Any(role => MAINTENANCE_BYPASS_ROLES.Contains(role)) ?? false;

                if (!canBypassMaintenance)
                {
                    return Content(CrystalPageGenerator.GenerateErrorPage("Servers are currently in maintenance mode. Please try again later."), "text/html");
                }
            }

            var userRepository = Constants.repositoryPool.For<User>();
            var user = await userRepository.FindByColumnAsync("discordid", discordUserId, useCache: false);

            if (user == null)
            {
                try
                {
                    var originalUsername = discordUser["username"]?.ToString() ?? string.Empty;
                    var cleanedUsername = CleanUsername(originalUsername);

                    var encryptedEmail = HashAlgorithmGenerator.Generate(cleanedUsername, HashAlgorithmName.SHA1);
                    var (hashedPassword, salt) = PasswordHasher.HashPassword(cleanedUsername);

                    var avatar = discordUser["avatar"]?.ToString();

                    var avatarUrl = !string.IsNullOrEmpty(avatar)
                        ? $"https://cdn.discordapp.com/avatars/{discordUserId}/{avatar}"
                        : null;

                    var newUser = await UserRegistration.Register(new NewRegisteredUser
                    {
                        Email = $"{encryptedEmail}@crystal.dev",
                        Password = hashedPassword,
                        Username = cleanedUsername,
                        DiscordId = discordUserId,
                        IsServer = false,
                        Roles = userRoles,
                        Avatar = avatarUrl
                    });

                    if (!newUser.Success)
                    {
                        Logger.Error($"Failed to register user: {discordUsername}");
                        return BasicErrors.BadRequest.WithMessage("Failed to create user account").Apply(HttpContext);
                    }

                    user = await userRepository.FindByColumnAsync("discordid", discordUserId);
                    if (user == null)
                    {
                        return BasicErrors.BadRequest.WithMessage("Failed to retrieve newly created user").Apply(HttpContext);
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Exception creating user: {ex.Message}");
                    return BasicErrors.BadRequest.WithMessage("Failed to create user account").Apply(HttpContext);
                }
            }
            else
            {
                try
                {
                    var avatar = discordUser["avatar"]?.ToString();
                    var avatarUrl = !string.IsNullOrEmpty(avatar)
                        ? $"https://cdn.discordapp.com/avatars/{discordUserId}/{avatar}"
                        : user.Avatar;


                    bool needsUpdate = false;

                    if (!userRoles.SequenceEqual(user.Roles ?? Array.Empty<string>()))
                    {
                        user.Roles = userRoles;
                        needsUpdate = true;
                    }

                    if (user.Avatar != avatarUrl)
                    {
                        user.Avatar = avatarUrl;
                        needsUpdate = true;
                    }

                    if (needsUpdate)
                    {
                        await userRepository.UpdateAsync(user);
                        Logger.Info($"Updated user: {discordUsername} ({discordUserId})");
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Exception updating user: {ex.Message}");
                }
            }

            if (user.Banned)
            {
                return Content(CrystalPageGenerator.GenerateErrorPage(
                    "You are currently banned from Crystal. If this was a mistake, make a ticket in our support server."), "text/html");
            }

            var itemsRepository = Constants.repositoryPool.For<Items>();
            string favoriteCharacter;
            object athenaProfile;
            object commonCoreProfile;
            object userStats;

            try
            {
                var profileTasks = new Dictionary<string, Task<Items>>
                {
                    ["favoriteCharacter"] = itemsRepository.FindByColumnsAsync(new Dictionary<string, object>
                    {
                        { "accountid", user.AccountId },
                        { "templateid", "favorite_character" },
                        { "profileid", "athena" }
                    }),
                    ["level"] = itemsRepository.FindByColumnsAsync(new Dictionary<string, object>
                    {
                        { "accountid", user.AccountId },
                        { "templateid", "level" },
                        { "profileid", "athena" }
                    }),
                    ["xp"] = itemsRepository.FindByColumnsAsync(new Dictionary<string, object>
                    {
                        { "accountid", user.AccountId },
                        { "templateid", "xp" },
                        { "profileid", "athena" }
                    }),
                    ["bookPurchased"] = itemsRepository.FindByColumnsAsync(new Dictionary<string, object>
                    {
                        { "accountid", user.AccountId },
                        { "templateid", "book_purchased" },
                        { "profileid", "athena" }
                    }),
                    ["bookLevel"] = itemsRepository.FindByColumnsAsync(new Dictionary<string, object>
                    {
                        { "accountid", user.AccountId },
                        { "templateid", "book_level" },
                        { "profileid", "athena" }
                    }),
                    ["bookXp"] = itemsRepository.FindByColumnsAsync(new Dictionary<string, object>
                    {
                        { "accountid", user.AccountId },
                        { "templateid", "book_xp" },
                        { "profileid", "athena" }
                    }),
                    ["currency"] = itemsRepository.FindByColumnsAsync(new Dictionary<string, object>
                    {
                        { "accountid", user.AccountId },
                        { "templateid", "Currency:MtxPurchased" },
                        { "profileid", "common_core" }
                    })
                };

                await Task.WhenAll(profileTasks.Values);

                var loadoutsRepository = Constants.repositoryPool.For<Loadouts>();
                var loadout = await loadoutsRepository.FindByColumnsAsync(new Dictionary<string, object>
                {
                    { "accountid", user.AccountId },
                    { "profileid", "athena" },
                    { "templateid", "CosmeticLocker:cosmeticlocker_athena" }
                });
                if (loadout == null)
                    return BasicErrors.BadRequest.WithMessage("User loadouts not found").Apply(HttpContext);

                var favoriteCharacterItem = loadout.CharacterId;
                var favoriteCharacterValue = favoriteCharacterItem.ToString();
                if (string.IsNullOrWhiteSpace(favoriteCharacterValue))
                {
                    loadout.CharacterId = "AthenaCharacter:CID_002_Athena_Commando_F_Default";
                    await loadoutsRepository.UpdateAsync(loadout);
                }

                favoriteCharacter = favoriteCharacterValue.Trim('"').Replace("AthenaCharacter:", "").ToLower();
                var tournamentHypeRepository = Constants.repositoryPool.For<TournamentHype>();

                var hypeEntry = (await tournamentHypeRepository.FindAllByColumnsAsync(new Dictionary<string, object>
                {
                    { "accountid", user.AccountId },
                    { "season", Constants.CurrentVersion },
                    { "type", "NormalHype" }
                }))?.FirstOrDefault();

                int hype = hypeEntry?.Hype ?? 0;

                athenaProfile = new
                {
                    favoriteCharacterId = favoriteCharacter,
                    season = new
                    {
                        level = int.TryParse(profileTasks["level"].Result?.Value, out var level) ? level : 0,
                        xp = int.TryParse(profileTasks["xp"].Result?.Value, out var xp) ? xp : 0,
                        battlePass = new
                        {
                            purchased = bool.TryParse(profileTasks["bookPurchased"].Result?.Value, out var bookPurchased) && bookPurchased,
                            level = int.TryParse(profileTasks["bookLevel"].Result?.Value, out var bookLevel) ? bookLevel : 0,
                            xp = int.TryParse(profileTasks["bookXp"].Result?.Value, out var bookXp) ? bookXp : 0
                        }
                    },
                    hype
                };
                commonCoreProfile = new
                {
                    vbucks = int.TryParse(profileTasks["currency"].Result?.Value, out var vbucks) ? vbucks : 0
                };

                Stats[] allUserStats;
                try
                {
                    var statsRepository = Constants.repositoryPool.For<Stats>();
                    allUserStats = (await statsRepository.FindAllByColumnAsync("accountid", new[] { user.AccountId })).ToArray();
                }
                catch (Exception ex)
                {
                    Logger.Error($"Exception getting user stats: {ex.Message}");
                    allUserStats = Array.Empty<Stats>();
                }

                int totalWins = 0;
                int totalEliminations = 0;
                int totalMatchesPlayed = 0;

                foreach (var stat in allUserStats)
                {
                    totalMatchesPlayed += stat.MatchesPlayed;

                    try
                    {
                        var statValue = JObject.Parse(stat.Value);
                        totalWins += statValue["Wins"]?.Value<int>() ?? 0;
                        totalEliminations += statValue["Kills"]?.Value<int>() ?? 0;
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Error parsing stats for {stat.Type}: {ex.Message}");
                    }
                }

                double kd = totalMatchesPlayed > 0 ? Math.Round((double)totalEliminations / totalMatchesPlayed, 2) : 0.0;

                userStats = new
                {
                    kd,
                    wins = totalWins,
                    eliminations = totalEliminations,
                    matchesPlayed = totalMatchesPlayed
                };
            }
            catch (Exception ex)
            {
                Logger.Error($"Exception getting profile data: {ex.Message}");
                return BasicErrors.BadRequest.WithMessage("Failed to load profile data").Apply(HttpContext);
            }

            var claims = new List<Claim>
            {
                new Claim("id", user.AccountId),

                new Claim("discord", JsonConvert.SerializeObject(new
                {
                    id = user.DiscordId,
                    username = discordUsername,
                    displayName = user.Username,
                    avatarUrl = user.Avatar,
                    isDonator = user.Roles?.Any(role => DONATOR_ROLES.Contains(role)) ?? false
                })),
                new Claim("roles", JsonConvert.SerializeObject(new
                {
                    list = userRoles
                })),
                new Claim("profile", JsonConvert.SerializeObject(new
                {
                    athena = athenaProfile,
                    common_core = commonCoreProfile,
                    stats = userStats
                })),
                new Claim("hellowelcometocrystalfortnite", GenerateAccountSecret(user.AccountId, user.DiscordId)), 
            };

            var token = TokenGenerator.GenerateJwtToken(claims.ToArray(), 1, Constants.config.JWTClientSecret);

            if (Constants.config.isTesting)
            {
                bool hasEarlyAccess = HasEarlyAccess(userRoles, user);
                if (!hasEarlyAccess)
                {
                    return Content(CrystalPageGenerator.GenerateErrorPage(
                        "Crystal is currently in early access. You need to have a donator role or higher to access this. "), "text/html");
                }
            }

            bool isDonator = user.Roles.Contains("Donator");
            bool isCrystalDonator = user.Roles.Contains("Crystal Donator");
            bool isBooster = user.Roles.Contains("Crystal Booster");
            bool isOgDonator = user.Roles.Contains("OG Donator");

            bool isManager = user.Roles.Contains("Manager") || user.Roles.Contains("Admin") || user.Roles.Contains("Owner") || user.Roles.Contains("Co Owner");

            if (isDonator || isCrystalDonator || isManager)
            {
                await ProfileItemGranting.GrantAll(user.AccountId);
            }
            else
            {
                if (isBooster)
                    await ProfileItemGranting.GrantBoosterItems(user.AccountId);
                if (isOgDonator)
                    await ProfileItemGranting.GrantOgDonatorItems(user.AccountId);
            }

            Logger.Info($"Successfully authenticated user {discordUsername} ({discordUserId})");
            return Content(CrystalPageGenerator.GenerateSuccessPage(
                user.Username,
                user.DiscordId,
                favoriteCharacter,
                token), "text/html");
        }
        catch (Exception ex)
        {
            Logger.Error($"Unexpected error in Discord callback: {ex.Message}");
            return BasicErrors.BadRequest.WithMessage("An unexpected error occurred during authentication").Apply(HttpContext);
        }
    }

    private async Task<string[]> GetUserRolesWithRetry(string discordUserId, string accessToken, int maxRetries = 3)
    {
        for (int attempt = 1; attempt <= maxRetries; attempt++)
        {
            try
            {
                var guildId = Constants.config.DiscordGuildId;
                var endpoint = $"https://discord.com/api/v10/guilds/{guildId}/members/{discordUserId}";

                using var request = new HttpRequestMessage(HttpMethod.Get, endpoint);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bot", Constants.config.DiscordBotToken);

                using var response = await _client.SendAsync(request);

                if (response.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
                {
                    var retryAfter = response.Headers.RetryAfter?.Delta ?? TimeSpan.FromSeconds(5);
                    Logger.Warn($"Rate limited on attempt {attempt}, waiting {retryAfter.TotalSeconds}s");
                    await Task.Delay(retryAfter);
                    continue;
                }

                if (!response.IsSuccessStatusCode)
                {
                    if (attempt == maxRetries)
                    {
                        return await TryGetRolesViaUserToken(discordUserId, accessToken);
                    }

                    await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, attempt)));
                    continue;
                }

                var responseBody = await response.Content.ReadAsStringAsync();
                var memberData = JObject.Parse(responseBody);
                var roleIds = memberData["roles"]?.ToObject<List<string>>() ?? new List<string>();

                if (roleIds.Count == 0)
                {
                    Logger.Warn($"No roles found for user {discordUserId} on attempt {attempt}");
                    if (attempt < maxRetries)
                    {
                        await Task.Delay(TimeSpan.FromSeconds(2));
                        continue;
                    }
                }

                var roleNames = await GetRoleNames(guildId, roleIds);

                return roleNames;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error getting user roles on attempt {attempt}: {ex.Message}");
                if (attempt == maxRetries)
                {
                    throw;
                }
                await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, attempt)));
            }
        }

        return Array.Empty<string>();
    }

    private async Task<string[]> TryGetRolesViaUserToken(string discordUserId, string accessToken)
    {
        try
        {
            var guildId = Constants.config.DiscordGuildId;
            var endpoint = $"https://discord.com/api/v10/users/@me/guilds/{guildId}/member";

            using var request = new HttpRequestMessage(HttpMethod.Get, endpoint);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            using var response = await _client.SendAsync(request);

            if (!response.IsSuccessStatusCode)
            {
                return Array.Empty<string>();
            }

            var responseBody = await response.Content.ReadAsStringAsync();
            var memberData = JObject.Parse(responseBody);
            var roleIds = memberData["roles"]?.ToObject<List<string>>() ?? new List<string>();

            return await GetRoleNames(guildId, roleIds);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error getting roles via user token: {ex.Message}");
            return Array.Empty<string>();
        }
    }

    private async Task<string[]> GetRoleNames(string guildId, List<string> roleIds)
    {
        if (roleIds.Count == 0) return Array.Empty<string>();

        try
        {
            var rolesEndpoint = $"https://discord.com/api/v10/guilds/{guildId}/roles";
            using var rolesRequest = new HttpRequestMessage(HttpMethod.Get, rolesEndpoint);
            rolesRequest.Headers.Authorization = new AuthenticationHeaderValue("Bot", Constants.config.DiscordBotToken);

            using var rolesResponse = await _client.SendAsync(rolesRequest);
            if (!rolesResponse.IsSuccessStatusCode)
            {
                Logger.Error($"Failed to get guild roles: {rolesResponse.StatusCode}");
                return Array.Empty<string>();
            }

            var rolesBody = await rolesResponse.Content.ReadAsStringAsync();
            var roles = JArray.Parse(rolesBody);
            var roleNames = new List<string>();

            foreach (var role in roles)
            {
                var roleId = role["id"]?.ToString();
                var roleName = role["name"]?.ToString();

                if (roleIds.Contains(roleId) && !string.IsNullOrEmpty(roleName))
                {
                    roleNames.Add(roleName);
                }
            }

            return roleNames.ToArray();
        }
        catch (Exception ex)
        {
            Logger.Error($"Error getting role names: {ex.Message}");
            return Array.Empty<string>();
        }
    }

    private bool HasEarlyAccess(string[] userRoles, User existingUser = null)
    {
        bool hasAccessRole = userRoles?.Any(role =>
            DONATOR_ROLES.Contains(role, StringComparer.OrdinalIgnoreCase)) ?? false;

        if (hasAccessRole)
        {
            return true;
        }

        if (existingUser?.Roles != null)
        {
            bool hasStoredAccessRole = existingUser.Roles.Any(role =>
                DONATOR_ROLES.Contains(role, StringComparer.OrdinalIgnoreCase));

            if (hasStoredAccessRole)
            {
                return true;
            }
        }

        return false;
    }

    private static string CleanUsername(string username)
    {
        if (string.IsNullOrEmpty(username)) return string.Empty;

        var cleanedUsername = username.Replace(".", "").Replace("_", "");

        if (cleanedUsername.Length > 16)
            cleanedUsername = cleanedUsername.Substring(0, 12);

        return cleanedUsername;
    }

    public static string GenerateAccountSecret(string accountId, string discordId)
    {
        var combined = $"{accountId}:{discordId}:{Constants.config.JWTClientSecret}";
        using (var sha256 = SHA256.Create())
        {
            var hashBytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(combined));
            return Convert.ToBase64String(hashBytes);
        }
    }


    [HttpPost("auth/exchange/create")]
    public async Task<IActionResult> CreateExchangeCode()
    {
        var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
        if (apiKey != Constants.ValidApiKey)
            return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);

        string requestBody = await new StreamReader(Request.Body).ReadToEndAsync();
        JObject requestData;

        try
        {
            requestData = JObject.Parse(requestBody);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        var secret = requestData["crystal"]?.ToString();
        if (string.IsNullOrWhiteSpace(secret))
            return Ok(new { error = "this endpoint is deprecated." });

        try
        {
            var userRepository = Constants.repositoryPool.For<User>();
            var tokensRepository = Constants.repositoryPool.For<Tokens>();
            var launcherSessionsRepository = Constants.repositoryPool.For<LauncherSessions>();

            var launcherSession = await launcherSessionsRepository.FindByColumnAsync("secret", secret);
            if (launcherSession is null)
                return Ok(new { error = "this endpoint is deprecated." });

            var user = await userRepository.FindByColumnAsync("accountid", launcherSession.AccountId);
            if (user is null)
                return Ok(new { error = "this endpoint is deprecated." });

            if (user.Banned)
                return AccountErrors.DisabledAccount.WithMessage($"You are currently banned from Crystal. If this was a mistake, make a ticket in our support server.").Apply(HttpContext);

            await tokensRepository.DeleteAsync(new Tokens
            {
                AccountId = user.AccountId,
                Type = "exchange"
            });

            var exchangeCode = Guid.NewGuid().ToString();
            await tokensRepository.SaveAsync(new Tokens
            {
                Type = "exchange",
                AccountId = user.AccountId,
                Token = exchangeCode
            });

            return Ok(new { code = exchangeCode });
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to create exchange code: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }
}