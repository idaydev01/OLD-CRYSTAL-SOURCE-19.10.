﻿using System.Text.Json;
using Helios.Configuration;
using Helios.Database.Tables.Solstice;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Microsoft.AspNetCore.Mvc;

namespace Helios.Controllers.Solstice;

[ApiController]
[Route("/solstice/api/v1/matchmaking/")]
public class SolsticeMatchmakingController : ControllerBase
{
    [HttpPost("start")]
    public async Task<IActionResult> StartSession()
    {
        var servers = Constants.repositoryPool.For<SolsticeServers>();
        JsonDocument requestData;

        try
        {
            requestData = await JsonDocument.ParseAsync(Request.Body);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        using (requestData)
        {
            var root = requestData.RootElement;

            if (!root.TryGetProperty("sessionId", out var sessionIdElement))
                return BasicErrors.BadRequest.WithMessage("Missing sessionId.").Apply(HttpContext);

            string sessionId = sessionIdElement.GetString();
            if (string.IsNullOrEmpty(sessionId))
                return BasicErrors.BadRequest.WithMessage("sessionId cannot be empty.").Apply(HttpContext);

            var existingServer = await servers.FindByColumnAsync("sessionid", sessionId);
            if (existingServer == null)
                return MatchmakingErrors.UnknownSession
                    .WithMessage($"Server with sessionId '{sessionId}' not found.").Apply(HttpContext);

            existingServer.MatchStarted = true;
            existingServer.Status = "STATUS_INGAME";
            existingServer.UpdatedAt = DateTime.Now;

            await servers.UpdateAsync(existingServer);

            Logger.Debug($"Server started: {existingServer.SessionId} region {existingServer.Region}");

            return NoContent();
        }
    }

    [HttpPost("stop")]
    public async Task<IActionResult> StopSession()
    {
        var servers = Constants.repositoryPool.For<SolsticeServers>();
        JsonDocument requestData;

        try
        {
            requestData = await JsonDocument.ParseAsync(Request.Body);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        using (requestData)
        {
            var root = requestData.RootElement;

            if (!root.TryGetProperty("sessionId", out var sessionIdElement))
                return BasicErrors.BadRequest.WithMessage("Missing sessionId.").Apply(HttpContext);

            string sessionId = sessionIdElement.GetString();
            if (string.IsNullOrEmpty(sessionId))
                return BasicErrors.BadRequest.WithMessage("sessionId cannot be empty.").Apply(HttpContext);

            var existingServer = await servers.FindByColumnAsync("sessionid", sessionId);
            if (existingServer == null)
                return MatchmakingErrors.UnknownSession
                    .WithMessage($"Server with sessionId '{sessionId}' not found.").Apply(HttpContext);

            existingServer.MatchStarted = false;
            existingServer.Status = "offline";
            existingServer.UpdatedAt = DateTime.Now;

            await servers.UpdateAsync(existingServer);

            return NoContent();
        }
    }

    [HttpPost("start/by-address")]
    public async Task<IActionResult> StartByAddress()
    {
        var servers = Constants.repositoryPool.For<SolsticeServers>();
        JsonDocument requestData;

        try
        {
            requestData = await JsonDocument.ParseAsync(Request.Body);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        using (requestData)
        {
            var root = requestData.RootElement;

            if (!root.TryGetProperty("ipAddress", out var ipElement) ||
                !root.TryGetProperty("port", out var portElement))
                return BasicErrors.BadRequest.WithMessage("Missing ipAddress or port.").Apply(HttpContext);

            var ipAddress = ipElement.GetString();
            var port = portElement.GetInt32();

            var existingServer = await servers.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "address", ipAddress },
                { "port", port }
            });

            if (existingServer == null)
                return MatchmakingErrors.UnknownSession
                    .WithMessage($"Server with IP '{ipAddress}' and Port '{port}' not found.").Apply(HttpContext);

            existingServer.MatchStarted = true;
            existingServer.Status = "STATUS_INGAME";
            existingServer.UpdatedAt = DateTime.Now;

            await servers.UpdateAsync(existingServer);

            Logger.Debug($"Server started: {existingServer.SessionId} ({ipAddress}:{port})");

            return NoContent();
        }
    }

    [HttpPost("stop/by-address")]
    public async Task<IActionResult> StopByAddress()
    {
        var servers = Constants.repositoryPool.For<SolsticeServers>();
        JsonDocument requestData;

        try
        {
            requestData = await JsonDocument.ParseAsync(Request.Body);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        using (requestData)
        {
            var root = requestData.RootElement;

            if (!root.TryGetProperty("ipAddress", out var ipElement) ||
                !root.TryGetProperty("port", out var portElement))
                return BasicErrors.BadRequest.WithMessage("Missing ipAddress or port.").Apply(HttpContext);

            var ipAddress = ipElement.GetString();
            var port = portElement.GetInt32();

            var existingServer = await servers.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "address", ipAddress },
                { "port", port }
            });

            if (existingServer == null)
                return MatchmakingErrors.UnknownSession
                    .WithMessage($"Server with IP '{ipAddress}' and Port '{port}' not found.").Apply(HttpContext);

            existingServer.MatchStarted = false;
            existingServer.Status = "offline";
            existingServer.UpdatedAt = DateTime.Now;

            await servers.UpdateAsync(existingServer);

            Logger.Debug($"Server stopped: {existingServer.SessionId} ({ipAddress}:{port})");

            return NoContent();
        }
    }
}
