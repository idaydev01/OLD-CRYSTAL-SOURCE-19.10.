﻿using Helios.Classes.GameSessions;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Managers;
using Helios.Services;
using Helios.Utilities;
using Helios.Utilities.Caching;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using static Org.BouncyCastle.Math.EC.ECCurve;
using static System.Runtime.InteropServices.JavaScript.JSType;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace Helios.Controllers.Matchmaking;

[ApiController]
[Route("/fortnite/api/game/v2/matchmakingservice/")]
public class MatchmakingServiceController : ControllerBase
{
    private const string SessionCachePrefix = "matchmaking_session_";
    private string GetSessionCacheKey(string sessionId) => $"{SessionCachePrefix}{sessionId}";
    private readonly TimeSpan _sessionTimeout = TimeSpan.FromMinutes(10);

    [HttpGet("ticket/player/{accountId}")]
    [VerifyToken]
    public async Task<IActionResult> MatchmakingTicket(string accountId)
    {
        string route = Constants.ExtractSanitiztedRoute(Request.Path);

        if (!Request.Headers.TryGetValue("User-Agent", out var userAgent) || string.IsNullOrWhiteSpace(userAgent))
            return InternalErrors.InvalidUserAgent.Apply(HttpContext);

        var userAgentInfo = await UserAgentParser.ParseAsync(userAgent);
        if (userAgentInfo == null)
            return InternalErrors.InvalidUserAgent.WithMessage("Failed to parse User-Agent.").Apply(HttpContext);

        if (!Request.Headers.TryGetValue("Authorization", out var authHeader) || string.IsNullOrWhiteSpace(authHeader))
            return AuthenticationErrors.AuthenticationFailed(route).Apply(HttpContext);

        string accessToken = authHeader.ToString().Trim();

        if (accessToken.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            accessToken = accessToken.Substring("Bearer ".Length);
        if (accessToken.StartsWith("eg1~"))
            accessToken = accessToken.Substring("eg1~".Length);

        if (accessToken.Count(c => c == '.') != 2)
        {
            Logger.Error($"Malformed token received: {accessToken}");
            return AuthenticationErrors.InvalidToken("Malformed accessToken").Apply(HttpContext);
        }

        var userRepository = Constants.repositoryPool.For<User>();
        var user = await userRepository.FindByColumnAsync("accountid", accountId);
        if (user == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found").Apply(HttpContext);

        if (user.Banned)
            return AccountErrors.DisabledAccount.Apply(HttpContext);

        #if !DEBUG
            if (!user.Ac)
                return AntiCheatErrors.NotLoggedIntoAnticheat.Apply(HttpContext);
        #endif

        if (!Request.Query.TryGetValue("bucketId", out var bucketId) || string.IsNullOrWhiteSpace(bucketId))
            return MatchmakingErrors.InvalidBucketId.WithMessage("Missing or invalid bucket ID.").Apply(HttpContext);

        var bucketParts = bucketId.ToString().Split(":");
        if (bucketParts.Length != 4)
            return MatchmakingErrors.InvalidBucketId.WithMessage("Invalid bucket ID format.").Apply(HttpContext);

        var region = bucketParts[2];
        var playlist = bucketParts[3];
        if (string.IsNullOrWhiteSpace(region) || string.IsNullOrWhiteSpace(playlist))
            return MatchmakingErrors.InvalidBucketId.WithMessage("Region or playlist is missing in bucket ID.").Apply(HttpContext);

        var partyPlayerIds = Request.Query["partyPlayerIds"].ToString();
        if (string.IsNullOrWhiteSpace(partyPlayerIds))
            return MatchmakingErrors.InvalidPartyPlayers.Apply(HttpContext);

        var subRegions = Request.Query["player.subregions"].ToString().Split(',').FirstOrDefault()?.Trim() ?? "default";
        var input = Request.Query["player.input"].ToString().Trim();
        var inputType = Request.Query["player.inputTypes"].ToString().Trim();
        var platform = Request.Query["player.platform"].ToString().Trim();
        var customKey = Request.Query["player.option.customKey"].ToString().Trim();

        if (string.IsNullOrWhiteSpace(platform))
            return MatchmakingErrors.InvalidPlatform.Apply(HttpContext);

        var (partyId, members, leadershipAccountId) = Constants.GlobalPartyManagerService.GetUserPartyInfo(user.AccountId);
        string bIsFill = Request.Query["player.option.fillTeam"].ToString();

        Logger.Debug($"Captain ID: {leadershipAccountId}");

        string leaderRegion = region;
        if (members != null && members.Count > 0)
        {
            var leader = members.FirstOrDefault(m => m == leadershipAccountId);
            if (leader != null && !string.IsNullOrWhiteSpace(leader))
            {
                leaderRegion = region;
            }
        }

        var leadership = new Dictionary<string, object>();

        foreach (var member in members)
        {
            leadership[member] = new
            {
                region,
                hasLeadership = member == leadershipAccountId
            };
        }

        var payload = new
        {
            playerId = user.AccountId,
            partyPlayerId = partyPlayerIds,
            bucketId,
            attributes = new Dictionary<string, object>
            {
                { "player.userAgent", userAgent },
                { "player.preferredSubregion", subRegions },
                { "player.option.spectator", "false" },
                { "player.inputTypes", inputType },
                { "player.revision", Request.Query["player.revision"].ToString() },
                { "player.teamFormat", "fun" },
                { "player.subregions", region },
                { "player.season", userAgentInfo.Season },
                { "player.platform", platform },
                { "player.option.linkType", "DEFAULT" },
                { "player.input", input },
                { "playlist.revision", Request.Query["playlist.revision"].ToString() },
                { "player.option.fillTeam", bIsFill },
                { "player.option.uiLanguage", "en" },
                { "player.option.microphoneEnabled", Request.Query["player.option.microphoneEnabled"].ToString() }
            },
            expiresAt = DateTime.UtcNow.AddHours(32).ToIsoUtcString(),
            none = Guid.NewGuid().ToString()
        };

        var attributesJson = JsonConvert.SerializeObject(payload.attributes);
        var signaturePayload = new Dictionary<string, object>
        {
            { "accountId", user.AccountId },
            { "bucketId", bucketId },
            { "attributes", JsonConvert.DeserializeObject<Dictionary<string, object>>(attributesJson) },
            { "expiresAt", payload.expiresAt },
            { "none", payload.none },
            { "sessionId", Guid.NewGuid().ToString() },
            { "matchId", Guid.NewGuid().ToString() },
            { "region", region },
            { "userAgent", userAgent },
            { "playlist", playlist },
            { "partyMembers", partyPlayerIds },
            { "type", !string.IsNullOrEmpty(customKey) ? "rented" : "default" },
            { "customKey", !string.IsNullOrEmpty(customKey) ? customKey : "NO_KEY" },
            { "isFill", bIsFill },
            { "leadership", JsonConvert.SerializeObject(leadership) }
        };


        var responsePayload = JsonConvert.SerializeObject(payload);

        return Ok(new
        {
            serviceUrl =
#if DEBUG
        "ws://127.0.0.1:2053",
#else
        "ws://185.206.149.110:2053",
#endif
            ticketType = "Solstice",
            payload = responsePayload,
            signature = JsonWebTokenService.GenerateJwt(signaturePayload, Constants.config.JWTClientSecret)
        });

    }

    [HttpGet("ticket/session/{sessionId}")]
    //[VerifyToken]
    public async Task<IActionResult> GetSessionTicket(string sessionId)
    {
        var partyPlayerIds = Request.Query["partyPlayerIds"].ToString();
        var bucketIdParts = Request.Query["bucketIds"].ToString().Split(':');
        var timestamp = DateTime.UtcNow.ToIsoUtcString();
        var cacheKey = GetSessionCacheKey(sessionId);

        if (!HeliosFastCache.TryGet<MatchmakingSession>(cacheKey, out var cachedSession))
        {
            Logger.Warn($"Session {sessionId} not found in cache at {timestamp}.");
            return MatchmakingErrors.UnknownSession
                .WithMessage($"Server by sessionId '{sessionId}' does not exist.")
                .Apply(HttpContext);
        }

        var playlistResponse = await ServerManager.GetPlaylistByRegion(bucketIdParts[2]);
        if (string.IsNullOrWhiteSpace(playlistResponse.Playlist))
            return BasicErrors.BadRequest
                .WithMessage("Failed to select a playlist.")
                .Apply(HttpContext);

        var selectedPlaylist = playlistResponse.Playlist;
        Logger.Info($"Selected playlist: {selectedPlaylist}");

        var finalListOfBucketIds = string.Join(":", bucketIdParts[0], bucketIdParts[1], bucketIdParts[2], selectedPlaylist);

        HeliosFastCache.Set(cacheKey, cachedSession, _sessionTimeout);

        var userAgent = Request.Headers["User-Agent"].ToString();
        if (string.IsNullOrWhiteSpace(userAgent))
            return InternalErrors.InvalidUserAgent.Apply(HttpContext);

        var userAgentInfo = UserAgentParser.Parse(userAgent);

        var signaturePayload = new Dictionary<string, object>
        {
            { "bucketIds", finalListOfBucketIds },
            { "partyMembers", partyPlayerIds },
            { "playlist", selectedPlaylist },
            { "buildUniqueId", bucketIdParts[0] },
            { "region", bucketIdParts[2] },
            { "ownerId", cachedSession.OwnerId },
            { "serverAddress", cachedSession.ServerAddress },
            { "serverPort", cachedSession.ServerPort }
        };

        Logger.Info($"Server SessionId [TICKET]: {sessionId}");

        var signature = JsonWebTokenService.GenerateJwt(signaturePayload, Constants.config.JWTClientSecret);

        // "ws://185.206.149.110:666
        return Ok(new
        {
            serviceUrl =
#if DEBUG
        "ws://127.0.0.1:666",
#else
        "ws://185.206.149.110:666",
#endif
            ticketType = "Solstice",
            payload = JsonConvert.SerializeObject(sessionId),
            signature
        });
    }
}