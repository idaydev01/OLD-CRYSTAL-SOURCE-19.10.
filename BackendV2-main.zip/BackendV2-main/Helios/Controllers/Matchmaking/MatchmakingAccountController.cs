﻿using Helios.Classes.MatchmakingServers;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Solstice;
using Helios.Managers;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;

namespace Helios.Controllers.Matchmaking;

[ApiController]
[Route("/fortnite/api/game/v2/matchmaking/account/{accountId}/session")]
public class MatchmakingAccountController : ControllerBase
{
    [HttpGet("{sessionId}")]
    [VerifyToken]
    public async Task<IActionResult> GetMatchmakingAccount(string accountId, string sessionId)
    {
        var userRepository = Constants.repositoryPool.For<User>();
        
        var user = await userRepository.FindByColumnAsync("accountid", accountId);

        if (user == null)
            return AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found").Apply(HttpContext);
        if (user.Banned)
            return AccountErrors.DisabledAccount.Apply(HttpContext);

        Servers session = await ServerManager.GetServerBySessionIdAsync(sessionId);

        if (session == null)
            return MatchmakingErrors.UnknownSession
                .WithMessage($"Server by sessionId '{sessionId}' does not exist.").Apply(HttpContext);

        return Ok(new
        {
            accountId = user.AccountId,
            sessionId = session.SessionId,
            key = "none"
        });
    }
}