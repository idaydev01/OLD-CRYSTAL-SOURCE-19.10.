﻿using Helios.Classes.GameSessions;
using Helios.Classes.MatchmakingServers;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Solstice;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Caching;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Middleware.Attributes;
using Helios.Utilities.Tokens;
using Helios.Sockets.IgnisClient; 
using Microsoft.AspNetCore.Mvc;
using System.Numerics;
using System.Security.Claims;
using System.Text.Json;
using Newtonsoft.Json;

namespace Helios.Controllers.Matchmaking;

[ApiController]
[Route("/fortnite/api/matchmaking/")]
public class MatchmakingController : ControllerBase
{
    private readonly TimeSpan _sessionTimeout = TimeSpan.FromMinutes(10);
    private const string SessionCachePrefix = "matchmaking_session_";
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = true
    };

    private readonly ConnectionManager _connectionManager;

    public MatchmakingController()
    {
        _connectionManager = new ConnectionManager();
    }

    [HttpPost("session/{sessionId}/join")]
    public async Task<IActionResult> JoinSession(string sessionId)
    {
        return Ok();
    }

    [HttpGet("session/{sessionId}")]
    [VerifyToken]
    public async Task<IActionResult> GetSession(string sessionId)
    {
        var userRepository = Constants.repositoryPool.For<User>();
        if (!Request.Headers.TryGetValue("Authorization", out var authHeader) || string.IsNullOrEmpty(authHeader))
            return AuthenticationErrors.AuthenticationFailed(Constants.ExtractSanitiztedRoute(Request.Path))
                .AddVariables([authHeader.ToString()])
                .Apply(HttpContext);

        if (!Request.Headers.TryGetValue("User-Agent", out var userAgent) || string.IsNullOrEmpty(userAgent))
            return InternalErrors.InvalidUserAgent.Apply(HttpContext);

        var uaParser = UserAgentParser.Parse(userAgent);

        string token = authHeader.ToString().Trim();

        if (token.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            token = token.Substring("Bearer ".Length);
        if (token.StartsWith("eg1~"))
            token = token.Substring("eg1~".Length);

        if (token.Count(c => c == '.') != 2)
        {
            Logger.Error($"Malformed token received: {token}");
            return AuthenticationErrors.InvalidToken("Malformed token").Apply(HttpContext);
        }

        string accountId;
        try
        {
            var decodedToken = TokenGenerator.DecodeToken(token);
            if (decodedToken == null)
            {
                return AuthenticationErrors.InvalidToken("Failed to decode token").Apply(HttpContext);
            }

            accountId = decodedToken["sub"] as string;
            if (string.IsNullOrEmpty(accountId))
            {
                return AuthenticationErrors.InvalidToken("Missing subject in token").Apply(HttpContext);
            }
        }
        catch (Exception ex)
        {
            Logger.Error("Token decoding error", ex);
            return AuthenticationErrors.InvalidToken("Failed to decode token").Apply(HttpContext);
        }

        var user = await userRepository.FindByColumnAsync("accountid", accountId);

        if (user == null)
        {
            return AccountErrors.AccountNotFound(accountId)
                .WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);
        }

        if (user.Banned)
        {
            return AccountErrors.DisabledAccount.Apply(HttpContext);
        }

        Servers? server = await ServerManager.GetServerBySessionIdAsync(sessionId);

        if (server == null)
            return MatchmakingErrors.UnknownSession
                .WithMessage($"Server by sessionId '{sessionId}' does not exist.").Apply(HttpContext);

        if (uaParser.Season >= 23)
        {
            var tokenRepository = Constants.repositoryPool.For<Tokens>();

            var claims = new List<Claim>
            {
                new Claim("productId", "prod-fn"),
                new Claim("iss", "fnmcp"),
                new Claim("env", "prod"),
                new Claim("nonce", "nTPbvdnW9DBYp4USUnes8v7NCgr4GQRS"),
                new Claim("fnAppId", "Fortnite"),
                new Claim("organizationId", "o-aa83a0a9bc45e98c80c1b1c9d92e9e"),
                new Claim("productUserId", "00021c6e5a3e42cdbbdf174562fd6afc"),
                new Claim("organizationUserId", "0001103f1a9b43b1a5a3defb29deaffb"),
                new Claim("deploymentId", "62a9473a2dca46b29ccf17577fcf42d7"),
                new Claim("sandboxId", "fn"),
                new Claim("tokenType", "gameSession"),

                new Claim("account.idp", "epicgames"),
                new Claim("account.id", accountId),
                new Claim("account.plf", "other"),

                new Claim("gameSession.dsIp", server.Address),
                new Claim("gameSession.id", server.SessionId),

                new Claim("jti", Guid.NewGuid().ToString("N").ToUpper()),
            };

            string gameSessionToken = TokenGenerator.GenerateJwtToken(
                claims.ToArray(),
                1,
                Constants.config.JWTClientSecret
            );

            await tokenRepository.SaveAsync(new Tokens
            {
                Type = "gamesession",
                AccountId = accountId,
                Token = gameSessionToken
            });
        }


        bool allowJoinInProgress = server?.Playlist?.ToLower().Contains("playgroundv2") ?? false;

        var sessionKey = Guid.NewGuid().ToString().ToUpper();
        var ownerId = Guid.NewGuid().ToString();

        int actualTotalPlayers = server.Clients;

        return Ok(new
        {
            id = server.SessionId,
            ownerId,
            ownerName = "[DS]fortnite-liveeugcec1c2e30ubrcore0a-z8hj-1968",
            serverName = "[DS]fortnite-liveeugcec1c2e30ubrcore0a-z8hj-1968",
            serverAddress = server.Address,
            serverPort = server.Port,
            maxPublicPlayers = 220,
            openPublicPlayers = 175,
            maxPrivatePlayers = 0,
            openPrivatePlayers = 0,
            attributes = new
            {
                REGION_s = server?.Region ?? "Unknown",
                GAMEMODE_s = "FORTATHENA",
                ALLOWBROADCASTING_b = true,
                SUBREGION_s = "GB",
                DCID_s = "FORTNITE-LIVEEUGCEC1C2E30UBRCORE0A-14840880",
                MATCHMAKINGPOOL_s = "Any",
                STORMSHIELDDEFENSETYPE_i = 0,
                HOTFIXVERSION_i = 0,
                PLAYLISTNAME_s = server?.Playlist ?? "Default",
                SESSIONKEY_s = sessionKey,
                TENANT_s = "Fortnite",
                BEACONPORT_i = 15009
            },
            publicPlayers = new List<string>(),
            privatePlayers = new List<string>(),
            totalPlayers = actualTotalPlayers,
            allowJoinInProgress = allowJoinInProgress,
            shouldAdvertise = false,
            isDedicated = false,
            usesStats = false,
            allowInvites = true,
            usesPresence = false,
            allowJoinViaPresence = true,
            allowJoinViaPresenceFriendsOnly = false,
            buildUniqueId = int.Parse(server.BucketId),
            lastUpdated = DateTime.UtcNow.ToIsoUtcString(),
            started = false
        });
    }

    [HttpGet("session/findPlayer/{accountId}")]
    public IActionResult SessionFindPlayer(string accountId)
    {
        return Ok();
    }

    private async Task<T?> DeserializeRequestBody<T>()
    {
        try
        {
            using var reader = new StreamReader(Request.Body);
            var bodyText = await reader.ReadToEndAsync();
            return string.IsNullOrWhiteSpace(bodyText) ? default : System.Text.Json.JsonSerializer.Deserialize<T>(bodyText, JsonOptions);
        }
        catch (System.Text.Json.JsonException)
        {
            return default;
        }
    }

    private string GetSessionCacheKey(string sessionId) => $"{SessionCachePrefix}{sessionId}";

    private async Task BroadcastServerUpdate(string action, string sessionId)
    {
        try
        {
            if (_connectionManager == null) return;

            var sessions = HeliosFastCache.GetByPrefix<MatchmakingSession>("matchmaking_session_")?.Values
                ?.Where(s => s.IsDedicated &&
                             !string.IsNullOrEmpty(s.SessionId) &&
                             s.Attributes?.ContainsKey("PLAYLISTNAME_s") == true &&
                             s.MaxPublicPlayers > 0 &&
                             (s.PublicPlayers?.Count ?? 0) > 0)
                .ToList() ?? new List<MatchmakingSession>();

            foreach (var session in sessions)
            {
                Console.WriteLine(JsonConvert.SerializeObject(session, Formatting.Indented));
                Console.WriteLine(JsonConvert.SerializeObject(session.Attributes, Formatting.Indented));

                var test = ServerManager.GetDedicatedServerBySessionIdAsync(session.SessionId);
                Console.WriteLine(JsonConvert.SerializeObject(test, Formatting.Indented));
            }

            var data = sessions.Select(s => new
            {
                Players = Math.Max(0, s.PublicPlayers?.Count ?? 0),
                SessionId = s.SessionId,
                Playlist = s.Attributes?.GetValueOrDefault("PLAYLISTNAME_s")?.ToString() ?? "",
                CapPlayers = s.MaxPublicPlayers > 0 ? s.MaxPublicPlayers : 50,
                Started = s.Started,
                Region = s.Attributes?.GetValueOrDefault("REGION_s")?.ToString() ?? ""
            }).OrderByDescending(s => s.Players);

            var message = new
            {
                type = "servers_update",
                action, // "created", "updated", "deleted"
                sessionId,
                timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                payload = new { data }
            };

            await _connectionManager.BroadcastToLauncherClients(JsonConvert.SerializeObject(message));
        }
        catch (Exception ex)
        {
            Logger.Error($"Error broadcasting server update: {ex.Message}");
        }
    }

    [HttpPost("session")]
    [VerifyToken]
    public async Task<IActionResult> CreateSession()
    {
        var timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
        var sessionObj = System.Text.Json.JsonSerializer.Deserialize<MatchmakingSession>(await new StreamReader(Request.Body).ReadToEndAsync());

        if (sessionObj == null)
        {
            Logger.Warn($"Failed to deserialize request body at {timestamp}: Invalid session data.");
            return BasicErrors.BadRequest
                            .WithMessage("Invalid request body format.")
                            .Apply(HttpContext);
        }

        var sessionId = Guid.NewGuid().ToString();
        var attributesJson = sessionObj.Attributes is string ? sessionObj.Attributes.ToString() : System.Text.Json.JsonSerializer.Serialize(sessionObj.Attributes, JsonOptions);
        var attributes = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, object>>(attributesJson);

        if (sessionObj != null)
        {
            sessionObj.LastUpdated = timestamp;
            sessionObj.ServerAddress = Request.HttpContext.Connection.RemoteIpAddress!.ToString();
            sessionObj.SessionId = sessionId;
            sessionObj.Attributes = attributes;
        }

        HeliosFastCache.Set(GetSessionCacheKey(sessionId), sessionObj, _sessionTimeout);
        Logger.Info($"Created session: {sessionObj.SessionId} at {timestamp}");
        await BroadcastServerUpdate("created", sessionId);

        return Ok(sessionObj);
    }

    [HttpDelete("session/{sessionId}")]
    [VerifyToken]
    public async Task<IActionResult> DeleteSessionBySessionId(string sessionId)
    {
        var timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
        var cacheKey = GetSessionCacheKey(sessionId);

        if (!HeliosFastCache.TryGet<MatchmakingSession>(cacheKey, out var cachedSession))
        {
            Logger.Warn($"Session {sessionId} not found in cache at {timestamp}.");
            return MatchmakingErrors.UnknownSession
                .WithMessage($"Server by sessionId '{sessionId}' does not exist.").Apply(HttpContext);
        }

        HeliosFastCache.Remove(cacheKey);
        Logger.Info($"Deleted session: {sessionId} at {timestamp}");
        await BroadcastServerUpdate("deleted", sessionId);

        return Ok();
    }

    [HttpPost("session/{sessionId}/players")]
    [VerifyToken]
    public async Task<IActionResult> UpdatePlayers(string sessionId)
    {
        var timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
        var cacheKey = GetSessionCacheKey(sessionId);

        if (!HeliosFastCache.TryGet<MatchmakingSession>(cacheKey, out var session))
        {
            Logger.Warn($"Session {sessionId} not found in cache at {timestamp}.");
            return MatchmakingErrors.UnknownSession
                .WithMessage($"Server by sessionId '{sessionId}' does not exist.").Apply(HttpContext);
        }

        var body = await DeserializeRequestBody<MatchmakingSession>();
        if (body == null)
        {
            Logger.Warn($"Failed to deserialize request body for session {sessionId} at {timestamp}: Invalid player data.");
            return BasicErrors.BadRequest
                .WithMessage("Invalid request body format.")
                .Apply(HttpContext);
        }
        var publicPlayers = session.PublicPlayers?.ToList() ?? new List<string>();
        var privatePlayers = session.PrivatePlayers?.ToList() ?? new List<string>();

        if (body.PublicPlayers?.Any() == true)
            publicPlayers.AddRange(body.PublicPlayers);

        if (body.PrivatePlayers?.Any() == true)
            privatePlayers.AddRange(body.PrivatePlayers);

        session.PublicPlayers = publicPlayers;
        session.PrivatePlayers = privatePlayers;
        session.OpenPublicPlayers = publicPlayers.Count > 0 ? publicPlayers.Count - 1 : 0;
        session.LastUpdated = timestamp;

        HeliosFastCache.Set(cacheKey, session, _sessionTimeout);
        Logger.Info($"Updated players in session: {session.SessionId} at {timestamp}");
        await BroadcastServerUpdate("updated", sessionId);

        return Ok(session);
    }

    [HttpPost("session/{sessionId}/heartbeat")]
    [VerifyToken]
    public async Task<IActionResult> Heartbeat(string sessionId)
    {
        var timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
        var cacheKey = GetSessionCacheKey(sessionId);

        if (!HeliosFastCache.TryGet<MatchmakingSession>(cacheKey, out var session))
        {
            Logger.Warn($"Session {sessionId} not found in cache at {timestamp}.");
            return MatchmakingErrors.UnknownSession
                .WithMessage($"Server by sessionId '{sessionId}' does not exist.").Apply(HttpContext);
        }

        session.LastUpdated = timestamp;
        HeliosFastCache.Set(cacheKey, session, _sessionTimeout);

        Logger.Info($"Heartbeat received for session: {sessionId} at {timestamp}");
        await BroadcastServerUpdate("heartbeat", sessionId);

        return Ok(session);
    }

    [HttpPut("session/{sessionId}")]
    [VerifyToken]
    public async Task<IActionResult> UpdateSession(string sessionId)
    {
        var timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
        var cacheKey = GetSessionCacheKey(sessionId);

        if (!HeliosFastCache.TryGet<MatchmakingSession>(cacheKey, out var session))
        {
            Logger.Warn($"Session {sessionId} not found in cache at {timestamp}.");
            return MatchmakingErrors.UnknownSession
                .WithMessage($"Server by sessionId '{sessionId}' does not exist.")
                .Apply(HttpContext);
        }

        var body = await DeserializeRequestBody<MatchmakingSession>();
        if (body == null)
        {
            Logger.Warn($"Failed to deserialize request body for session {sessionId} at {timestamp}: Invalid session data.");
            return BasicErrors.BadRequest
                .WithMessage("Invalid request body format.")
                .Apply(HttpContext);
        }

        session.LastUpdated = timestamp;

        session.OwnerId = body.OwnerId;
        session.OwnerName = body.OwnerName;
        session.ServerName = body.ServerName;
        session.MaxPublicPlayers = body.MaxPublicPlayers;
        session.MaxPrivatePlayers = body.MaxPrivatePlayers;
        session.ShouldAdvertise = body.ShouldAdvertise;
        session.AllowJoinInProgress = body.AllowJoinInProgress;
        session.IsDedicated = body.IsDedicated;
        session.UsesStats = body.UsesStats;
        session.AllowInvites = body.AllowInvites;
        session.UsesPresence = body.UsesPresence;
        session.AllowJoinViaPresence = body.AllowJoinViaPresence;
        session.AllowJoinViaPresenceFriendsOnly = body.AllowJoinViaPresenceFriendsOnly;
        session.BuildUniqueId = body.BuildUniqueId;
        session.ServerPort = body.ServerPort;
        session.OpenPrivatePlayers = body.OpenPrivatePlayers;
        session.OpenPublicPlayers = body.OpenPublicPlayers;
        session.SortWeight = body.SortWeight;
        session.Started = body.Started;
        session.ServerAddress = body.ServerAddress;
        session.PublicPlayers = body.PublicPlayers ?? new List<string>();
        session.PrivatePlayers = body.PrivatePlayers ?? new List<string>();
        session.Attributes = body.Attributes ?? new Dictionary<string, object>();

        HeliosFastCache.Set(cacheKey, session, _sessionTimeout);
        await BroadcastServerUpdate("updated", sessionId);

        return Ok(session);
    }

    [HttpDelete("session/{sessionId}/players")]
    [VerifyToken]
    public async Task<IActionResult> RemovePlayers(string sessionId)
    {
        var cacheKey = GetSessionCacheKey(sessionId);

        if (!HeliosFastCache.TryGet<MatchmakingSession>(cacheKey, out var session))
        {
            return MatchmakingErrors.UnknownSession
                .WithMessage($"Session '{sessionId}' not found.")
                .Apply(HttpContext);
        }

        List<string> playerIdsToRemove;
        try
        {
            var jsonBody = await Request.ReadFromJsonAsync<JsonElement>();

            if (jsonBody.ValueKind != JsonValueKind.Array)
            {
                return BasicErrors.BadRequest
                    .WithMessage("Request body must be a JSON array of player IDs.")
                    .Apply(HttpContext);
            }

            playerIdsToRemove = jsonBody.EnumerateArray()
                .Select(element => element.GetString())
                .Where(id => !string.IsNullOrWhiteSpace(id))
                .Distinct()
                .ToList();

            if (playerIdsToRemove.Count == 0)
            {
                return Ok(session);
            }
        }
        catch (Exception)
        {
            return BasicErrors.BadRequest
                .WithMessage("Invalid JSON format in request body.")
                .Apply(HttpContext);
        }

        session.PublicPlayers = (session.PublicPlayers ?? new List<string>())
            .Where(player => !playerIdsToRemove.Contains(player, StringComparer.OrdinalIgnoreCase))
            .ToList();

        session.PrivatePlayers = (session.PrivatePlayers ?? new List<string>())
            .Where(player => !playerIdsToRemove.Contains(player, StringComparer.OrdinalIgnoreCase))
            .ToList();

        session.LastUpdated = DateTime.UtcNow.ToIsoUtcString();
        HeliosFastCache.Set(cacheKey, session, _sessionTimeout);

        await BroadcastServerUpdate("updated", sessionId);

        return Ok(session);
    }

    [HttpPost("session/{sessionId}")]
    [VerifyToken]
    public async Task<IActionResult> UpdateSessionById(string sessionId)
    {
        var timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
        var cacheKey = GetSessionCacheKey(sessionId);

        if (!HeliosFastCache.TryGet<MatchmakingSession>(cacheKey, out var session))
        {
            Logger.Warn($"Session {sessionId} not found in cache at {timestamp}.");
            return MatchmakingErrors.UnknownSession
                .WithMessage($"Server by sessionId '{sessionId}' does not exist.").Apply(HttpContext);
        }

        var body = await DeserializeRequestBody<MatchmakingSession>();
        if (body == null)
        {
            Logger.Warn($"Failed to deserialize request body for session {sessionId} at {timestamp}: Invalid session data.");
            return BasicErrors.BadRequest
                .WithMessage("Invalid request body format.")
                .Apply(HttpContext);
        }

        session.LastUpdated = timestamp;

        session.OwnerId = body.OwnerId;
        session.OwnerName = body.OwnerName;
        session.ServerName = body.ServerName;
        session.MaxPublicPlayers = body.MaxPublicPlayers;
        session.MaxPrivatePlayers = body.MaxPrivatePlayers;
        session.ShouldAdvertise = body.ShouldAdvertise;
        session.AllowJoinInProgress = body.AllowJoinInProgress;
        session.IsDedicated = body.IsDedicated;
        session.UsesStats = body.UsesStats;
        session.AllowInvites = body.AllowInvites;
        session.UsesPresence = body.UsesPresence;
        session.AllowJoinViaPresence = body.AllowJoinViaPresence;
        session.AllowJoinViaPresenceFriendsOnly = body.AllowJoinViaPresenceFriendsOnly;
        session.BuildUniqueId = body.BuildUniqueId;
        session.ServerPort = body.ServerPort;
        session.OpenPrivatePlayers = body.OpenPrivatePlayers;
        session.OpenPublicPlayers = body.OpenPublicPlayers;
        session.SortWeight = body.SortWeight;
        session.Started = body.Started;
        session.ServerAddress = body.ServerAddress;
        session.PublicPlayers = body.PublicPlayers ?? new List<string>();
        session.PrivatePlayers = body.PrivatePlayers ?? new List<string>();
        session.Attributes = body.Attributes ?? new Dictionary<string, object>();

        HeliosFastCache.Set(cacheKey, session, _sessionTimeout);
        Logger.Info($"Updated session: {session.SessionId} at {timestamp}");

        await BroadcastServerUpdate("updated", sessionId);

        return Ok(session);
    }

    [HttpPost("session/{sessionId}/start")]
    [VerifyToken]
    public async Task<IActionResult> StartSession(string sessionId)
    {
        var cacheKey = GetSessionCacheKey(sessionId);

        if (!HeliosFastCache.TryGet<MatchmakingSession>(cacheKey, out var session))
        {
            return MatchmakingErrors.UnknownSession
                .WithMessage($"Server by sessionId '{sessionId}' does not exist.").Apply(HttpContext);
        }

        session.Started = true;
        session.LastUpdated = DateTime.UtcNow.ToIsoUtcString();

        HeliosFastCache.Set(cacheKey, session, _sessionTimeout);
        await BroadcastServerUpdate("updated", sessionId);

        return Ok(session);
    }

    [HttpPost("session/{sessionId}/stop")]
    [VerifyToken]
    public async Task<IActionResult> StopSession(string sessionId)
    {
        var cacheKey = GetSessionCacheKey(sessionId);

        if (!HeliosFastCache.TryGet<MatchmakingSession>(cacheKey, out var session))
        {
            Logger.Warn($"Session {sessionId} not found in cache.");
            return MatchmakingErrors.UnknownSession
                .WithMessage($"Server by sessionId '{sessionId}' does not exist.").Apply(HttpContext);
        }

        HeliosFastCache.Remove(cacheKey);
        await BroadcastServerUpdate("deleted", sessionId);

        return Ok();
    }
}