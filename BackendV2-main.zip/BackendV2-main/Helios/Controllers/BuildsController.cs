﻿    using Helios.Utilities;
    using Helios.Utilities.Errors.HeliosErrors;
    using Helios.Utilities.Extensions;
    using Microsoft.AspNetCore.Mvc;

    namespace Helios.Controllers;

    [ApiController]
    [Route("/Builds/Fortnite/Content/CloudDir/")]
    public class BuildsController : ControllerBase
    {
        private static readonly string BaseAssetsPath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "CloudDir");

        [HttpGet("{file}")]
        public IActionResult GetFile(string file)
        {
            var filePath = Path.Combine(BaseAssetsPath, file);

            if (!System.IO.File.Exists(filePath))
            {
                Logger.Warn($"File '{file}' not found.");
                return BasicErrors.NotFound.WithMessage($"File '{file}' not found.").Apply(HttpContext);
            }

            return PhysicalFile(filePath, "application/octet-stream");
        }

        [HttpGet("{namespace}/{file}")]
        [HttpGet("ChunksV4/{num:int}/{file}")]
        [HttpGet("Deltas/{whatever}/{file}")]
        public IActionResult AlsoGetTheFile(string file)
        {
            string? fileName = file switch
            {
                var f when f.Contains(".ini") => "Full.ini",
                var f when f.Contains(".chunk") => "Helios.chunk",
                var f when f.Contains(".manifest") => "Helios.manifest",
                _ => "Helios.chunk"
            };

            if (fileName == null)
            {
                Logger.Warn($"File '{file}' not found.");
                return BasicErrors.NotFound.WithMessage($"File '{file}' not found.").Apply(HttpContext);
            }

            var filePath = Path.Combine(BaseAssetsPath, fileName);
            return PhysicalFile(filePath, "application/octet-stream");
        }
    }