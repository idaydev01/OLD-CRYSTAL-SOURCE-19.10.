﻿using Helios.Classes.Errors;
using Helios.Classes.Storefront;
using Helios.Classes.Storefront.Dashboard;
using Helios.Classes.Storefront.Dashboard.FortniteAPI;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Dashboard;
using Helios.Database.Tables.Fortnite;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Asn1.Ocsp;
using System.Collections.Concurrent;
using System.Net.Http;
using System.Text.Json;

namespace Helios.Controllers.Dashboard;

[ApiController]
[Route("/dashboard/api/storefront/")]
public class DashboardStorefrontController : ControllerBase
{
    private readonly HttpClient _httpClient;
    private static ConcurrentBag<AddStorefrontItemRequest> FeaturedCache = new();
    private static ConcurrentBag<AddStorefrontItemRequest> DailyCache = new();

    public DashboardStorefrontController()
    {
        _httpClient = new HttpClient();
    }

    [HttpPost("save")]
    public async Task<IActionResult> SaveStorefront([FromBody] SaveStorefrontRequest request)
    {
        try
        {
            if (request == null)
                return BasicErrors.BadRequest.WithMessage("Request is invalid.").Apply(HttpContext);

            var catalogRepository = Constants.repositoryPool.For<Catalog>();

            await DeleteByStorefrontAsync(catalogRepository, "BRWeeklyStorefront");
            await DeleteByStorefrontAsync(catalogRepository, "BRDailyStorefront");

            var allItems = (request.FeaturedItems ?? new List<StorefrontItemRequest>())
                .Concat(request.DailyItems ?? new List<StorefrontItemRequest>())
                .GroupBy(x => x.CosmeticId)
                .Select(g => g.First())
                .ToList();

            var cosmeticDataMap = new ConcurrentDictionary<string, JSONResponse>();

            await Parallel.ForEachAsync(allItems, new ParallelOptions { MaxDegreeOfParallelism = 10 }, async (item, ct) =>
            {
                var data = await GetCosmeticFromApi(item.CosmeticId);
                if (data != null)
                    cosmeticDataMap[item.CosmeticId] = data;
            });

            var featuredStorefrontItems = new List<StorefrontItem>();
            var featuredCategories = new List<string>();

            foreach (var item in request.FeaturedItems ?? Enumerable.Empty<StorefrontItemRequest>())
            {
                if (cosmeticDataMap.TryGetValue(item.CosmeticId, out var cosmetic))
                {
                    featuredStorefrontItems.Add(new StorefrontItem
                    {
                        Id = item.CosmeticId,
                        Name = cosmetic.Name,
                        Price = item.Price,
                        Rarity = cosmetic.Rarity?.DisplayValue ?? "Common",
                        Type = cosmetic.Type?.DisplayValue ?? "Outfit",
                        Image = cosmetic.Images?.Icon ?? cosmetic.Images?.SmallIcon ?? ""
                    });
                    featuredCategories.Add(cosmetic.Set?.BackendValue ?? "Default");
                }
            }

            var dailyStorefrontItems = new List<StorefrontItem>();
            foreach (var item in request.DailyItems ?? Enumerable.Empty<StorefrontItemRequest>())
            {
                if (cosmeticDataMap.TryGetValue(item.CosmeticId, out var cosmetic))
                {
                    dailyStorefrontItems.Add(new StorefrontItem
                    {
                        Id = item.CosmeticId,
                        Name = cosmetic.Name,
                        Price = item.Price,
                        Rarity = cosmetic.Rarity?.DisplayValue ?? "Common",
                        Type = cosmetic.Type?.DisplayValue ?? "Outfit",
                        Image = cosmetic.Images?.Icon ?? cosmetic.Images?.SmallIcon ?? ""
                    });
                }
            }

            var saveTasks = new List<Task>();

            foreach (var (item, index) in featuredStorefrontItems.Select((v, i) => (v, i)))
            {
                if (cosmeticDataMap.TryGetValue(item.Id, out var cosmetic))
                {
                    var category = index < featuredCategories.Count ? featuredCategories[index] : "";
                    saveTasks.Add(SaveStorefrontItems(catalogRepository, new List<StorefrontItem> { item }, cosmetic, "BRWeeklyStorefront", new List<string> { category }));
                }
            }

            foreach (var item in dailyStorefrontItems)
            {
                if (cosmeticDataMap.TryGetValue(item.Id, out var cosmetic))
                {
                    saveTasks.Add(SaveStorefrontItems(catalogRepository, new List<StorefrontItem> { item }, cosmetic, "BRDailyStorefront", new List<string>()));
                }
            }

            await Task.WhenAll(saveTasks);

            return Ok(new StorefrontResponse
            {
                Success = true,
                Message = "Storefront saved successfully",
                FeaturedItems = featuredStorefrontItems,
                DailyItems = dailyStorefrontItems
            });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error saving storefront: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    [HttpGet("load")]
    public async Task<IActionResult> LoadStorefront()
    {
        try
        {
            var catalogRepository = Constants.repositoryPool.For<Catalog>();

            var featuredItems = await LoadStorefrontItems(catalogRepository, "BRWeeklyStorefront");
            var dailyItems = await LoadStorefrontItems(catalogRepository, "BRDailyStorefront");

            return Ok(new StorefrontResponse
            {
                Success = true,
                Message = "Storefront loaded successfully",
                FeaturedItems = featuredItems,
                DailyItems = dailyItems
            });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error loading storefront: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    [HttpDelete("clear")]
    public async Task<IActionResult> ClearStorefront()
    {
        try
        {
            var catalogRepository = Constants.repositoryPool.For<Catalog>();

            await DeleteByStorefrontAsync(catalogRepository, "BRWeeklyStorefront");
            await DeleteByStorefrontAsync(catalogRepository, "BRDailyStorefront");

            return Ok(new { success = true, message = "Storefront cleared successfully" });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error clearing storefront: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    [HttpPost("add")]
    public async Task<IActionResult> AddStorefrontItem([FromBody] AddStorefrontItemRequest request)
    {
        try
        {
            if (request == null || string.IsNullOrEmpty(request.CosmeticId) || string.IsNullOrEmpty(request.Section))
                return BasicErrors.BadRequest.WithMessage("Request is invalid or missing required fields.").Apply(HttpContext);

            if (request.Section != "featured" && request.Section != "daily")
                return BasicErrors.BadRequest.WithMessage("Invalid section. Must be 'featured' or 'daily'.").Apply(HttpContext);

            var cosmetic = await GetCosmeticFromApi(request.CosmeticId);
            if (cosmetic == null)
                return BasicErrors.BadRequest.WithMessage("Cosmetic not found or invalid cosmetic ID.").Apply(HttpContext);

            var storefrontItem = new StorefrontItem
            {
                Id = request.CosmeticId,
                Name = cosmetic.Name,
                Price = request.Price,
                Rarity = cosmetic.Rarity?.DisplayValue ?? "Common",
                Type = cosmetic.Type?.DisplayValue ?? "Outfit",
                Image = cosmetic.Images?.Icon ?? cosmetic.Images?.SmallIcon ?? ""
            };

            if (request.Section == "featured")
                FeaturedCache.Add(request);
            else
                DailyCache.Add(request);

            return Ok(new AddStorefrontItemResponse
            {
                Success = true,
                Message = "Item added to cache successfully",
                Item = storefrontItem
            });
        }
        catch (Exception ex)
        {
            Logger.Error($"Error adding storefront item: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    private async Task<List<StorefrontItem>> LoadStorefrontItems(Repository<Catalog> repository, string storefrontType)
    {
        var catalogItems = await repository.FindAllByColumnAsync("storefront", new[] { storefrontType });
        var items = new List<StorefrontItem>();

        if (catalogItems?.Any() == true)
        {
            foreach (var catalogItem in catalogItems)
            {


                var cosmetic = await GetCosmeticFromApi(catalogItem.OfferId);
                if (cosmetic == null)
                    continue;

                items.Add(new StorefrontItem
                {
                    Id = catalogItem.OfferId,
                    Name = catalogItem.Name,
                    Price = int.TryParse(catalogItem.Value, out int price) ? price : 0,
                    Rarity = cosmetic.Rarity.DisplayValue,
                    Type = cosmetic.Type.Value,
                    Image = cosmetic.Images.SmallIcon
                });
            }
        }

        return items;
    }

    private async Task DeleteByStorefrontAsync(Repository<Catalog> repository, string storefront)
    {
        var oldItems = await repository.FindAllByColumnAsync("storefront", new[] { storefront });
        if (oldItems?.Any() == true)
            await Task.WhenAll(oldItems.Select(item => repository.DeleteAsync(item)));
    }

    private async Task SaveStorefrontItems(
        Repository<Catalog> repository,
        List<StorefrontItem> items,
        JSONResponse apiItem,
        string storefrontType,
        List<string> categories)
    {
        var now = DateTime.UtcNow.ToIsoUtcString();
        var isWeeklyStorefront = storefrontType == "BRWeeklyStorefront";
        Logger.Info(storefrontType);

        var saveTasks = items.Select((item, index) =>
        {
            var entry = StorefrontManager.New(apiItem, item.Price, isWeeklyStorefront ? "featured" : "daily");
            if (entry == null)
                return Task.CompletedTask;

            var category = (index < categories.Count && !string.IsNullOrWhiteSpace(categories[index]))
                ? categories[index]
                : "";

            var catalogItem = new Catalog
            {
                CreatedAt = now,
                Storefront = storefrontType,
                OfferId = item.Id,
                TemplateId = item.Id,
                Name = item.Name,
                Value = JsonSerializer.Serialize(entry),
                Category = new List<string> { category }
            };

            return repository.SaveAsync(catalogItem);
        });

        await Task.WhenAll(saveTasks);
    }

    private async Task<JSONResponse> GetCosmeticFromApi(string cosmeticId)
    {
        try
        {
            var cleanId = cosmeticId.Contains(':') ? cosmeticId.Split(':').Last() : cosmeticId;
            Logger.Debug(cleanId);
            var response = await _httpClient.GetAsync($"https://fortnite-api.com/v2/cosmetics/br/{cleanId}");
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                var apiResponse = JsonSerializer.Deserialize<APIResponse>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                return apiResponse?.Data;
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Error fetching cosmetic {cosmeticId}: {ex.Message}");
        }
        return null;
    }
}
