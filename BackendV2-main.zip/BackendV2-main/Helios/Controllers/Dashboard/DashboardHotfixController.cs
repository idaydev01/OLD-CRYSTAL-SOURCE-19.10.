using Helios.Classes.Errors;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Database.Tables.Dashboard;
using Helios.Database.Tables.Fortnite;
using Helios.Database.Tables.Profiles;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Launcher;
using Helios.Utilities.Profile;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Helios.Controllers.Dashboard;

[ApiController]
[Route("/dashboard/api/hotfixes/")]
public class DashboardHotfixController : ControllerBase
{
    [HttpGet("list")]
    public async Task<IActionResult> GetAllHotfixesAsync()
    {
        var cloudstorageRepository = Constants.repositoryPool.For<CloudStorage>();
        var hotfixes = await cloudstorageRepository.FindAllByTableAsync();
        if (hotfixes.Count == 0)
            return MCPErrors.InvalidPayload.WithIntent(Intents.Prod).Apply(HttpContext);

        var enabledHotfixes = hotfixes.Where(x => x.Enabled).ToList();
        if (enabledHotfixes.Count == 0)
            return MCPErrors.InvalidPayload.WithIntent(Intents.Prod).Apply(HttpContext);

        return Ok(enabledHotfixes);
    }


    [HttpPost("update/{filename}")]
    public async Task<IActionResult> UpdateHotfixesAsync(string filename)
    {
        try
        {
            var cloudstorageRepository = Constants.repositoryPool.For<CloudStorage>();
            string newHotfixContent = await new StreamReader(Request.Body).ReadToEndAsync();

            if (string.IsNullOrWhiteSpace(newHotfixContent))
                return BadRequest("Hotfix content cannot be empty.");

            var enabledHotfix = (await cloudstorageRepository.FindAllByTableAsync())
                ?.FirstOrDefault(x => x.Enabled && x.Filename == filename);

            if (enabledHotfix == null)
                return MCPErrors.InvalidPayload.WithIntent(Intents.Prod).Apply(HttpContext);

            enabledHotfix.Value = newHotfixContent;
            await cloudstorageRepository.UpdateAsync(enabledHotfix);

            return NoContent();
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to update hotfix {filename}: {ex}");
            return InternalErrors.ServerError.WithMessage("Failed to update hotfix").Apply(HttpContext);
        }
    }
}