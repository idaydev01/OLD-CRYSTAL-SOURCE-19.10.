using Discord;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Database.Tables.XMPP;
using Helios.Socket;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Helios.Controllers.AntiCheat;

[ApiController]
[Route("/h/v1/")]
public class HermesApiController : ControllerBase
{
    [HttpGet("auth/verify")]
    public async Task<IActionResult> VerifyClient([FromQuery] string accountId, [FromQuery] string token)
    {
        var hermesToken = Request.Headers["X-Hermes-Token"];
        if (string.IsNullOrEmpty(hermesToken))
        {
            return AuthenticationErrors.InvalidToken("Invalid Token")
                .WithMessage("'X-Hermes-Token' is null.")
                .Apply(HttpContext);
        }

        if (hermesToken != Constants.ValidApiKey)
        {
            return AuthenticationErrors.InvalidToken("Invalid Token")
                .WithMessage("Token is not valid.")
                .Apply(HttpContext);
        }

        var userRepository = Constants.repositoryPool.For<User>();
        var user = await userRepository.FindByColumnAsync("accountid", accountId);
        if (user == null)
        {
            return AccountErrors.AccountNotFound(accountId)
                .WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);
        }

        var whitelistedUsernames = new[]
        {
            "sigmags",
            "ONBROISAFUCKINGRETARDKYSNWORDFUCKINGGSGSGSGSGSGS",
            "chargedcum",
            "STINKYFUCKINGRETARDNEGAN",
            "TIVANMPISANASTYJEWCRACKER",
            "FUCKUVENTIRETARS11",
            "hoster105",
            "hoster10145",
            "hoster10433245"
        };

        var serverAccountsRepository = Constants.repositoryPool.For<ServerAccounts>();
        var serverAccount = await serverAccountsRepository.FindByColumnAsync("username", user.Username);

        bool isWhitelisted = whitelistedUsernames.Contains(user.Username) || serverAccount != null;
        if (isWhitelisted)
        {
            return AuthenticationErrors.InvalidRequest
                .WithMessage("Server accounts are not allowed.")
                .Apply(HttpContext);
        }

        if (string.IsNullOrEmpty(token))
        {
            return AuthenticationErrors.InvalidToken("Invalid Token")
                .WithMessage("Token is null or empty.")
                .Apply(HttpContext);
        }

        return Ok(new
        {
            accountId = user.AccountId,
            username = user.Username,
        });
    }

    [HttpGet("friends")]
    public async Task<IActionResult> GetFriends([FromQuery] string accountId)
    {
        var hermesToken = Request.Headers["X-Hermes-Token"];
        if (string.IsNullOrEmpty(hermesToken))
        {
            return AuthenticationErrors.InvalidToken("Invalid Token")
                .WithMessage("'X-Hermes-Token' is null.")
                .Apply(HttpContext);
        }

        if (hermesToken != Constants.ValidApiKey)
        {
            return AuthenticationErrors.InvalidToken("Invalid Token")
                .WithMessage("Token is not valid.")
                .Apply(HttpContext);
        }

        var userRepository = Constants.repositoryPool.For<User>();
        var user = await userRepository.FindByColumnAsync("accountid", accountId);
        if (user == null)
        {
            return AccountErrors.AccountNotFound(accountId)
                .WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);
        }

        var whitelistedUsernames = new[]
        {
            "sigmags",
            "ONBROISAFUCKINGRETARDKYSNWORDFUCKINGGSGSGSGSGSGS",
            "chargedcum",
            "STINKYFUCKINGRETARDNEGAN",
            "TIVANMPISANASTYJEWCRACKER",
            "FUCKUVENTIRETARS11",
            "hoster105",
            "hoster10145",
            "hoster10433245"
        };

        var serverAccountsRepository = Constants.repositoryPool.For<ServerAccounts>();
        var serverAccount = await serverAccountsRepository.FindByColumnAsync("username", user.Username);

        bool isWhitelisted = whitelistedUsernames.Contains(user.Username) || serverAccount != null;
        if (isWhitelisted)
        {
            return AuthenticationErrors.InvalidRequest
                .WithMessage("Server accounts are not allowed.")
                .Apply(HttpContext);
        }

        var friendsRepository = Constants.repositoryPool.For<Friends>();
        var friends = await friendsRepository.FindAllByColumnAsync("accountid", new[] { accountId });

        var allFriends = friends
            .Select(f => new
            {
                id = f.FriendId,
                status = f.Status,
                direction = f.Direction
            })
            .ToList();

        return Ok(allFriends);
    }
}
