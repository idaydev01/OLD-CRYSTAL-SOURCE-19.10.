import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface SettingsStore {
  bubbleWrapBuilds: boolean;
  resetOnRelease: boolean;
  viewMode: "list" | "grid";
  alwaysOnTop: boolean;
  setAlwaysOnTop: (alwaysOnTop: boolean) => void;
  toggleBubbleWrapBuilds: () => void;
  toggleResetOnRelease: () => void;
  setViewMode: (mode: "list" | "grid") => void;
}

export const useSettingsStore = create<SettingsStore>()(
  persist(
    (set) => ({
      bubbleWrapBuilds: false,
      resetOnRelease: false,
      viewMode: "list",
      alwaysOnTop: false,
      setAlwaysOnTop: (alwaysOnTop) => set({ alwaysOnTop }),
      toggleBubbleWrapBuilds: () =>
        set((state) => ({ bubbleWrapBuilds: !state.bubbleWrapBuilds })),
      toggleResetOnRelease: () =>
        set((state) => ({ resetOnRelease: !state.resetOnRelease })),
      setViewMode: (mode) => set({ viewMode: mode }),
    }),
    {
      name: "crystal-settings",
    }
  )
);
