// this shat is not done its odl

import type React from "react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Download,
  Archive,
  Pause,
  Play,
  X,
  TrendingUp,
  HardDrive,
  ArrowLeft,
} from "lucide-react";

interface Build {
  version: string;
  isPrivate: boolean;
  zipUrl: string;
  normalUrl: string;
  splashUrl: string;
  status: "available" | "beta" | "stable";
  releaseDate: string;
  size: string;
  description: string;
}

interface DownloadStatusProps {
  build: Build;
  onClose: () => void;
}

interface DownloadState {
  isDownloading: boolean;
  progress: number;
  speed: number;
  downloaded: number;
  totalSize: number;
  timeRemaining: number;
  isPaused: boolean;
  selectedType: "normal" | "zip" | null;
}

export const DownloadStatus: React.FC<DownloadStatusProps> = ({
  build,
  onClose,
}) => {
  const [downloadState, setDownloadState] = useState<DownloadState>({
    isDownloading: false,
    progress: 0,
    speed: 0,
    downloaded: 0,
    totalSize: Number.parseFloat(build.size) * 1024 * 1024 * 1024,
    timeRemaining: 0,
    isPaused: false,
    selectedType: null,
  });

  const downloadOptions = [
    {
      id: "normal" as const,
      name: "Standard Download",
      icon: Download,
      description: "Regular game files",
      size: build.size,
    },
    {
      id: "zip" as const,
      name: "ZIP Archive",
      icon: Archive,
      description: "Compressed download",
      size: `${(Number.parseFloat(build.size) * 0.7).toFixed(1)} GB`,
    },
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (downloadState.isDownloading && !downloadState.isPaused) {
      interval = setInterval(() => {
        setDownloadState((prev) => {
          if (prev.progress >= 100) {
            return { ...prev, isDownloading: false, progress: 100 };
          }

          const baseSpeed = 15 + Math.random() * 25;
          const variation = Math.sin(Date.now() / 1000) * 10;
          const newSpeed = Math.max(5, baseSpeed + variation) * 1024 * 1024;

          const increment = (newSpeed / prev.totalSize) * 100 * 0.1;
          const newProgress = Math.min(100, prev.progress + increment);
          const newDownloaded = (newProgress / 100) * prev.totalSize;
          const remaining = prev.totalSize - newDownloaded;
          const timeRemaining = remaining / newSpeed;

          return {
            ...prev,
            progress: newProgress,
            speed: newSpeed,
            downloaded: newDownloaded,
            timeRemaining,
          };
        });
      }, 100);
    }

    return () => clearInterval(interval);
  }, [downloadState.isDownloading, downloadState.isPaused]);

  const selectDownloadType = (type: "normal" | "zip") => {
    setDownloadState((prev) => ({ ...prev, selectedType: type }));
  };

  const startDownload = () => {
    if (!downloadState.selectedType) return;

    const selectedOption = downloadOptions.find(
      (opt) => opt.id === downloadState.selectedType
    );
    const actualSize =
      Number.parseFloat(selectedOption?.size || build.size) *
      1024 *
      1024 *
      1024;

    setDownloadState((prev) => ({
      ...prev,
      isDownloading: true,
      isPaused: false,
      progress: 0,
      downloaded: 0,
      totalSize: actualSize,
    }));
  };

  const pauseDownload = () => {
    setDownloadState((prev) => ({ ...prev, isPaused: !prev.isPaused }));
  };

  const cancelDownload = () => {
    setDownloadState((prev) => ({
      ...prev,
      isDownloading: false,
      isPaused: false,
      progress: 0,
      downloaded: 0,
      speed: 0,
      timeRemaining: 0,
    }));
  };

  const resetSelection = () => {
    setDownloadState((prev) => ({
      ...prev,
      selectedType: null,
      isDownloading: false,
      isPaused: false,
      progress: 0,
      downloaded: 0,
      speed: 0,
      timeRemaining: 0,
    }));
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return (
      Number.parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i]
    );
  };

  const formatTime = (seconds: number) => {
    if (seconds === Number.POSITIVE_INFINITY || isNaN(seconds)) return "--:--";
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    if (hours > 0) {
      return `${hours}h ${minutes}m ${secs}s`;
    }
    return `${minutes}m ${secs}s`;
  };

  return (
    <div className="backdrop-blur-xl border border-slate-600/50 rounded-3xl p-8 shadow-2xl max-w-md mx-auto">
      <div className="text-center mb-8 relative">
        <button
          onClick={onClose}
          className="absolute top-0 right-0 w-8 h-8 rounded-full bg-slate-700/50 hover:bg-slate-600/50 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
        <div className="w-18 h-18 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-stone-500 to-zinc-500 flex items-center justify-center shadow-xl">
          <img
            src={`https://dl.netcable.dev/${build.version}/Splash.bmp`}
            className="w-16 h-16 rounded-lg bg-gradient-to-br from-stone-600 to-slate-800 flex items-center justify-center text-white font-bold text-lg shadow-lg"
          />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">
          Fortnite {build.version}
        </h2>
        <div className="flex items-center justify-center gap-3 text-sm">
          <span
            className={`px-3 py-1 rounded-full ${
              build.isPrivate
                ? "bg-red-500/20 text-red-300"
                : "bg-green-500/20 text-green-300"
            }`}
          >
            {build.isPrivate ? "Private" : "Public"}
          </span>
          <span className="text-slate-400">•</span>
          <span className="text-slate-300">{build.size}</span>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!downloadState.selectedType && !downloadState.isDownloading ? (
          <motion.div
            key="selection"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-semibold text-white mb-4 text-center">
              Choose Download Type
            </h3>
            {downloadOptions.map((option) => (
              <motion.button
                key={option.id}
                className="w-full p-4 rounded-2xl border border-slate-600/50 hover:bg-indigo-950 hover:border-purple-500/50 transition-all duration-200 text-left"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => selectDownloadType(option.id)}
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center">
                    <option.icon className="w-6 h-6 text-purple-300" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-white mb-1">
                      {option.name}
                    </div>
                    <div className="text-sm text-slate-400 mb-1">
                      {option.description}
                    </div>
                    <div className="text-sm font-medium text-purple-300">
                      {option.size}
                    </div>
                  </div>
                </div>
              </motion.button>
            ))}
          </motion.div>
        ) : downloadState.selectedType && !downloadState.isDownloading ? (
          <motion.div
            key="confirm"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="rounded-2xl p-4 border border-slate-600/50">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-purple-600/30 flex items-center justify-center">
                  {downloadState.selectedType === "zip" ? (
                    <Archive className="w-5 h-5 text-purple-300" />
                  ) : (
                    <Download className="w-5 h-5 text-purple-300" />
                  )}
                </div>
                <div>
                  <div className="font-medium text-white">
                    {
                      downloadOptions.find(
                        (opt) => opt.id === downloadState.selectedType
                      )?.name
                    }
                  </div>
                  <div className="text-sm text-slate-400">
                    {
                      downloadOptions.find(
                        (opt) => opt.id === downloadState.selectedType
                      )?.description
                    }
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-slate-400">Size:</span>
                  <span className="text-white ml-2 font-medium">
                    {
                      downloadOptions.find(
                        (opt) => opt.id === downloadState.selectedType
                      )?.size
                    }
                  </span>
                </div>
                <div>
                  <span className="text-slate-400">Type:</span>
                  <span className="text-white ml-2 font-medium capitalize">
                    {downloadState.selectedType}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <motion.button
                className="flex-1 p-3 hover:bg-indigo-950 text-white rounded-xl transition-all duration-200"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={resetSelection}
              >
                <ArrowLeft className="w-4 h-4 mx-auto" />
              </motion.button>
              <motion.button
                className="flex-[3] flex items-center justify-center gap-2 p-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-medium rounded-xl transition-all duration-200"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={startDownload}
              >
                <Download className="w-4 h-4" />
                Start Download
              </motion.button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="downloading"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className=" rounded-2xl p-6 border border-slate-600/50">
              <div className="flex justify-between items-center mb-4">
                <span className="font-medium text-white">Progress</span>
                <span className="text-2xl font-bold text-purple-300">
                  {downloadState.progress.toFixed(1)}%
                </span>
              </div>
              <div className="w-full  rounded-full h-4 overflow-hidden mb-4">
                <motion.div
                  className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${downloadState.progress}%` }}
                  transition={{ duration: 0.1 }}
                />
              </div>
              <div className="text-center text-slate-300">
                {formatBytes(downloadState.downloaded)} of{" "}
                {formatBytes(downloadState.totalSize)}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className=" rounded-2xl p-4 border border-slate-600/50 text-center">
                <TrendingUp className="w-6 h-6 text-green-400 mx-auto mb-2" />
                <div className="text-sm text-slate-400 mb-1">
                  Download Speed
                </div>
                <div className="text-xl font-bold text-white">
                  {(downloadState.speed / (1024 * 1024)).toFixed(1)} MB/s
                </div>
              </div>
              <div className="rounded-2xl p-4 border border-slate-600/50 text-center">
                <HardDrive className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                <div className="text-sm text-slate-400 mb-1">
                  Time Remaining
                </div>
                <div className="text-xl font-bold text-white">
                  {formatTime(downloadState.timeRemaining)}
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <motion.button
                className="flex-1 flex items-center justify-center gap-2 p-4 hover:bg-indigo-950 text-white font-medium rounded-xl transition-all duration-200"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={pauseDownload}
              >
                {downloadState.isPaused ? (
                  <Play className="w-5 h-5" />
                ) : (
                  <Pause className="w-5 h-5" />
                )}
                {downloadState.isPaused ? "Resume" : "Pause"}
              </motion.button>
              <motion.button
                className="flex items-center justify-center p-4 bg-red-600/80 hover:bg-red-600 text-white rounded-xl transition-all duration-200"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={cancelDownload}
              >
                <X className="w-5 h-5" />
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {!downloadState.isDownloading && (
        <div className="mt-8 pt-6 border-t border-slate-600/50">
          <div className="text-center text-sm text-slate-400 space-y-2">
            <div>
              Released: {new Date(build.releaseDate).toLocaleDateString()}
            </div>
            <div>Status: Ready to download</div>
          </div>
        </div>
      )}
    </div>
  );
};
