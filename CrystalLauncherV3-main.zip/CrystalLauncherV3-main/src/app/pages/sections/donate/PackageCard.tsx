import { useState } from "react";
import { open } from "@tauri-apps/plugin-shell";
import { motion } from "framer-motion";
import { Loader2, Sparkles, Zap, Star } from "lucide-react";
import { sleep } from "../../../../lib/sleep";
import { Package } from "../../../types/pages";
interface PackageCardProps {
  pkg: Package;
  index: number;
  selectedPackage: string | null;
  onSelect: (id: string) => void;
}

const storeUrls: Record<string, string> = {
  "og-donator": "https://crystalmp.mysellauth.com/product/og-bundle",
  "crystal-donator": "https://crystalmp.mysellauth.com/product/crystal-donator",
  "full-locker": "https://crystalmp.mysellauth.com/product/full-locker",
};

const PackageCard: React.FC<PackageCardProps> = ({
  pkg,
  index,
  selectedPackage,
  onSelect,
}) => {
  const [redirecting, setRedirecting] = useState(false);
  const [hovered, setHovered] = useState(false);

  const handlePurchase = async () => {
    const url = storeUrls[pkg.id];
    if (url) {
      setRedirecting(true);
      await open(url);
      await sleep(500);
      setRedirecting(false);
    } else {
      console.warn("No store URL defined for package:", pkg.id);
    }
  };

  return (
    <motion.div
      className="group relative"
      initial={{ y: 20, opacity: 0, scale: 0.9 }}
      animate={{ y: 0, opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: index * 0.2 }}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
    >
      <motion.div
        className="relative flex items-center p-4 rounded-xl border border-stone-800 hover:border-stone-600 bg-stone-900 cursor-pointer"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        transition={{ duration: 0.2, ease: "easeOut" }}
        onClick={() => onSelect(pkg.id)}
      >
        {selectedPackage === pkg.id && (
          <motion.div className="absolute inset-0 pointer-events-none">
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute"
                initial={{ scale: 0, rotate: 0 }}
                animate={{
                  scale: [1, 0.5, 1],
                  rotate: [0, 180, 360],
                  x: Math.random() * 200 - 100,
                  y: Math.random() * 100 - 50,
                }}
                transition={{
                  duration: 2,
                  repeat: Number.POSITIVE_INFINITY,
                  delay: i * 0.5,
                  ease: "easeInOut",
                }}
                style={{
                  left: `${30 + Math.random() * 40}%`,
                  top: `${30 + Math.random() * 40}%`,
                }}
              >
                <Sparkles className="w-4 h-4 text-stone-400" />
              </motion.div>
            ))}
          </motion.div>
        )}

        <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-stone-800 border border-stone-700 mr-4">
          <motion.img
            src={pkg.image}
            alt={pkg.name}
            className="w-full h-full object-cover"
            whileHover={{ scale: 1.1, rotate: 1 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          />
        </div>

        <div className="flex-1 relative">
          <motion.h3
            className="font-semibold text-stone-100 mb-1"
            animate={hovered ? { x: [0, 2, 0] } : {}}
            transition={{ duration: 0.5 }}
          >
            {pkg.name}
            {selectedPackage === pkg.id && (
              <motion.span
                className="inline-block ml-2"
                initial={{ scale: 0 }}
                animate={{ scale: 1, rotate: [0, 10, -10, 0] }}
                transition={{
                  duration: 0.5,
                  repeat: Number.POSITIVE_INFINITY,
                  repeatDelay: 2,
                }}
              >
                <Star className="w-4 h-4 text-neutral-400 fill-current" />
              </motion.span>
            )}
          </motion.h3>
          <motion.p
            className="text-stone-300 text-sm"
            animate={hovered ? { x: [0, 1, 0] } : {}}
            transition={{ duration: 0.7, delay: 0.1 }}
          >
            {pkg.description}
          </motion.p>
        </div>

        <div className="flex items-center gap-4 relative">
          <motion.p
            className="text-lg font-bold text-stone-200"
            animate={hovered ? { scale: [1, 1.05, 1] } : {}}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
          >
            {pkg.price}
          </motion.p>

          <motion.button
            className="relative cursor-pointer px-4 py-2 bg-stone-700 hover:bg-stone-600 text-stone-100 font-medium rounded-lg text-sm border border-stone-600 flex items-center gap-2 disabled:opacity-50"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            transition={{ duration: 0.2 }}
            onClick={(e) => {
              e.stopPropagation();
              handlePurchase();
            }}
            disabled={redirecting}
          >
            {redirecting ? (
              <>
                <Loader2 className="animate-spin w-4 h-4" />
                Redirecting...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                Purchase
              </>
            )}
          </motion.button>
        </div>

        {selectedPackage === pkg.id && (
          <motion.div
            className="absolute top-4 right-4"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            <motion.div
              className="relative w-3 h-3 bg-stone-400 rounded-full border border-stone-500"
              animate={{
                boxShadow: [
                  "0 0 8px rgba(120, 113, 108, 0.6)",
                  "0 0 16px rgba(120, 113, 108, 0.8)",
                  "0 0 8px rgba(120, 113, 108, 0.6)",
                ],
              }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
            />
            <motion.div
              className="absolute inset-0 bg-stone-400 rounded-full"
              animate={{ scale: [1, 1.5, 1], opacity: [1, 0, 1] }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
            />
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  );
};

export default PackageCard;
