;

import type React from "react";
import PackageCard from "./PackageCard";

interface Package {
  id: string;
  name: string;
  description: string;
  price: string;
  image: string;
}

interface PackageListProps {
  packages: Package[];
  selectedPackage: string | null;
  onSelect: (id: string) => void;
}

const PackageList: React.FC<PackageListProps> = ({
  packages,
  selectedPackage,
  onSelect,
}) => (
  <div className="mb-8">
    <h2 className="text-xl font-semibold text-white mb-2">Donator Packages</h2>
    <div className="bg-neutral-800 h-1 w-full rounded-full mb-4" />
    <div className="space-y-4">
      {packages.map((pkg, index) => (
        <PackageCard
          key={pkg.id}
          pkg={pkg}
          index={index}
          selectedPackage={selectedPackage}
          onSelect={onSelect}
        />
      ))}
    </div>
  </div>
);

export default PackageList;
