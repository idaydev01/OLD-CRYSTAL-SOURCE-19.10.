;

import type React from "react";

import { Sparkles } from "lucide-react";
import { motion } from "framer-motion";

type StoreHeaderProps = {};

const StoreHeader: React.FC<StoreHeaderProps> = () => (
  <div className="bg-[#101010] p-8">
    <motion.div
      className="text-center"
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex items-center justify-center gap-2 mb-4">
        <motion.div
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{
            duration: 2,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
          }}
        >
          <Sparkles className="w-6 h-6 text-purple-400" />
        </motion.div>
        <h1 className="text-3xl font-bold text-white">Store</h1>
      </div>
      <p className="text-gray-300 text-sm">
        Support Crystal's development with your donations. Every contribution
        helps keep our servers running and enables new features.
      </p>
    </motion.div>
  </div>
);

export default StoreHeader;
