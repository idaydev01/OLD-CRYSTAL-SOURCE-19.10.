import React from "react";
import { HelpingHand } from "lucide-react";

const SupportCrystalCard: React.FC = () => {
  return (
    <div className="bg-gradient-to-r from-cyan-800 via-teal-500 to-blue-900 py-4 px- w-70 rounded-2xl flex items-center gap-4 border border-cyan-700 transition-transform duration-300 group hover:scale-105 text-white shadow-lg">
      <HelpingHand size={56} />

      <div className="flex flex-col justify-center gap-1">
        <h2 className="text-xl font-bold leading-snug">
          SUPPORT CRYSTAL
        </h2>
        <p className="text-base font-medium leading-snug">
          Help fund Crystal's servers for special perks.
        </p>
      </div>
    </div>
  );
};

export default SupportCrystalCard;
