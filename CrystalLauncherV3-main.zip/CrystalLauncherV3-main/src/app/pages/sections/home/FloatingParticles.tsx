;

export default function FloatingParticles() {
  return (
    <>
      <div className="absolute top-4 right-4 w-1 h-1 bg-purple-400 rounded-full animate-ping" />
      <div
        className="absolute top-8 right-12 w-1.5 h-1.5 bg-pink-400 rounded-full animate-ping"
        style={{ animationDelay: "0.5s" }}
      />
      <div
        className="absolute top-12 right-6 w-1 h-1 bg-blue-400 rounded-full animate-ping"
        style={{ animationDelay: "1s" }}
      />
      <div
        className="absolute top-6 right-20 w-0.5 h-0.5 bg-purple-300 rounded-full animate-ping"
        style={{ animationDelay: "1.5s" }}
      />
    </>
  );
}
