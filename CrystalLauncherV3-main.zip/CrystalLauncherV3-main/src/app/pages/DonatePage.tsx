import { useState } from "react";
import StoreHeader from "./sections/donate/StoreHeader";
import PackageList from "./sections/donate/PackageList";

interface Package {
  id: string;
  name: string;
  price: string;
  image: string;
  description: string;
}

export default function DonatorPage() {
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null);

  const packages: Package[] = [
    {
      id: "og-donator",
      name: "OG Donator",
      price: "$10.00",
      image: "/og-donator.avif",
      description:
        "Get the original supporter badge and show your early support for Crystal.",
    },
    {
      id: "full-locker",
      name: "Full Locker",
      price: "$15.00",
      image: "/full-locker.avif",
      description:
        "Unlock everything Crystal has to offer with complete feature access.",
    },
    {
      id: "crystal-donator",
      name: "Crystal Donator",
      price: "$3.99",
      image: "/crystal-donator.avif",
      description: "Get access to privately hosted seasons.",
    },
  ];

  return (
    <div className="flex-1 p-6 min-h-screen">
      <div className="max-w-5xl mx-auto">
        <StoreHeader />
        <PackageList
          packages={packages}
          selectedPackage={selectedPackage}
          onSelect={setSelectedPackage}
        />
      </div>
    </div>
  );
}
