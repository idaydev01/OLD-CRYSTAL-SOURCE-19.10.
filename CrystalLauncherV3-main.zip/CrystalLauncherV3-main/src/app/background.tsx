import type React from "react";

interface BackgroundProps {
  children: React.ReactNode;
}

export default function Background({ children }: BackgroundProps) {
  return (
    <div className="w-[1280px] h-[720px]  bg-[#101010] text-gray-300 overflow-hidden flex flex-col shadow-2xl">
      {children}
    </div>
  );
}
