import React, { useEffect, useRef, useCallback } from "react";
import { useUserStore } from "../../../store/user";
import { getWsConfig } from "../../../lib/configurations";
import { cleanWsUrl } from "../../utils";
import { ConnectionState, useWebSocket } from "../../../lib/socket";
import { useConnectionStatus } from "./ConnectionStatus";
import type { User } from "../../types/user";

const RuntimeInitializer: React.FC = () => {
  const websocket = useWebSocket();
  const user = useUserStore();
  const { updateStatus } = useConnectionStatus();

  const mountedRef = useRef(true);
  const handlersSetup = useRef(false);
  const userRequestSent = useRef(false);
  const connectionInitialized = useRef(false);
  const cleanupFunctions = useRef<(() => void)[]>([]);

  const cleanup = useCallback(() => {
    cleanupFunctions.current.forEach((fn) => fn());
    cleanupFunctions.current = [];
    handlersSetup.current = false;
    userRequestSent.current = false;

    updateStatus({
      handlersSetup: false,
      userRequestSent: false,
    });
  }, [updateStatus]);

  const setupMessageHandlers = useCallback(() => {
    if (handlersSetup.current) return;

    cleanup();

    const unsubUser = websocket.onMessage("user", (event) => {
      const payload = event.payload as any;
      console.log(payload);
      const userData = payload.token as User | undefined;
      if (userData) {
        user.setUser(userData);
        console.log("[Runtime] User authenticated:", userData.id);
      } else {
        console.warn("[Runtime] Invalid user data received");
      }
    });

    const unsubError = websocket.onMessage("error", (event) => {
      const err = event.payload as any;
      const errorMsg = err.message || "Unknown error";
      console.error("[Runtime] WebSocket error:", errorMsg);

      if (
        errorMsg.includes("User not found") ||
        errorMsg.includes("Invalid token")
      ) {
        console.log("[Runtime] Authentication failed, signing out");
        user.signOut();
      }

      userRequestSent.current = false;
      updateStatus({
        handlersSetup: handlersSetup.current,
        userRequestSent: false,
      });
    });

    cleanupFunctions.current = [unsubUser, unsubError];
    handlersSetup.current = true;

    updateStatus({
      handlersSetup: true,
      userRequestSent: userRequestSent.current,
    });
  }, [websocket, user, cleanup, updateStatus]);

  const requestUserData = useCallback(async () => {
    if (
      userRequestSent.current ||
      !handlersSetup.current ||
      !websocket.isConnected()
    ) {
      return;
    }

    try {
      userRequestSent.current = true;
      updateStatus({
        handlersSetup: handlersSetup.current,
        userRequestSent: true,
      });

      await websocket.send({ type: "request_user" });
      console.log("[Runtime] User data requested");
    } catch (error) {
      console.error("[Runtime] Failed to request user data:", error);
      userRequestSent.current = false;
      updateStatus({
        handlersSetup: handlersSetup.current,
        userRequestSent: false,
      });
    }
  }, [websocket, updateStatus]);

  const connectWebSocket = useCallback(async () => {
    if (!user.accessToken || connectionInitialized.current) return;

    try {
      connectionInitialized.current = true;
      const wsUrl = cleanWsUrl(
        `${getWsConfig().url}?token=${user.accessToken}`
      );

      await websocket.connect({
        url: wsUrl,
        heartbeat: {
          enabled: true,
          interval: 30000,
          timeout: 10000,
        },
        reconnect: {
          enabled: true,
          maxAttempts: 5,
          delay: 1000,
          backoffMultiplier: 1.5,
        },
      });

      console.log("[Runtime] WebSocket connected");
    } catch (error) {
      console.error("[Runtime] WebSocket connection failed:", error);
      connectionInitialized.current = false;
    }
  }, [websocket, user.accessToken]);

  useEffect(() => {
    return () => {
      mountedRef.current = false;
      cleanup();
    };
  }, [cleanup]);

  useEffect(() => {
    setupMessageHandlers();
  }, [setupMessageHandlers]);

  useEffect(() => {
    const currentState = websocket.getState();

    switch (currentState) {
      case ConnectionState.CONNECTED:
        if (
          !userRequestSent.current &&
          handlersSetup.current &&
          mountedRef.current
        ) {
          requestUserData();
        }
        break;

      case ConnectionState.DISCONNECTED:
      case ConnectionState.ERROR:
        userRequestSent.current = false;
        connectionInitialized.current = false;
        updateStatus({
          handlersSetup: handlersSetup.current,
          userRequestSent: false,
        });
        break;

      case ConnectionState.RECONNECTING:
        userRequestSent.current = false;
        updateStatus({
          handlersSetup: handlersSetup.current,
          userRequestSent: false,
        });
        break;
    }
  }, [websocket.state, requestUserData, updateStatus]);

  useEffect(() => {
    if (
      user.accessToken &&
      handlersSetup.current &&
      !connectionInitialized.current
    ) {
      connectWebSocket();
    } else if (!user.accessToken && connectionInitialized.current) {
      websocket.disconnect();
      connectionInitialized.current = false;
      userRequestSent.current = false;
      updateStatus({
        handlersSetup: handlersSetup.current,
        userRequestSent: false,
      });
      console.log("[Runtime] WebSocket disconnected");
    }
  }, [user.accessToken, connectWebSocket, websocket, updateStatus]);

  return null;
};

export default React.memo(RuntimeInitializer);
